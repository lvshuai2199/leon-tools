package com.leon.leonT.impl.Nav;

import cn.elibot.robot.commons.lang.swing.ThemeUtils;
import cn.elibot.robot.plugin.contribution.navbar.NavbarApiProvider;
import cn.elibot.robot.plugin.contribution.navbar.NavbarContribution;
import cn.elibot.robot.plugin.ui.SwingService;
import cn.elibot.robot.plugin.ui.model.BaseKeyboardCallback;
import com.leon.leonT.impl.MyDaemonServiceImpl;
import com.leon.leonT.impl.XmlRpcMyDaemonFacade;
import com.leon.leonT.impl.formTools.FormTools;
import com.leon.leonT.impl.resource.ResourceSupport;
import org.apache.xmlrpc.XmlRpcException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

import static cn.elibot.robot.plugin.ui.SwingService.keyboardService;

public class LeonNavbarContributionImpl implements NavbarContribution {

    // 增加Daemon控制外部的内容
    private final MyDaemonServiceImpl daemonService;
    private final XmlRpcMyDaemonFacade xmlRpcMyDaemonFacade;

    private NavbarApiProvider navbarApiProvider;
//    private final String host = "192.168.249.1";
    private final String host = "127.0.0.1";
    private final int rpcPort = 3333;


    JTextArea statusTextArea = new JTextArea(4, 20);

    public LeonNavbarContributionImpl(MyDaemonServiceImpl daemonService, NavbarApiProvider navbarApiProvider) {
        this.daemonService = daemonService;
        this.xmlRpcMyDaemonFacade = new XmlRpcMyDaemonFacade(host, rpcPort);
        this.navbarApiProvider = navbarApiProvider;
    }

    @Override
    public void buildUI(JPanel jPanel) {
        // 外层根面板（整个视图真正容器）
        jPanel.setLayout(new BorderLayout(5, 5));

        // 创建高级标题面板
        JPanel mainPanel = SwingService.seniorPaneService.createSeniorPane(ResourceSupport.tr("常用工具"));
        mainPanel.setLayout(new BorderLayout());

        // 关键：移除最大宽度限制，允许窗口拉宽时同步放大
        mainPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        // 设置最小宽度防止挤扁，按需调整数值
        mainPanel.setMinimumSize(new Dimension(400, 300));
        // 首选推荐尺寸（打开窗口默认宽度）
        mainPanel.setPreferredSize(new Dimension(600, 400));

        // ==========【新增：顶部状态显示区域】==========
        // 状态文本域

        statusTextArea.setEditable(false);       // 禁止用户编辑，仅展示
        statusTextArea.setLineWrap(true);        // 自动换行
        statusTextArea.setWrapStyleWord(true);
        statusTextArea.setFont(new Font("Dialog", Font.PLAIN, 12));
        statusTextArea.setText("等待指令...\n");

        // 放入滚动面板，信息过长自动出现滚动条
        JScrollPane statusScroll = new JScrollPane(statusTextArea);
        statusScroll.setPreferredSize(new Dimension(800, 90));

        // 添加到mainPanel北侧（顶部）
        mainPanel.add(statusScroll, BorderLayout.NORTH);

        // 你的表单面板 GridBagLayout
        JPanel formPanel = new JPanel(new GridBagLayout());
        // 表单也设置最小宽度，内部按钮不会挤在一起
        formPanel.setMinimumSize(new Dimension(550, 350));
        // GridBag 布局必须给组件 weightx=1 才能横向拉伸铺满
        JButton jButton1 = new JButton("上电");
        jButton1.addActionListener(e -> {
            System.out.println("robot startUp!!!");
            try {
                updateStatus("正在执行机器人上电...");
                // 接收RPC返回字符串
                String result = xmlRpcMyDaemonFacade.robotStartup();
                updateStatus("机器人上电完成，返回信息：" + result);
            } catch (XmlRpcException ex) {
                ex.printStackTrace();
                updateStatus("机器人上电失败：" + ex.getMessage());
            }
        });
        JButton jButton2 = new JButton("断电");
        // 断电
        jButton2.addActionListener(e -> {
            try {
                updateStatus("正在执行机器人断电...");
                String result = xmlRpcMyDaemonFacade.robotStop();
                updateStatus("机器人断电完成，返回信息：" + result);
            } catch (XmlRpcException ex) {
                ex.printStackTrace();
                updateStatus("机器人断电失败：" + ex.getMessage());
            }
        });
        // 同一行左右平分，自动拉伸填满面板宽度
        FormTools.addComponent(formPanel,jButton1,0, 0, 1, 1, 1.0D, 0.0D, 5, 5, 5, 5, 1, 10);
        FormTools.addComponent(formPanel,jButton2,1, 0, 1, 1, 1.0D, 0.0D, 5, 5, 5, 5, 1, 10);

        JButton taskStart = new JButton("任务启动");
        taskStart.addActionListener(e -> {
            try {
                updateStatus("启动任务...");
                // 1. 加载任务文件（替换为你的任务实际路径）
//                String loadRet = xmlRpcMyDaemonFacade.load_task("weld.task");
//                updateStatus(loadRet);
                // 2. 启动任务
                String playRet = xmlRpcMyDaemonFacade.playTask();
                updateStatus("任务启动最终返回：" + playRet);
            } catch (XmlRpcException ex) {
                ex.printStackTrace();
                updateStatus("任务启动异常：" + ex.getMessage());
            }
        });
        JButton taskPause = new JButton("任务暂停");
        // 任务暂停按钮
        taskPause.addActionListener(e -> {
            try {
                updateStatus("执行任务暂停指令");
                String ret = xmlRpcMyDaemonFacade.pauseTask();
                updateStatus(ret);
            } catch (XmlRpcException ex) {
                updateStatus("暂停失败：" + ex.getMessage());
            }
        });
//        JButton taskContinue = new JButton("任务继续");
        JButton taskStop = new JButton("任务停止");
        // 任务停止按钮
        taskStop.addActionListener(e -> {
            try {
                updateStatus("执行任务停止指令");
                String ret = xmlRpcMyDaemonFacade.stopTask();
                updateStatus(ret);
            } catch (XmlRpcException ex) {
                updateStatus("停止失败：" + ex.getMessage());
            }
        });
        FormTools.addComponent(formPanel,taskStart,0, 1, 1, 1, 1.0D, 0.0D, 5, 5, 5, 5, 1, 10);
        FormTools.addComponent(formPanel,taskPause,1, 1, 1, 1, 1.0D, 0.0D, 5, 5, 5, 5, 1, 10);
        // FormTools.addComponent(formPanel,taskContinue,0, 2, 1, 1, 1.0D, 0.0D, 5, 5, 5, 5, 1, 10);
        FormTools.addComponent(formPanel,taskStop,0, 2, 1, 1, 1.0D, 0.0D, 5, 5, 5, 5, 1, 10);

        // 机械臂关节运动
        JButton r_moveJ_btn = new JButton("运动到初始位置");
        r_moveJ_btn.addActionListener(e -> {
            String script = "def moveJoint():\n" +
                    "    global u36335u28857_1_p\n" +
                    "    u36335u28857_1_p = [0.38408322662661437, -0.14749999998051516, 0.5791660826988158, 3.141590486727266, 2.0510342851484963E-10, -1.570796326794897]\n" +
                    "    global u36335u28857_1_q\n" +
                    "    u36335u28857_1_q = [0.0,-1.3553166793699976,-1.5417435069442484,-1.815330960932971,1.570796327,0.0]\n" +
                    "    global u36335u28857_2_p\n" +
                    "    u36335u28857_2_p = [0.384082379510545, -0.14749999998051516, 0.47530833400077926, -3.141590901884441, 2.051034285150165E-10, -1.5707963267948963]\n" +
                    "    global u36335u28857_2_q\n" +
                    "    u36335u28857_2_q = [0.0,-1.327509509546772,-1.8310296704013531,-1.5538480487312125,1.570796327,0.0]\n" +
                    "    global u36335u28857_3_p\n" +
                    "    u36335u28857_3_p = [0.3840815975778526, 0.06940005726177045, 0.4753079998448488, -3.141591470706301, 7.522785813227031E-7, -1.570795659007012]\n" +
                    "    global u36335u28857_3_q\n" +
                    "    u36335u28857_3_q = [0.56630344846347,-1.2721295632916005,-1.870202375828231,-1.5700556394316383,1.570796327,0.5663027806760305]\n" +
                    "    # movej(get_inverse_kin(u36335u28857_1_p, qnear=u36335u28857_1_q), a=1.3962634015954636, v=1.0471975511965976)\n" +
                    "    # movej(get_inverse_kin(u36335u28857_2_p, qnear=u36335u28857_2_q), a=1.3962634015954636, v=1.0471975511965976)\n" +
                    "    movej(get_inverse_kin(u36335u28857_3_p, qnear=u36335u28857_3_q), a=1.3962634015954636, v=1.0471975511965976)\n" +
                    "end\n";
//                        "moveJoint()";
            updateStatus("运动到初始位置");
            this.navbarApiProvider.getTaskApi().getRpcService().runScript(script);
        });
        FormTools.addComponent(formPanel,r_moveJ_btn,1, 2, 1, 1, 1.0D, 0.0D, 5, 5, 5, 5, 1, 10);


        mainPanel.add(formPanel, BorderLayout.CENTER);
        // CENTER 会自动铺满mainPanel全部宽高
        jPanel.add(mainPanel, BorderLayout.CENTER);
    }


    @Override
    public void openView() {
        System.out.println("Hello World Navigator Contribution View Opened.");
    }

    @Override
    public void closeView() {
        System.out.println("Hello World Navigator Contribution View Closed.");
    }

    @Override
    public ViewDisplayMode getViewDisplayType() {
        return ViewDisplayMode.FLOATING_WINDOW;
    }

    @Override
    public Color getCustomTitleBackground() {
        return ThemeUtils.MAIN_MENU_COLOR;
    }

    private JButton createBackDistInput(){
        JButton saveButton = new JButton(ResourceSupport.tr("saveButtonNote"));
        return saveButton;
    }

    private JPanel createCurrentInput() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel.setOpaque(false); // 设置透明，保持与背景一致

        // 获取之前保存的数据（假设你存在 DataModel 里）
//        String savedValue = dataModel.get("current_value", "1.0");

//        JTextField textField = new JTextField(savedValue, 8);
//        textField.setEditable(false); // 机器人插件通常禁止物理键盘输入，强制用软键盘



        // 1. 从数据模型获取初始值
//        double initialValue = Double.parseDouble(dataModel.get(key, "0.0"));

        JTextField textField = new JTextField(String.valueOf(0.05), 8);
        textField.setEditable(false); // 禁止物理输入，强制弹出键盘

        JTextField textNewVariable = new JTextField();
        textNewVariable.setFocusable(false);
        textNewVariable.setPreferredSize(new Dimension(200, 30));
        textNewVariable.setMaximumSize(textNewVariable.getPreferredSize());
        textNewVariable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // 调用你提供的 showNumberKeyboard 接口
                // 假设键盘服务对象是 keyboardService
                keyboardService.showNumberKeyboard(
                        textNewVariable,    // var1: 触发组件
                        0.05, // var2: 初始值
                        2,            // var3: 允许 2 位小数
                        false,        // var4: 不允许负数 (电流通常为正)
                        new BaseKeyboardCallback<Double>() { // var5: 回调
                            @Override
                            public void onOk(Double result) {
                                // result 就是用户输入的数字
                                textField.setText(String.valueOf(result));
                                // 保存到数据模型
//                                dataModel.set(key, result);
                            }

                            @Override
                            public void onCancel() {
                                // 用户点击取消，通常不做处理
                            }
                        }
                );
            }
        });

        panel.add(textNewVariable);
        panel.add(Box.createHorizontalStrut(5)); // 加一点点间距
        panel.add(new JLabel("A"));

        return panel;
    }


    private Component createVerticalSpacing() {
        return Box.createRigidArea(new Dimension(0, 10));
    }

    private Component createHorizontalSpacing() {
        return Box.createRigidArea(new Dimension(10, 0));
    }

//    public TaskVariable createGlobalVariable(String variableName) {
//        TaskVariable variable = null;
//        try {
//            variable = this.variableService.getVariableFactory().createTaskVariable(variableName);
//        } catch (VariableException e) {
//            SwingService.messageService.showMessage("Error", e.getMessage(), MessageType.ERROR);
//        }
//
//        return variable;
//    }

    /**
     * 更新顶部状态信息，自动追加换行
     * @param msg 需要展示的返回字符串（RPC结果）
     */
    private void updateStatus(String msg) {
        // Swing界面更新必须在UI线程执行
        SwingUtilities.invokeLater(() -> {
            String time = new SimpleDateFormat("HH:mm:ss").format(new Date());
            statusTextArea.append(String.format("[%s] %s%n", time, msg));
            // 自动滚动到末尾
            statusTextArea.setCaretPosition(statusTextArea.getDocument().getLength());
        });
    }
}
