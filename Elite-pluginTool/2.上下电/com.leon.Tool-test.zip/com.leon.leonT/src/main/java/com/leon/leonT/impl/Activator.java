package com.leon.leonT.impl;

import cn.elibot.robot.commons.lang.resource.LocaleProvider;
import cn.elibot.robot.plugin.contribution.daemon.DaemonService;
import cn.elibot.robot.plugin.contribution.navbar.NavbarService;
import com.leon.leonT.impl.Nav.LeonNavbarServiceImpl;
import com.leon.leonT.impl.resource.ResourceSupport;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

/**
 * Activator for the OSGi bundle com.leon.leonT.impl contribution
 */
public class Activator implements BundleActivator {
    private ServiceReference<LocaleProvider> localeProviderServiceReference;
    private ServiceRegistration<DaemonService> daemon;


    @Override
    public void start(BundleContext bundleContext) throws Exception {
        localeProviderServiceReference = bundleContext.getServiceReference(LocaleProvider.class);
        if (localeProviderServiceReference != null) {
            LocaleProvider localeProvider = bundleContext.getService(localeProviderServiceReference);
            if (localeProvider != null) {
                ResourceSupport.setLocaleProvider(localeProvider);
            }
        }


        MyDaemonServiceImpl daemonService = new MyDaemonServiceImpl();
        this.daemon = bundleContext.registerService(DaemonService.class, daemonService, null);
        bundleContext.registerService(NavbarService.class, new LeonNavbarServiceImpl(daemonService), null);
        System.out.println("com.leon.leonT.impl.Activator says Hello World!");
    }


    @Override
    public void stop(BundleContext bundleContext) throws Exception {
        this.daemon.unregister();
        System.out.println("com.leon.leonT.impl.Activator says Goodbye World!");
    }
}
