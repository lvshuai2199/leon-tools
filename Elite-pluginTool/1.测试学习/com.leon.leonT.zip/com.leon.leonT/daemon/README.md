## **HelloWorld Daemon**
- This project only supports compiling and running on Linux systems
- The project offers two compilation methods.
  - scons
    
    build : `scons`
    
    clean: `scons -c`
  - make
    
    build: `cmake -Bbuild && cd build && make`
    
    clean: `make clean`

    ```
    .
    ├── CMakeLists.txt
    ├── include
    │   ├── Data.h
    │   ├── MyXmlRpcServerMethods.h
    │   ├── webServer.h
    │   └── xmlrpcserver.h
    ├── README.md
    ├── SConscript
    ├── SConstruct
    └── src
        ├── Data.cpp
        ├── main.cpp
        ├── MyXmlRpcServerMethods.cpp
        ├── webServer.cpp
        └── xmlrpcserver.cpp
    ```
    
    Compile with scons in pom
    
    ```
    <plugin>
        <groupId>org.codehaus.mojo</groupId>
        <artifactId>exec-maven-plugin</artifactId>
        <version>1.1</version>
        <executions>
            <execution>
                <id>compile-daemon</id>
                <phase>compile</phase>
                <goals>
                    <goal>exec</goal>
                </goals>
                <configuration>
                    <executable>scons</executable>
                    <arguments>
                        <argument>release=1</argument>
                    </arguments>
                    <workingDirectory>./daemon</workingDirectory>
                </configuration>
            </execution>
    
            <execution>
                <id>make-clean</id>
                <phase>clean</phase>
                <goals>
                    <goal>exec</goal>
                </goals>
                <configuration>
                    <executable>make</executable>
                    <arguments>
                        <argument>clean</argument>
                    </arguments>
                    <workingDirectory>./daemon/build</workingDirectory>
                </configuration>
            </execution>
        </executions>
    </plugin>
    ```
