package com.leon.leonT.impl;

import cn.elibot.robot.plugin.domain.RpcService;
import org.apache.xmlrpc.XmlRpcException;
import org.apache.xmlrpc.client.XmlRpcClient;
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class XmlRpcMyDaemonFacade {
    private final XmlRpcClient client;

    private RpcService rpcService;

    public XmlRpcMyDaemonFacade(String host, int port) {
        XmlRpcClientConfigImpl config = new XmlRpcClientConfigImpl();
        // Python 标准 SimpleXMLRPCServer 不支持 Apache 的扩展协议，必须关闭！
        config.setEnabledForExtensions(false);
        try {
             config.setServerURL(new URL("http://" + host + ":" + port + "/RPC2"));
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        //1s
        config.setConnectionTimeout(1000);
        client = new XmlRpcClient();
        client.setConfig(config);
    }


    public String setMessage(String mes) throws XmlRpcException {
        ArrayList<String> args = new ArrayList<String>();
        args.add(mes);
        Object result = client.execute("set_message", args);
        return processString(result);


    }

    // 无参方法 robot_start
    public String robotStartup() throws XmlRpcException {
        Object[] args = new Object[0]; // 空数组，不要ArrayList
        Object result = client.execute("robot_start", args);
        return processString(result);
    }

    // 无参方法 robot_start
    public String robotStop() throws XmlRpcException {
        Object[] args = new Object[0]; // 空数组，不要ArrayList
        Object result = client.execute("robot_stop", args);
        return processString(result);
    }

    // 加载任务，传入任务文件名，如 "weld.task"
    public String loadTask(String taskName) throws XmlRpcException {
        List<Object> args = new ArrayList<>();
        args.add(taskName);
        return client.execute("load_task", args).toString();
    }
    // 启动任务
    public String playTask() throws XmlRpcException {
        Object[] args = new Object[0]; // 空数组，不要ArrayList
        Object result = client.execute("play_task", args);
        return processString(result);
    }
    // 暂停任务
    public String pauseTask() throws XmlRpcException {
        Object[] args = new Object[0]; // 空数组，不要ArrayList
        Object result = client.execute("pause_task", args);
        return processString(result);
    }
    // 停止任务
    public String stopTask() throws XmlRpcException {
        Object[] args = new Object[0]; // 空数组，不要ArrayList
        Object result = client.execute("stop_task", args);
        return processString(result);
    }

    // 机械臂关节运动
    public String robotMoveJ() throws XmlRpcException {
        Object[] args = new Object[0]; // 空数组，不要ArrayList
        Object result = client.execute("robot_moveJ", args);
        return processString(result);
    }


    private String processString(Object response) {
        if (response instanceof String) {
            return (String) response;
        } else {
            return "";
        }
    }
}
