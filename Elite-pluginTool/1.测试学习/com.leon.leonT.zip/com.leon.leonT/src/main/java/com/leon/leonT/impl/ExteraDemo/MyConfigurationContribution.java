package com.leon.leonT.impl.ExteraDemo;


import cn.elibot.robot.commons.lang.StringUtils;
import cn.elibot.robot.plugin.contribution.configuration.ConfigurationAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.ConfigurationNodeContribution;
import cn.elibot.robot.plugin.domain.data.DataModelWrapper;
import cn.elibot.robot.plugin.domain.io.IO;
import cn.elibot.robot.plugin.domain.script.ScriptWriter;
import cn.elibot.robot.plugin.domain.system.LogLevel;
import cn.elibot.robot.plugin.domain.tcp.TCP;
import cn.elibot.robot.plugin.domain.value.*;

import java.util.Arrays;

/**
 * @author ELITECO SDK API
 */
public class MyConfigurationContribution implements ConfigurationNodeContribution {
    private static final String CONFIG_VAR_VALUE_KEY = "config_ext_var";
    private static final String DEFAULT_VALUE = "";
    private final MyConfigurationNodeView view;
    private final ConfigurationAPIProvider configurationApiProvider;

    private final DataModelWrapper model;

    public MyConfigurationContribution(ConfigurationAPIProvider configurationApiProvider, MyConfigurationNodeView view,
                                       DataModelWrapper model) {
        this.model = model;
        this.view = view;
        this.configurationApiProvider = configurationApiProvider;
    }

    @Override
    public void onViewOpen() {
        System.out.println("enter MyConfigurationContribution");
        view.setPopupText(getConfigVarValue());

        System.out.println("Current all TCPs:");
        configurationApiProvider.getTCPModel().getTCPs().forEach(e -> System.out.println(e.getDisplayName()));

        System.out.println("Current all Frames:");
        configurationApiProvider.getFrameModel().getFrames().forEach(e -> System.out.println(e.getName()));

        configurationApiProvider.getSystemLogService().Log(LogLevel.INFO, "{} message", "INFO");
        configurationApiProvider.getSystemLogService().Log(LogLevel.WARN, "{} message", "WARN");
        configurationApiProvider.getSystemLogService().Log(LogLevel.ERROR, "{} message", "ERROR");
        configurationApiProvider.getSystemLogService().Trace(LogLevel.INFO, "{} message", "INFO");
        configurationApiProvider.getSystemLogService().Trace(LogLevel.WARN, "{} message", "WARN");
        configurationApiProvider.getSystemLogService().Trace(LogLevel.ERROR, "{} message", "ERROR");

        configurationApiProvider.getIOModel().getIOs().forEach(io -> {
            System.out.printf("io name = %s value = %s type = %s interface type = %s, input = %s, Valid=%s\n", io.getName(),
                io.getValueStr(), io.getType().toString(), io.getInterfaceType().toString(), io.isInput() + "",
                "" + io.isResolvable());
            if (io.getInterfaceType() == IO.InterfaceType.GENERAL_PURPOSE && io.getType() == IO.IOType.BOOLEAN && io.isInput()) {
                System.out.println("GENERAL_PURPOSE BOOLEAN INPUT REG " + io.getValueStr());
            }

            if (io.getInterfaceType() == IO.InterfaceType.GENERAL_PURPOSE && io.getType() == IO.IOType.FLOAT && io.isInput()) {
                System.out.println("GENERAL_PURPOSE FLOAT INPUT REG " + io.getValueStr());
            }

            if (io.getInterfaceType() == IO.InterfaceType.GENERAL_PURPOSE && io.getType() == IO.IOType.INTEGER && io.isInput()) {
                System.out.println("GENERAL_PURPOSE INT INPUT REG " + io.getValueStr());
            }

            if (io.getInterfaceType() == IO.InterfaceType.GENERAL_PURPOSE && io.getType() == IO.IOType.BOOLEAN && !io.isInput()) {
                System.out.println("GENERAL_PURPOSE BOOLEAN OUTPUT REG " + io.getValueStr());
            }

            if (io.getInterfaceType() == IO.InterfaceType.GENERAL_PURPOSE && io.getType() == IO.IOType.FLOAT && !io.isInput()) {
                System.out.println("GENERAL_PURPOSE FLOAT OUTPUT REG " + io.getValueStr());
            }

            if (io.getInterfaceType() == IO.InterfaceType.GENERAL_PURPOSE && io.getType() == IO.IOType.INTEGER && !io.isInput()) {
                System.out.println("GENERAL_PURPOSE INT OUTPUT REG " + io.getValueStr());
            }
        });

        getDefaultValue();
    }

    @Override
    public void onViewClose() {
        System.out.println("Exit MyConfigurationContribution");
    }

    public DataModelWrapper getModel() {
        return this.model;
    }

    public boolean isDefined() {
        return !getConfigVarValue().isEmpty();
    }

    @Override
    public void generateScript(ScriptWriter writer) {
        if (!isDefined()) {
            return;
        }
        String value = getConfigVarValue();
        if (!StringUtils.isNullOrEmpty(value)) {
            writer.declareAndDefineGlobalVariable("config_ext_global_var", "\"" + value + "\"");
        }
    }

    public String getConfigVarValue() {
        String ret = model.getString(CONFIG_VAR_VALUE_KEY);
        return ret == null ? DEFAULT_VALUE : ret;
    }

    public void setConfigVarValue(String value) {
        if ("".equals(value)) {
            resetToDefaultValue();
        } else {
            model.setString(CONFIG_VAR_VALUE_KEY, value);
        }
    }

    private void resetToDefaultValue() {
        view.setPopupText(DEFAULT_VALUE);
        model.setString(CONFIG_VAR_VALUE_KEY, DEFAULT_VALUE);
    }

    public void getDefaultValue() {
        System.out.println("=========================================");
        System.out.println("Data model is changed. Show current data.");
        System.out.println("testInt: " + this.getModel().getInteger("testInt"));
        System.out.println("testDouble: " + this.getModel().getDouble("testDouble"));
        System.out.println("testBool: " + this.getModel().getBoolean("testBool"));
        System.out.println("testData: " + this.getModel().getData("testData", null));
        System.out.println("testString: " + this.getModel().getString("testString"));
        System.out.println("testBytes: " + Arrays.toString(this.getModel().get("testBytes", new byte[] {0})));
        System.out.println("testChars: " + Arrays.toString(this.getModel().get("testChars", new char[] {0})));
        System.out.println("testInts: " + Arrays.toString(this.getModel().get("testInts", new int[] {0})));
        System.out.println("testLongs: " + Arrays.toString(this.getModel().get("testLongs", new long[] {0})));
        System.out.println("testShorts: " + Arrays.toString(this.getModel().get("testShorts", new short[] {0})));
        System.out.println("testBooleans: " + Arrays.toString(this.getModel().get("testBooleans", new boolean[] {false})));
        System.out.println("testFloats: " + Arrays.toString(this.getModel().get("testFloats", new float[] {0.f})));
        System.out.println("testDoubles: " + Arrays.toString(this.getModel().get("testDoubles", new double[] {0})));
        System.out.println("testStrings: " + Arrays.toString(this.getModel().get("testStrings", new String[] {""})));
        System.out.println("*****************************************");
        System.out.println("*****************************************");

        TCP tcp = this.getModel().getTCP("TcpData");
        System.out.println("TcpData: " + tcp);

        Pose pose = this.getModel().getPose("PoseData");
        System.out.println("PoseData: " + pose);

        Acceleration acceleration = this.getModel().getAcceleration("AccelerationData");
        System.out.println("AccelerationData: " + acceleration);

        Angle angle = this.getModel().getAngle("AngleData");
        System.out.println("AngleData: " + angle);

        AngularAcceleration angularAcceleration = this.getModel().getAngularAcceleration("AngularAccelerationData");
        System.out.println("AngularAccelerationData: " + angularAcceleration);

        AngularSpeed angularSpeed = this.getModel().getAngularSpeed("AngularSpeedData");
        System.out.println("AngularSpeedData: " + angularSpeed);

        Current current = this.getModel().getCurrent("CurrentData");
        System.out.println("CurrentData: " + current);

        Force force = this.getModel().getForce("ForceData");
        System.out.println("ForceData: " + force);

        JointPosition jointPosition = this.getModel().getJointPosition("JointPositionData");
        System.out.println("JointPositionData: " + jointPosition);

        JointPositions jointPositions = this.getModel().getJointPositions("JointPositionsData");
        System.out.println("JointPositionsData: " + jointPositions);

        Length length = this.getModel().getLength("LengthData");
        System.out.println("LengthData: " + length);

        Momentum momentum = this.getModel().getMomentum("MomentumData");
        System.out.println("MomentumData: " + momentum);

        Position position = this.getModel().getPosition("PositionData");
        System.out.println("PositionData: " + position);

        Power power = this.getModel().getPower("PowerData");
        System.out.println("PowerData: " + power);

        Pressure pressure = this.getModel().getPressure("PressureData");
        System.out.println("PressureData: " + pressure);

        Rotation rotation = this.getModel().getRotation("RotationData");
        System.out.println("RotationData: " + rotation);

        Speed speed = this.getModel().getSpeed("SpeedData");
        System.out.println("SpeedData: " + speed);

        Time time = this.getModel().getTime("TimeData");
        System.out.println("TimeData: " + time);

        Torque torque = this.getModel().getTorque("TorqueData");
        System.out.println("TorqueData: " + torque);

        Voltage voltage = this.getModel().getVoltage("VoltageData");
        System.out.println("VoltageData: " + voltage);

        System.out.println("*****************************************");
        System.out.println("*****************************************");
        System.out.println("=========================================");
    }

    public void setDefaultValue() {
        this.getModel().setInteger("testInt", 123);
        this.getModel().setDouble("testDouble", 123.21);
        this.getModel().setBoolean("testBool", true);
//        this.getModel().setData("testData", new TestData(4, true));
        this.getModel().setString("testString", "ELITE ROBOTS");

        this.getModel().set("testBytes", new byte[] {1, 2, 3});
        this.getModel().set("testInts", new int[] {1, 2, 3});
        this.getModel().set("testLongs", new long[] {11L, 22L, 3L});
        this.getModel().set("testShorts", new short[] {33, 44, 55});
        this.getModel().set("testBooleans", new boolean[] {true, false, true});
        this.getModel().set("testFloats", new float[] {1.1f, 2.2f, 3.3f});
        this.getModel().set("testDoubles", new double[] {1.111, 2.222, 3.333});
        this.getModel().set("testChars", new char[] {'a', 'b', 'c'});
        this.getModel().set("testStrings", new String[] {"qqs", "swh", "shp"});

        TCP tcp = (TCP) configurationApiProvider.getTCPModel().getTCPs().toArray()[0];
        this.getModel().setTCP("TcpData", tcp);

        ValueFactory valueFactory = this.configurationApiProvider.getValueFactory();

        Pose pose = valueFactory.createPose(1, 2, 3, 4, 5, 6, Length.Unit.MM, Angle.Unit.RAD);
        this.getModel().setPose("PoseData", pose);

        Acceleration acceleration = valueFactory.createAcceleration(0.3, Acceleration.Unit.M_S2);
        this.getModel().setAcceleration("AccelerationData", acceleration);

        Angle angle = valueFactory.createAngle(1, Angle.Unit.RAD);
        this.getModel().setAngle("AngleData", angle);

        AngularAcceleration angularAcceleration = valueFactory.createAngularAcceleration(2, AngularAcceleration.Unit.RAD_S2);
        this.getModel().setAngularAcceleration("AngularAccelerationData", angularAcceleration);

        AngularSpeed angularSpeed = valueFactory.createAngularSpeed(3.3, AngularSpeed.Unit.RAD_S);
        this.getModel().setAngularSpeed("AngularSpeedData", angularSpeed);

        Current current = valueFactory.createCurrent(1.1, Current.Unit.A);
        this.getModel().setCurrent("CurrentData", current);

        Force force = valueFactory.createForce(2.2, Force.Unit.N);
        this.getModel().setForce("ForceData", force);

        JointPosition jointPosition = valueFactory.createJointPosition(4.4, Angle.Unit.RAD);
        this.getModel().setJointPosition("JointPositionData", jointPosition);

        JointPositions jointPositions = valueFactory.createJointPositions(1, 2, 3, 4, 5, 6, Angle.Unit.RAD);
        this.getModel().setJointPositions("JointPositionsData", jointPositions);

        Length length = valueFactory.createLength(6.6, Length.Unit.M);
        this.getModel().setLength("LengthData", length);

        Momentum momentum = valueFactory.createMomentum(6.7, Momentum.Unit.KG_M_S);
        this.getModel().setMomentum("MomentumData", momentum);

        Position position = valueFactory.createPosition(1.1, 2.2, 3.3, Length.Unit.M);
        this.getModel().setPosition("PositionData", position);

        Power power = valueFactory.createPower(3.2, Power.Unit.W);
        this.getModel().setPower("PowerData", power);

        Pressure pressure = valueFactory.createPressure(3.2, Pressure.Unit.PA);
        this.getModel().setPressure("PressureData", pressure);

        Rotation rotation = valueFactory.createRotation(1.1, 2.2, 3.3, Angle.Unit.RAD);
        this.getModel().setRotation("RotationData", rotation);

        Speed speed = valueFactory.createSpeed(9.9, Speed.Unit.M_S);
        this.getModel().setSpeed("SpeedData", speed);

        Time time = valueFactory.createTime(33.9, Time.Unit.S);
        this.getModel().setTime("TimeData", time);

        Torque torque = valueFactory.createTorque(3.9, Torque.Unit.NM);
        this.getModel().setTorque("TorqueData", torque);

        Voltage voltage = valueFactory.createVoltage(33, Voltage.Unit.V);
        this.getModel().setVoltage("VoltageData", voltage);
    }

    @Override
    public void contributionDestruction() {
    }

    @Override
    public void onModelChanged() {
        getDefaultValue();
    }
}
