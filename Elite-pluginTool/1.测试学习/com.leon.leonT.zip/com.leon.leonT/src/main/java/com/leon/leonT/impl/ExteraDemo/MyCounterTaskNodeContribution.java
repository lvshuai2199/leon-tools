package com.leon.leonT.impl.ExteraDemo;


import cn.elibot.robot.plugin.contribution.task.TaskApiProvider;
import cn.elibot.robot.plugin.contribution.task.TaskNodeContribution;
import cn.elibot.robot.plugin.contribution.task.TaskNodeDataModelWrapper;
import cn.elibot.robot.plugin.domain.frame.Frame;
import cn.elibot.robot.plugin.domain.script.ScriptWriter;
import cn.elibot.robot.plugin.domain.task.TaskExtensionNodeViewProvider;
import cn.elibot.robot.plugin.domain.task.listener.*;
import cn.elibot.robot.plugin.domain.task.nodes.TaskNodeFactory;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.*;
import cn.elibot.robot.plugin.domain.task.structure.TreeNode;
import cn.elibot.robot.plugin.domain.task.structure.TreeStructureException;
import cn.elibot.robot.plugin.domain.value.expression.Expression;
import cn.elibot.robot.plugin.domain.value.expression.ExpressionService;
import cn.elibot.robot.plugin.domain.value.expression.IllegalExpressionException;
import cn.elibot.robot.plugin.domain.variable.TaskVariable;
import cn.elibot.robot.plugin.domain.variable.Variable;
import cn.elibot.robot.plugin.domain.variable.VariableException;
import cn.elibot.robot.plugin.domain.variable.VariableService;
import cn.elibot.robot.plugin.ui.SwingService;
import cn.elibot.robot.plugin.ui.model.MessageType;
import com.leon.leonT.impl.resource.ImageHelper;
import com.leon.leonT.impl.resource.ResourceSupport;

import javax.swing.*;
import java.io.File;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

public class MyCounterTaskNodeContribution implements TaskNodeContribution, ContributionInsertedListener, ContributionRemovedListener, ContributionLoadCompletedListener {
    private static final ImageIcon NODE_ICON = ImageHelper.loadImage("counterNode.png");
    private static final String SELECTED_VAR = "selected_var";
    private final ExpressionService expressionService;
    private final TaskApiProvider taskApiProvider;
    private final TaskNodeDataModelWrapper taskNodeDataModelWrapper;
    private final VariableService variableService;
    private MyCounterTaskNodeView view;

    public MyCounterTaskNodeContribution(TaskApiProvider taskApiProvider, TaskNodeDataModelWrapper taskNodeDataModelWrapper) {
        this.taskApiProvider = taskApiProvider;
        this.taskNodeDataModelWrapper = taskNodeDataModelWrapper;
        this.variableService = this.taskApiProvider.getVariableService();
        this.expressionService = this.taskApiProvider.getExpressionService();
        TreeNode treeNode = this.taskApiProvider.getTaskModel().getContributionTreeNode(this);
        this.taskApiProvider.getUndoRedoManager().recordChanges(() -> MyCounterTaskNodeContribution.this.addFolderNode(treeNode));
    }

    protected void addFolderNode(TreeNode treeNode) {
        TaskNodeFactory factory = this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        FolderNode folderNode = factory.createFolderNode();
        folderNode.setDisplay("Hello world!main");
        try {
            treeNode.addChild(folderNode);
            List<TreeNode> children = treeNode.getChildren();
            for (TreeNode treeNode1 : children) {
                if (treeNode1.getTaskNode().equals(folderNode)) {
                    addCommentNode(treeNode1);
                    addHaltNode(treeNode1);
                    addPopupNode(treeNode1);
                    addCommentNode(treeNode1);
                    addScriptNode(treeNode1);
                    addCirMoveNode(treeNode1);
                }
            }
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addPopupNode(TreeNode treeNode) {
        TaskNodeFactory factory = this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        PopupNode popupNode = factory.createPopupNode();
        popupNode.setMessage("Hello world!123456");
        popupNode.setMessageDialogType(MessageType.INFO);
        try {
            treeNode.addChild(popupNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addHaltNode(TreeNode treeNode) {
        TaskNodeFactory factory = this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        HaltNode haltNode = factory.createHaltNode();
        try {
            treeNode.addChild(haltNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addCommentNode(TreeNode treeNode) {
        TaskNodeFactory factory = this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        CommentNode commentNode = factory.createCommentNode();
        commentNode.setCommentString("Hello world!");
        try {
            treeNode.addChild(commentNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addScriptNode(TreeNode treeNode) {
        TaskNodeFactory factory = this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        ScriptNode scriptNode_1 = factory.createScriptNode();
        ScriptNode scriptNode_2 = factory.createScriptNode();
        scriptNode_1.setScriptType(ScriptNode.ScriptType.FILE);
        scriptNode_2.setScriptType(ScriptNode.ScriptType.LINE);
        try {
            Expression expression_1 = taskApiProvider.getExpressionService().createExpressionConstructor().appendStringCell("a").appendCheckEqualSymbol().appendStringCell("b").construct();
            Expression expression_2 = expression_1.clone();
            scriptNode_1.setExpression(expression_1);
            scriptNode_1.setScriptFile(new File("Palletizing"));
            scriptNode_2.setExpression(expression_2);
            scriptNode_2.setScriptFile(new File("Palletizing"));

            treeNode.addChild(scriptNode_1);
            treeNode.addChild(scriptNode_2);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void addCirMoveNode(TreeNode treeNode){
        TaskNodeFactory factory = this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        MoveNode moveNode = factory.createMoveNode();
//        moveNode.setCommentString("Hello world!");
//        等待
        WaitNode waitNode =  factory.createWaitNode();


        WaypointNode rWaypoint = factory.createWaypointNode();


        try {
//            treeNode.addChild(moveNode);
            treeNode.addChild(waitNode);

            TreeNode moveJNode = treeNode.addChild(moveNode);
            moveJNode.addChild(rWaypoint);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    @Override
    public String getDisplayOnTree(Locale locale) {
        Variable variable = getSelectedVariable();
        if (variable == null) {
            return ResourceSupport.tr(locale, "Counter") + " : " + ResourceSupport.tr(locale, "NullVariable");
        } else {
            return ResourceSupport.tr(locale, "Counter") + " : " + variable.getDisplayName();
        }
    }

    @Override
    public void onViewOpen() {
        this.view.updateView(this);
    }

    @Override
    public void onViewClose() {

    }

    @Override
    public String getTitle() {
        return ResourceSupport.tr("Counter");
    }

    @Override
    public Icon getNodeIcon() {
        return NODE_ICON;
    }

    @Override
    public boolean isDefined() {
        return getSelectedVariable() != null;
    }

    @Override
    public void generateScript(ScriptWriter scriptWriter) {
        Variable variable = getSelectedVariable();
        if (variable != null) {
            String resolvedVariableName = scriptWriter.getResolvedVariableName(variable);
            scriptWriter.appendLine(resolvedVariableName + " = " + resolvedVariableName + " + 5");
            scriptWriter.appendLine(resolvedVariableName + " = " + resolvedVariableName + " + 1");
            System.out.println("hello 2 my test world!!!");
            scriptWriter.writeChildren();
        }
    }

    @Override
    public void setTaskNodeContributionViewProvider(TaskExtensionNodeViewProvider taskExtensionNodeViewProvider) {
        this.view = (MyCounterTaskNodeView) taskExtensionNodeViewProvider.get();
    }

    public Variable getSelectedVariable() {
        return taskNodeDataModelWrapper.getVariable(SELECTED_VAR);
    }

    public TaskVariable createGlobalVariable(String variableName) {
        TaskVariable variable = null;
        try {
            variable = this.variableService.getVariableFactory().createTaskVariable(variableName, this.expressionService.createExpressionConstructor().appendTokenCell("0", "0").construct());
        } catch (VariableException | IllegalExpressionException e) {
            SwingService.messageService.showMessage("Error", e.getMessage(), MessageType.ERROR);
        }

        return variable;
    }

    public void setVariable(final Variable variable) {
        this.taskApiProvider.getUndoRedoManager().recordChanges(() -> taskNodeDataModelWrapper.setVariable(SELECTED_VAR, variable));
        Frame frame = this.taskApiProvider.getFrameModel().getBaseFrame();
        try {
            Expression expression = this.taskApiProvider.getExpressionService().createExpressionConstructor().appendFrame(frame).appendGreaterOrEqualSymbol().appendCharCell('1').construct();
            taskNodeDataModelWrapper.setExpression("exp", expression);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void removeVariable() {
        this.taskApiProvider.getUndoRedoManager().recordChanges(() -> taskNodeDataModelWrapper.remove(SELECTED_VAR));
    }

    public Collection<Variable> getGlobalVariables() {
        return variableService.get(variable -> variable.getType().equals(Variable.Type.TASK) || variable.getType().equals(Variable.Type.CONFIGURATION));
    }

    @Override
    public void onInserted(ContributionInsertedContext insertedContext) {
        System.out.println("Counter is inserted");
    }

    @Override
    public void loadComplete(ContributionLoadCompleteContext completeContext) {
        System.out.println("Counter has been loaded in task tree model");
    }

    @Override
    public void onRemoved(ContributionRemovedContext contributionRemovedContext) {
        System.out.println("Counter is removed");
    }
}
