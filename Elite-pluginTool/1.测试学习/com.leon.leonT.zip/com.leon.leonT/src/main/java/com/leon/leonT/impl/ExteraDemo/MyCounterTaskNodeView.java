package com.leon.leonT.impl.ExteraDemo;

import cn.elibot.robot.commons.lang.swing.HtmlUtils;
import cn.elibot.robot.plugin.contribution.task.SwingTaskNodeView;
import cn.elibot.robot.plugin.contribution.task.TaskApiProvider;
import cn.elibot.robot.plugin.contribution.task.TaskNodeViewApiProvider;
import cn.elibot.robot.plugin.domain.io.AnalogIO;
import cn.elibot.robot.plugin.domain.io.DigitalIO;
import cn.elibot.robot.plugin.domain.io.IO;
import cn.elibot.robot.plugin.domain.io.IOFilterFactory;
import cn.elibot.robot.plugin.domain.task.PluginEntityNameException;
import cn.elibot.robot.plugin.domain.task.nodes.TaskNodeFactory;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.*;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.assignment.AssignmentNodeConfigFactory;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.configturation.DigitalPinValueType;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.loop.LoopNodeConfigFactory;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.move.builders.MoveJointConfigBuilder;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.move.builders.MoveLinerConfigBuilder;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.move.builders.MoveProcessConfigBuilder;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.set.SetNodeConfigFactory;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.wait.ExpressionInputConfig;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.wait.TimeConfig;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.wait.WaitNodeConfig;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.waypoint.*;
import cn.elibot.robot.plugin.domain.task.structure.TaskNodeVisitor;
import cn.elibot.robot.plugin.domain.task.structure.TreeNode;
import cn.elibot.robot.plugin.domain.task.structure.TreeStructureException;
import cn.elibot.robot.plugin.domain.value.*;
import cn.elibot.robot.plugin.domain.value.expression.Expression;
import cn.elibot.robot.plugin.domain.value.expression.ExpressionService;
import cn.elibot.robot.plugin.domain.value.expression.IllegalExpressionException;
import cn.elibot.robot.plugin.domain.variable.TaskVariable;
import cn.elibot.robot.plugin.domain.variable.Variable;
import cn.elibot.robot.plugin.ui.SwingService;
import cn.elibot.robot.plugin.ui.model.BaseKeyboardCallback;
import cn.elibot.robot.plugin.ui.model.MessageType;
import com.leon.leonT.impl.resource.ImageHelper;
import com.leon.leonT.impl.resource.ResourceSupport;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MyCounterTaskNodeView implements SwingTaskNodeView<MyCounterTaskNodeContribution> {
    private final JButton btnNewVariable = new JButton();
    private final JComboBox<Object> cmbVariables = new JComboBox<>();
    private final JLabel errorLabel = new JLabel();
    private final ImageIcon errorIcon;
    private final TaskNodeViewApiProvider taskNodeViewApiProvider;
    private final TaskApiProvider taskApiProvider;
    private JTextField textNewVariable;
    private MyCounterTaskNodeContribution contribution;

    public MyCounterTaskNodeView(TaskNodeViewApiProvider taskNodeViewApiProvider) {
        this.taskNodeViewApiProvider = taskNodeViewApiProvider;
        this.taskApiProvider = this.taskNodeViewApiProvider.getTaskApiProvider();
        this.errorIcon = getErrorIcon();
    }

    private ImageIcon getErrorIcon() {
        return ImageHelper.loadImage("errorIcon.png");
    }

    @Override
    public void buildUI(JPanel jPanel, MyCounterTaskNodeContribution taskNodeContribution) {

        this.contribution = taskNodeContribution;
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));

        jPanel.add(createInfo(ResourceSupport.tr("ContributionDescribe")));
        jPanel.add(createVerticalSpacing());
        jPanel.add(createComboBox(taskNodeContribution));
        jPanel.add(createInfo(ResourceSupport.tr("CreateNewButtonDescribe")));
        jPanel.add(createButtonBox(taskNodeContribution));
        jPanel.add(createVerticalSpacing());
        jPanel.add(createErrorLabel());
        jPanel.add(Box.createVerticalGlue());
        jPanel.add(createDemoButtonBox(taskNodeContribution));
        JButton jButton = new JButton();
        jButton.setText("hello leon");

        jPanel.add(jButton);

    }

    private Box createInfo(String info) {
        Box infoBox = Box.createHorizontalBox();
        infoBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel label = new JLabel();
        label.setText(HtmlUtils.toHtml(info));
        label.setSize(label.getPreferredSize());
        infoBox.add(label);
        return infoBox;
    }

    private Component createVerticalSpacing() {
        return Box.createRigidArea(new Dimension(0, 10));
    }

    private Component createHorizontalSpacing() {
        return Box.createRigidArea(new Dimension(10, 0));
    }

    private Box createComboBox(MyCounterTaskNodeContribution taskNodeContribution) {
        Box inputBox = Box.createHorizontalBox();
        inputBox.setAlignmentX(Component.LEFT_ALIGNMENT);

        cmbVariables.setFocusable(false);
        cmbVariables.setPreferredSize(new Dimension(250, 30));
        cmbVariables.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                if (e.getItem() instanceof Variable) {
                    Variable variable = (Variable) e.getItem();
                    if (!variable.equals(MyCounterTaskNodeView.this.contribution.getSelectedVariable())) {
                        MyCounterTaskNodeView.this.contribution.setVariable((Variable) e.getItem());
                    }
                } else {
                    MyCounterTaskNodeView.this.contribution.removeVariable();
                }
            }
        });

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.add(cmbVariables, BorderLayout.CENTER);

        inputBox.add(panel);
        return inputBox;
    }

    private Box createButtonBox(MyCounterTaskNodeContribution taskNodeContribution) {
        Box horizontalBox = Box.createHorizontalBox();
        horizontalBox.setAlignmentX(Component.LEFT_ALIGNMENT);

        textNewVariable = new JTextField();
        textNewVariable.setFocusable(false);
        textNewVariable.setPreferredSize(new Dimension(200, 30));
        textNewVariable.setMaximumSize(textNewVariable.getPreferredSize());
        textNewVariable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                SwingService.keyboardService.showLetterKeyboard(textNewVariable, "", false, new BaseKeyboardCallback() {
                    @Override
                    public void onOk(Object value) {
                        MyCounterTaskNodeView.this.setNewVariable((String) value);
                    }
                });
            }
        });

        horizontalBox.add(textNewVariable);
        horizontalBox.add(createHorizontalSpacing());

        btnNewVariable.setPreferredSize(new Dimension(120, 30));
        btnNewVariable.setText(ResourceSupport.tr("CreateNew"));
        btnNewVariable.addActionListener(e -> {
            clearErrors();
            TaskVariable variable = MyCounterTaskNodeView.this.contribution.createGlobalVariable(textNewVariable.getText());
            if (variable != null) {
                MyCounterTaskNodeView.this.contribution.setVariable(variable);
                updateView(MyCounterTaskNodeView.this.contribution);
            }
        });

        horizontalBox.add(btnNewVariable);
        return horizontalBox;
    }

    private Box createErrorLabel() {
        Box infoBox = Box.createHorizontalBox();
        infoBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        errorLabel.setVisible(false);
        infoBox.add(errorLabel);
        return infoBox;
    }

    public void updateView(MyCounterTaskNodeContribution taskNodeContribution) {
        this.contribution = taskNodeContribution;
        update(taskNodeContribution);
    }

    public void setNewVariable(String name) {
        textNewVariable.setText(name);
    }

    public void setError(final String message) {
        errorLabel.setText("<html>Error: Could not create variable<br>" + message + "</html>");
        errorLabel.setIcon(errorIcon);
        errorLabel.setVisible(true);
    }

    private void clearInputVariableName() {
        textNewVariable.setText("");
    }

    private void clearErrors() {
        errorLabel.setVisible(false);
    }

    private void updateComboBox(MyCounterTaskNodeContribution contribution) {
        List<Object> items = new ArrayList<>(contribution.getGlobalVariables());
        items.sort((o1, o2) -> {
            int compareTo = o1.toString().toLowerCase().compareTo(o2.toString().toLowerCase());
            if (compareTo == 0) {
                return o1.toString().compareTo(o2.toString());
            } else {
                return compareTo;
            }
        });

        items.add(0, ResourceSupport.tr("SelectVariable"));

        cmbVariables.setModel(new DefaultComboBoxModel<>(items.toArray()));

        Variable selectedVar = contribution.getSelectedVariable();
        if (selectedVar != null && !Objects.equals(cmbVariables.getSelectedItem(), selectedVar)) {
            cmbVariables.setSelectedItem(selectedVar);
        }
    }

    public void update(MyCounterTaskNodeContribution contribution) {
        clearInputVariableName();
        clearErrors();
        updateComboBox(contribution);
    }

    /**
     * test code
     */
    private Box createDemoButtonBox(MyCounterTaskNodeContribution taskNodeContribution) {
        Box verticalBox = Box.createVerticalBox();
        verticalBox.setAlignmentY(Component.TOP_ALIGNMENT);

        Box horizontalBox = Box.createHorizontalBox();
        horizontalBox.setAlignmentX(Component.LEFT_ALIGNMENT);

        horizontalBox.add(createBasicNodesBtn(taskNodeContribution));
        horizontalBox.add(createHorizontalSpacing());

        horizontalBox.add(createLogicNodesBtn(taskNodeContribution));
        horizontalBox.add(createHorizontalSpacing());

        horizontalBox.add(createMoveNodesBtn(taskNodeContribution));
        horizontalBox.add(createHorizontalSpacing());

        Box secondHorizontalBox = Box.createHorizontalBox();
        secondHorizontalBox.setAlignmentX(Component.LEFT_ALIGNMENT);

        secondHorizontalBox.add(createUndoButton());
        secondHorizontalBox.add(createHorizontalSpacing());

        secondHorizontalBox.add(createRedoButton());
        secondHorizontalBox.add(createHorizontalSpacing());

        verticalBox.add(horizontalBox);
        verticalBox.add(Box.createVerticalStrut(10));
        verticalBox.add(secondHorizontalBox);


        JButton button = new JButton(ResourceSupport.tr("TraverseAdd"));
        button.addActionListener(e -> {
            TreeNode treeNode = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel()
                .getContributionTreeNode(MyCounterTaskNodeView.this.contribution);
            MyCounterTaskNodeView.this.taskApiProvider.getUndoRedoManager().recordChanges(() -> {
                treeNode.traverse(new TaskNodeVisitor() {
                    @Override
                    public void visit(int index, int depth, TreeNode currentLocation) {
                        if (depth == 1 && index == 0) {
                            TaskNodeFactory factory =
                                MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
                            FolderNode folderNode = factory.createFolderNode();
                            folderNode.setDisplay("I am new one!");
                            try {
                                treeNode.insertChildBefore(currentLocation, folderNode);
                            } catch (TreeStructureException treeStructureException) {
                                treeStructureException.printStackTrace();
                            }

                            this.terminate();
                        }
                    }
                });
            });
        });
        horizontalBox.add(button);
        return verticalBox;
    }

    private JButton createUndoButton() {
        JButton undoBtn = new JButton("undo");
        undoBtn.setPreferredSize(new Dimension(180, 50));
        undoBtn.addActionListener(e -> {
            this.taskApiProvider.getUndoRedoService().undo();
        });

        return undoBtn;
    }

    private JButton createRedoButton() {
        JButton redoButton = new JButton("redo");
        redoButton.setPreferredSize(new Dimension(180, 50));
        redoButton.addActionListener(e -> {
            this.taskApiProvider.getUndoRedoService().redo();
        });

        return redoButton;
    }


    private JButton createMoveNodesBtn(MyCounterTaskNodeContribution taskNodeContribution) {
        JButton moveNodesBtn = new JButton(ResourceSupport.tr("MoveNodes"));
        moveNodesBtn.setPreferredSize(new Dimension(180, 50));
        moveNodesBtn.addActionListener(e -> {
            TreeNode treeNode = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel()
                .getContributionTreeNode(MyCounterTaskNodeView.this.contribution);
            MyCounterTaskNodeView.this.taskApiProvider.getUndoRedoManager().recordChanges(() -> {
                addMoveNode(treeNode);
//                addMoveArcMotionNode(treeNode);
//                addMoveArcMotionNode(treeNode);
//                addDirectionNode(treeNode);
//                addMoveCircleMotionNode(treeNode);
//                addMoveP(treeNode);
//                addCircleMotionNode(treeNode);
            });
        });

        return moveNodesBtn;
    }

    private void addMoveNode(TreeNode treeNode) {
        ValueFactory valueFactory = MyCounterTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        MoveNode moveJ = factory.createMoveNode();
        MoveJointConfigBuilder moveJointConfigBuilder = moveJ.getConfigBuilderFactory().createMoveJConfigBuilder();
        moveJointConfigBuilder.setDescribe("Demo");
        moveJointConfigBuilder.setJointSpeed(valueFactory.createAngularSpeed(80.0D, AngularSpeed.Unit.DEG_S));
        moveJointConfigBuilder.setJointAcceleration(
            valueFactory.createAngularAcceleration(1200.0D, AngularAcceleration.Unit.DEG_S2));
        moveJointConfigBuilder.setTCPSelection(moveJ.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        moveJ.setConfig(moveJointConfigBuilder.build());
        WaypointNode rWaypoint = factory.createWaypointNode();
        TransitionSelection varTransitionSelection = rWaypoint.getWaypointNodeConfigFactory().createInheritedTransitionSelection();
        MotionSelection varMotionSelection =
            rWaypoint.getWaypointNodeConfigFactory().createTimeMotion(valueFactory.createTime(3.0D, Time.Unit.S));
        JointPositions fjp = taskApiProvider.getValueFactory().createJointPositions(0, -90, 0, -90, 90, 0.0, Angle.Unit.DEG);
        JointPositions tjp = taskApiProvider.getValueFactory().createJointPositions(0, -90, 0, -90, 90, 0, Angle.Unit.DEG);
        Pose fPose = taskApiProvider.getValueFactory().createPose(92, -147.5, 1076.50, -90, 0, -90, Length.Unit.MM, Angle.Unit.DEG);
        Pose tPose = taskApiProvider.getValueFactory().createPose(92, -147.5, 1076.50, -90, 0, -90, Length.Unit.MM, Angle.Unit.DEG);
        WaypointNodeConfig rWaypointNodeConfig = rWaypoint.getWaypointNodeConfigFactory()
            .createRelativePositionConfig(fPose, tPose, fjp, tjp, varTransitionSelection, varMotionSelection);
        rWaypoint.setConfig(rWaypointNodeConfig);
        try {
            TreeNode movej = treeNode.addChild(moveJ);
            movej.addChild(rWaypoint);

        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }


        MoveNode moveL = factory.createMoveNode();
        MoveLinerConfigBuilder moveLConfigBuilder = moveL.getConfigBuilderFactory().createMoveLConfigBuilder();
        moveLConfigBuilder.setToolSpeed(valueFactory.createSpeed(80.0D, Speed.Unit.MM_S));
        moveLConfigBuilder.setToolAcceleration(valueFactory.createAcceleration(15000, Acceleration.Unit.MM_S2));
        moveLConfigBuilder.setTCPSelection(moveL.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        moveL.setConfig(moveLConfigBuilder.build());

        WaypointNode vWaypoint = factory.createWaypointNode();
        WaypointNodeConfig waypointNodeConfig = vWaypoint.getWaypointNodeConfigFactory().createVariablePositionConfig();
        vWaypoint.setConfig(waypointNodeConfig);

        List<TreeNode> children = treeNode.getChildren();
        TreeNode lastChild = children.get(children.size() > 0 ? children.size() - 1 : 0);
        if (lastChild != null) {
            try {
                TreeNode movel = treeNode.insertChildAfter(lastChild, moveL);
                movel.addChild(vWaypoint);
                vWaypoint.setName("hello1");
            } catch (TreeStructureException | PluginEntityNameException treeStructureException) {
                treeStructureException.printStackTrace();
            }
        }

        MoveNode moveP = factory.createMoveNode();
        MoveProcessConfigBuilder movePConfigBuilder = moveP.getConfigBuilderFactory().createMovePConfigBuilder();
        movePConfigBuilder.setToolSpeed(valueFactory.createSpeed(80.0D, Speed.Unit.MM_S));
        movePConfigBuilder.setToolAcceleration(valueFactory.createAcceleration(15000, Acceleration.Unit.MM_S2));
        movePConfigBuilder.setTCPSelection(moveP.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        movePConfigBuilder.setTransitionRadius(valueFactory.createLength(50.0D, Length.Unit.MM));
        moveP.setConfig(movePConfigBuilder.build());

        children = treeNode.getChildren();
        lastChild = children.get(children.size() > 0 ? children.size() - 1 : 0);
        if (lastChild != null) {
            try {
                treeNode.insertChildAfter(lastChild, moveP);
            } catch (TreeStructureException treeStructureException) {
                treeStructureException.printStackTrace();
            }
        }

        MoveNode moveWaypointNodeTemplate = factory.createMoveWaypointNodeTemplate();
        MoveJointConfigBuilder moveWaypointTempConfigBuilder =
            moveWaypointNodeTemplate.getConfigBuilderFactory().createMoveJConfigBuilder();
        moveWaypointTempConfigBuilder.setJointSpeed(valueFactory.createAngularSpeed(80.0D, AngularSpeed.Unit.DEG_S));
        moveWaypointTempConfigBuilder.setJointAcceleration(
            valueFactory.createAngularAcceleration(1200.0D, AngularAcceleration.Unit.DEG_S2));
        moveWaypointTempConfigBuilder.setTCPSelection(
            moveWaypointNodeTemplate.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        moveWaypointNodeTemplate.setConfig(moveWaypointTempConfigBuilder.build());
        try {
            treeNode.addChild(moveWaypointNodeTemplate);
            children = treeNode.getChildren();
            lastChild = children.get(children.size() > 0 ? children.size() - 1 : 0);
            if (lastChild != null) {
                addWaypoint(lastChild);
            }
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addWaypoint(TreeNode treeNode) {
        ValueFactory valueFactory = MyCounterTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        WaypointNode waypointNode = factory.createWaypointNode();
        WaypointNodeConfigFactory waypointNodeConfigFactory = waypointNode.getWaypointNodeConfigFactory();
        Length transitionRadius = valueFactory.createLength(-60.0D, Length.Unit.MM);
        TransitionSelection transitionSelection = waypointNodeConfigFactory.createWaypointTransitionSelection(transitionRadius);
        FixedPositionConfig fixedPositionConfig = waypointNodeConfigFactory.createFixedPositionConfig(transitionSelection,
            waypointNodeConfigFactory.createInheritedMotion());
        waypointNode.setConfig(fixedPositionConfig);
        try {
            treeNode.addChild(waypointNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }

        WaypointNode varWaypointNode = factory.createWaypointNode();
        TransitionSelection varTransitionSelection = waypointNodeConfigFactory.createInheritedTransitionSelection();
        MotionSelection varMotionSelection = waypointNodeConfigFactory.createTimeMotion(valueFactory.createTime(3.0D, Time.Unit.S));
        VariablePositionConfig varPositionConfig =
            waypointNodeConfigFactory.createVariablePositionConfig(varMotionSelection, varTransitionSelection);
        varWaypointNode.setConfig(varPositionConfig);
        try {
            treeNode.addChild(varWaypointNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }

    }

    /*
        添加包含一个路点的 MOVE_P 节点
     */
    private void addMoveP(TreeNode treeNode) {
        ValueFactory valueFactory = MyCounterTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        MoveNode moveP = factory.createMoveNode();
        MoveProcessConfigBuilder movePConfigBuilder = moveP.getConfigBuilderFactory().createMovePConfigBuilder();
        movePConfigBuilder.setToolSpeed(valueFactory.createSpeed(80.0D, Speed.Unit.MM_S));
        movePConfigBuilder.setToolAcceleration(valueFactory.createAcceleration(15000, Acceleration.Unit.MM_S2));
        movePConfigBuilder.setTCPSelection(moveP.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        movePConfigBuilder.setTransitionRadius(valueFactory.createLength(50.0D, Length.Unit.MM));
        moveP.setConfig(movePConfigBuilder.build());

        WaypointNode waypointNode = factory.createWaypointNode();

        List<TreeNode> children = treeNode.getChildren();
        children = treeNode.getChildren();
        TreeNode lastChild = children.get(children.size() > 0 ? children.size() - 1 : 0);

        if (lastChild != null) {
            try {
                TreeNode move = treeNode.insertChildAfter(lastChild, moveP);
                move.addChild(waypointNode);
                waypointNode.setName("test");
            } catch (TreeStructureException | PluginEntityNameException treeStructureException) {
                treeStructureException.printStackTrace();
            }
        }
    }

    private void addMoveArcMotionNode(TreeNode treeNode) {
        ValueFactory valueFactory = MyCounterTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        MoveNode moveArcMotionTemplate = factory.createMoveArcMotionTemplate();
        MoveProcessConfigBuilder moveArcMotionTempConfigBuilder =
            moveArcMotionTemplate.getConfigBuilderFactory().createMovePConfigBuilder();
        moveArcMotionTempConfigBuilder.setToolSpeed(valueFactory.createSpeed(80.0D, Speed.Unit.MM_S));
        moveArcMotionTempConfigBuilder.setToolAcceleration(valueFactory.createAcceleration(15000, Acceleration.Unit.MM_S2));
        moveArcMotionTempConfigBuilder.setTCPSelection(
            moveArcMotionTemplate.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        moveArcMotionTempConfigBuilder.setTransitionRadius(valueFactory.createLength(50.0D, Length.Unit.MM));
        moveArcMotionTemplate.setConfig(moveArcMotionTempConfigBuilder.build());
        try {
            treeNode.addChild(moveArcMotionTemplate);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    /*
        添加一个整圆/圆弧运动节点，可设置其姿态演进方向约束属性，但 treeNode 当前的最后一个节点必须是包含至少一个路点的 MOVE_P 节点，否则会添加失败
     */
    private void addCircleMotionNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        ArcMotionNode circleMotionTemplate = factory.createCircleMotionNodeTemplate();
        circleMotionTemplate.setOrientationMode(ArcMotionNode.OrientationMode.FIXED);
        List<TreeNode> children = treeNode.getChildren();
        children = treeNode.getChildren();
        TreeNode lastChild = children.get(children.size() > 0 ? children.size() - 1 : 0);

        try {
            lastChild.addChild(circleMotionTemplate);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addMoveCircleMotionNode(TreeNode treeNode) {
        ValueFactory valueFactory = MyCounterTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        MoveNode moveArcMotionTemplate = factory.createMoveCircleMotionTemplate();
        MoveProcessConfigBuilder moveArcMotionTempConfigBuilder =
            moveArcMotionTemplate.getConfigBuilderFactory().createMovePConfigBuilder();
        moveArcMotionTempConfigBuilder.setToolSpeed(valueFactory.createSpeed(80.0D, Speed.Unit.MM_S));
        moveArcMotionTempConfigBuilder.setToolAcceleration(valueFactory.createAcceleration(15000, Acceleration.Unit.MM_S2));
        moveArcMotionTempConfigBuilder.setTCPSelection(
            moveArcMotionTemplate.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        moveArcMotionTempConfigBuilder.setTransitionRadius(valueFactory.createLength(50.0D, Length.Unit.MM));
        moveArcMotionTemplate.setConfig(moveArcMotionTempConfigBuilder.build());
        try {
            treeNode.addChild(moveArcMotionTemplate);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addDirectionNode(TreeNode treeNode) {
        ValueFactory valueFactory = MyCounterTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        MoveNode moveDirectionUntilNodeTemplate = factory.createMoveDirectionUntilNodeTemplate();
        MoveLinerConfigBuilder moveLConfigBuilder =
            moveDirectionUntilNodeTemplate.getConfigBuilderFactory().createMoveLConfigBuilder();
        moveLConfigBuilder.setToolSpeed(valueFactory.createSpeed(80.0D, Speed.Unit.MM_S));
        moveLConfigBuilder.setToolAcceleration(valueFactory.createAcceleration(15000, Acceleration.Unit.MM_S2));
        moveLConfigBuilder.setTCPSelection(
            moveDirectionUntilNodeTemplate.getTCPSelectionFactory().createIgnoreActiveTCPSelection());
        moveDirectionUntilNodeTemplate.setConfig(moveLConfigBuilder.build());
        try {
            treeNode.addChild(moveDirectionUntilNodeTemplate);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    protected JButton createBasicNodesBtn(MyCounterTaskNodeContribution taskNodeContribution) {
        JButton basicNodesBtn = new JButton(ResourceSupport.tr("BasicNodes"));
        basicNodesBtn.setPreferredSize(new Dimension(180, 50));
        basicNodesBtn.addActionListener(e -> {
            TreeNode treeNode = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel()
                .getContributionTreeNode(MyCounterTaskNodeView.this.contribution);
            MyCounterTaskNodeView.this.taskApiProvider.getUndoRedoManager().recordChanges(() -> {
                addFolderNode(treeNode);
            });
        });

        return basicNodesBtn;
    }

    protected void addFolderNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        FolderNode folderNode = factory.createFolderNode();
        folderNode.setDisplay("Hello world!");
        try {
            treeNode.addChild(folderNode);
            List<TreeNode> children = treeNode.getChildren();
            for (TreeNode treeNode1 : children) {
                if (treeNode1.getTaskNode().equals(folderNode)) {
                    addCommentNode(treeNode1);
                    addHaltNode(treeNode1);
                    addPopupNode(treeNode1);
                    addCommentNode(treeNode1);
                }
            }
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addPopupNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        PopupNode popupNode = factory.createPopupNode();
        popupNode.setMessage("Hello world!");
        popupNode.setMessageDialogType(MessageType.INFO);
        try {
            treeNode.addChild(popupNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addHaltNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        HaltNode haltNode = factory.createHaltNode();
        try {
            treeNode.addChild(haltNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addCommentNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        CommentNode commentNode = factory.createCommentNode();
        commentNode.setCommentString("Hello world!");
        try {
            treeNode.addChild(commentNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private JButton createLogicNodesBtn(MyCounterTaskNodeContribution taskNodeContribution) {
        JButton logicNodesBtn = new JButton(ResourceSupport.tr("LogicNodes"));
        logicNodesBtn.setPreferredSize(new Dimension(180, 50));
        logicNodesBtn.addActionListener(e -> {
            TreeNode treeNode = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel()
                .getContributionTreeNode(MyCounterTaskNodeView.this.contribution);
            addIfNode(treeNode);
        });

        return logicNodesBtn;
    }

    private void addIfNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        IfNode ifNode = factory.createIfNode();

        ExpressionService expressionService = MyCounterTaskNodeView.this.taskApiProvider.getExpressionService();
        List<IO> listIO = new ArrayList<>(
            MyCounterTaskNodeView.this.taskApiProvider.getIOModel().getIOs(IOFilterFactory.createAnalogInputFilter()));
        IO io = listIO.get(0);
        Expression expression;
        try {
            expression = expressionService.createExpressionConstructor().appendIOCell(io).appendTokenCell(" ?= ", "==")
                .appendTokenCell("10", "10").construct();
            ifNode.setExpression(expression);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ElseIfNode elseIfNode = factory.createElseIfNode();
        Expression expressionElseIf;
        try {
            expressionElseIf = expressionService.createExpressionConstructor().appendIOCell(io).appendTokenCell(" ?= ", "==")
                .appendTokenCell("15", "15").construct();
            elseIfNode.setExpression(expressionElseIf);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ElseIfNode elseIfNodeSec = factory.createElseIfNode();
        Expression expressionElseIf2;
        try {
            expressionElseIf2 = expressionService.createExpressionConstructor().appendIOCell(io).appendTokenCell(" ?= ", "==")
                .appendTokenCell("18", "15").construct();
            elseIfNodeSec.setExpression(expressionElseIf2);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ElseIfNode elseIfNodeThird = factory.createElseIfNode();
        Expression expressionElseIfThird;
        try {
            expressionElseIfThird = expressionService.createExpressionConstructor().appendIOCell(io).appendTokenCell(" ?= ", "==")
                .appendTokenCell("18", "15").construct();
            elseIfNodeThird.setExpression(expressionElseIfThird);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ElseNode elseNode = factory.createElseNode();

        MyCounterTaskNodeView.this.taskApiProvider.getUndoRedoManager().recordChanges(() -> {
            try {
                treeNode.addChild(ifNode);
                List<TreeNode> children = treeNode.getChildren();
                for (TreeNode treeNode1 : children) {
                    if (treeNode1.getTaskNode().equals(ifNode)) {
                        addLoopNode(treeNode1);
                    }
                }

                try {
                    treeNode.addChild(elseIfNode);
                } catch (TreeStructureException treeStructureException) {
                    treeStructureException.printStackTrace();
                }
                List<TreeNode> childrenElseIf = treeNode.getChildren();
                for (TreeNode treeNode1 : childrenElseIf) {
                    if (treeNode1.getTaskNode().equals(elseIfNode)) {
                        addCommentNode(treeNode1);
                    }
                }

                try {
                    treeNode.addChild(elseIfNodeSec);
                } catch (TreeStructureException treeStructureException) {
                    treeStructureException.printStackTrace();
                }

                try {
                    treeNode.addChild(elseIfNodeThird);
                } catch (TreeStructureException treeStructureException) {
                    treeStructureException.printStackTrace();
                }
                List<TreeNode> childrenElseIfThird = treeNode.getChildren();
                for (TreeNode treeNode1 : childrenElseIfThird) {
                    if (treeNode1.getTaskNode().equals(elseIfNodeSec)) {
                        addWaitNodes(treeNode1);
                    }
                }

                try {
                    treeNode.addChild(elseNode);
                } catch (TreeStructureException treeStructureException) {
                    treeStructureException.printStackTrace();
                }
                List<TreeNode> childrenElse = treeNode.getChildren();
                for (TreeNode treeNode1 : childrenElse) {
                    if (treeNode1.getTaskNode().equals(elseNode)) {
                        addPopupNode(treeNode1);
                    }
                }
            } catch (TreeStructureException treeStructureException) {
                treeStructureException.printStackTrace();
            }
        });

    }

    private void addLoopNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        LoopNode alwaysLoopNode = factory.createLoopNode();
        LoopNodeConfigFactory loopNodeConfigFactory = alwaysLoopNode.getConfigFactory();
        alwaysLoopNode.setConfig(loopNodeConfigFactory.createLoopNodeAlwaysLoopConfig());
        try {
            treeNode.addChild(alwaysLoopNode);
            List<TreeNode> children = treeNode.getChildren();
            for (TreeNode treeNode1 : children) {
                if (treeNode1.getTaskNode().equals(alwaysLoopNode)) {
                    addCommentNode(treeNode1);
                }
            }
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }

        LoopNode nTimesLoopNode = factory.createLoopNode();
        nTimesLoopNode.setConfig(loopNodeConfigFactory.createLoopNodeCounterConfig(15));
        try {
            treeNode.addChild(nTimesLoopNode);
            List<TreeNode> children = treeNode.getChildren();
            for (TreeNode treeNode1 : children) {
                if (treeNode1.getTaskNode().equals(nTimesLoopNode)) {
                    addAssignmentNode(treeNode1);
                }
            }
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }


        LoopNode expressionLoopNode = factory.createLoopNode();
        ExpressionService expressionService = MyCounterTaskNodeView.this.taskApiProvider.getExpressionService();
        List<IO> listIO = new ArrayList<>(taskApiProvider.getIOModel().getIOs(IOFilterFactory.createAnalogInputFilter()));
        IO io = listIO.get(0);
        Expression expression;
        try {
            expression = expressionService.createExpressionConstructor().appendIOCell(io).appendTokenCell(" ?= ", "==")
                .appendTokenCell("10", "10").construct();
            expressionLoopNode.setConfig(loopNodeConfigFactory.createExpressionConfig(expression, true));
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            treeNode.addChild(expressionLoopNode);
            List<TreeNode> children = treeNode.getChildren();
            for (TreeNode treeNode1 : children) {
                if (treeNode1.getTaskNode().equals(nTimesLoopNode)) {
                    addAssignmentNode(treeNode1);
                }
            }
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

    private void addAssignmentNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        AssignmentNode assignmentNode = factory.createAssignmentNode();
        AssignmentNodeConfigFactory assignmentNodeConfigFactory = assignmentNode.getConfigFactory();
        ExpressionService expressionService = MyCounterTaskNodeView.this.taskApiProvider.getExpressionService();
        List<IO> listIO = new ArrayList<>(taskApiProvider.getIOModel().getIOs(IOFilterFactory.createAnalogInputFilter()));
        IO io = listIO.get(0);
        Expression expression;
        try {
            expression = expressionService.createExpressionConstructor().appendIOCell(io).appendTokenCell(" ?= ", "==")
                .appendTokenCell("10", "10").construct();
            TaskVariable variable = MyCounterTaskNodeView.this.contribution.createGlobalVariable("Variable_77");
            assignmentNode.setConfig(assignmentNodeConfigFactory.createExpressionConfig(variable, expression));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addWaitNodes(TreeNode treeNode) {

        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        WaitNode noWaitNode = factory.createWaitNode();
        WaitNodeConfig config = noWaitNode.getWaitNodeConfigFactory().createNoWaitConfig();
        noWaitNode.setConfig(config);
        try {
            treeNode.addChild(noWaitNode);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }

        WaitNode timeWaitNode = factory.createWaitNode();
        Time oneSecondWait = MyCounterTaskNodeView.this.taskApiProvider.getValueFactory().createTime(1, Time.Unit.S);
        TimeConfig timeConfig = timeWaitNode.getWaitNodeConfigFactory().createTimeWaitNodeConfig(oneSecondWait);
        timeWaitNode.setConfig(timeConfig);
        List<TreeNode> children = treeNode.getChildren();
        TreeNode lastChild = children.get(children.size() > 0 ? children.size() - 1 : 0);
        if (lastChild != null) {
            try {
                treeNode.insertChildAfter(lastChild, timeWaitNode);
            } catch (TreeStructureException treeStructureException) {
                treeStructureException.printStackTrace();
            }
        }

        ExpressionService expressionService = taskApiProvider.getExpressionService();
        List<IO> listIO = new ArrayList<>(taskApiProvider.getIOModel().getIOs(IOFilterFactory.createDigitalInputFilter()));
        IO io = listIO.get(0);
        try {
            Expression expression = expressionService.createExpressionConstructor().appendIOCell(io).appendTokenCell("?=", "==")
                .appendTokenCell("True", "True").construct();
            ExpressionInputConfig expressionInputConfig =
                timeWaitNode.getWaitNodeConfigFactory().createExpressionConfig(expression);
            WaitNode expressionInputWaitNode = factory.createWaitNode();
            expressionInputWaitNode.setConfig(expressionInputConfig);

            children = treeNode.getChildren();
            lastChild = children.get(children.size() > 0 ? children.size() - 1 : 0);
            if (lastChild != null) {
                try {
                    treeNode.insertChildAfter(lastChild, expressionInputWaitNode);
                } catch (TreeStructureException treeStructureException) {
                    treeStructureException.printStackTrace();
                }
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void addSetNode(TreeNode treeNode) {
        TaskNodeFactory factory = MyCounterTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();
        SetNode noActionSet = factory.createSetNode();
        SetNodeConfigFactory setNodeConfigFactory = noActionSet.getConfigFactory();
        noActionSet.setConfig(setNodeConfigFactory.createNoActionConfig());
        try {
            treeNode.addChild(noActionSet);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
        SetNode digitalOutSet = factory.createSetNode();
        List<IO> listDO = new ArrayList<>(taskApiProvider.getIOModel().getIOs(IOFilterFactory.createDigitalOutputFilter()));
        IO out0 = listDO.get(0);
        digitalOutSet.setConfig(setNodeConfigFactory.createDigitalOutputConfig(out0, DigitalPinValueType.HIGH));
        try {
            treeNode.addChild(digitalOutSet);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }

        ValueFactory valueFactory = taskApiProvider.getValueFactory();
        SetNode analogOutVSet = factory.createSetNode();
        List<IO> listAO = new ArrayList<>(taskApiProvider.getIOModel().getIOs(IOFilterFactory.createAnalogOutputFilter()));
        IO out_1 = listAO.get(0);
        AnalogIO analogIO_1 = (AnalogIO) out_1;
        if (analogIO_1.isVoltage()) {
            try {
                analogOutVSet.setConfig(setNodeConfigFactory.createAnalogOutputVoltageConfig(analogIO_1,
                    valueFactory.createVoltage(8.0D, Voltage.Unit.V)));
                treeNode.addChild(analogOutVSet);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        SetNode analogOutCSet = factory.createSetNode();
        IO out_2 = listAO.get(1);
        AnalogIO analogIO_2 = (AnalogIO) out_2;
        if (analogIO_2.isCurrent()) {
            try {
                analogOutCSet.setConfig(setNodeConfigFactory.createAnalogOutputCurrentConfig(analogIO_2,
                    valueFactory.createCurrent(8.0D, Current.Unit.MA)));
                treeNode.addChild(analogOutCSet);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        SetNode outSet = factory.createSetNode();
        List<IO> listMB = new ArrayList<>(taskApiProvider.getIOModel().getIOs(IOFilterFactory.createDigitalOutputFilter()));
        IO mbIO = listMB.get(3);
        ExpressionService expressionService = MyCounterTaskNodeView.this.taskApiProvider.getExpressionService();
        try {
            outSet.setConfig(setNodeConfigFactory.createExpressionOutputConfig(mbIO,
                expressionService.createExpressionConstructor().appendIOCell(mbIO).appendTokenCell(" == ", " == ")
                    .appendTokenCell("True", "true").construct()));
            try {
                treeNode.addChild(outSet);
            } catch (TreeStructureException treeStructureException) {
                treeStructureException.printStackTrace();
            }
        } catch (IllegalExpressionException e) {
            e.printStackTrace();
        }

        SetNode digitalSet = factory.createSetNode();
        digitalSet.setConfig(setNodeConfigFactory.createSinglePulseDigitalOutputConfig((DigitalIO) listDO.get(1),
            valueFactory.createTime(2.0D, Time.Unit.S)));

        try {
            treeNode.addChild(digitalSet);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }
}
