package com.leon.leonT.impl.WeldTaskNode;

import cn.elibot.robot.plugin.contribution.task.TaskApiProvider;
import cn.elibot.robot.plugin.contribution.task.TaskNodeContribution;
import cn.elibot.robot.plugin.contribution.task.TaskNodeDataModelWrapper;
import cn.elibot.robot.plugin.domain.script.ScriptWriter;
import cn.elibot.robot.plugin.domain.task.TaskExtensionNodeViewProvider;
import cn.elibot.robot.plugin.domain.task.listener.ContributionInsertedListener;
import cn.elibot.robot.plugin.domain.task.listener.ContributionLoadCompletedListener;
import cn.elibot.robot.plugin.domain.task.listener.ContributionRemovedListener;
import cn.elibot.robot.plugin.domain.task.structure.TreeNode;
import com.leon.leonT.impl.resource.ResourceSupport;

import java.util.Locale;

public class LeonWeldTaskNodeContribution implements TaskNodeContribution, ContributionInsertedListener, ContributionRemovedListener, ContributionLoadCompletedListener {
    private final TaskApiProvider taskApiProvider;

    public LeonWeldTaskNodeContribution(TaskApiProvider taskApiProvider, TaskNodeDataModelWrapper taskNodeDataModelWrapper) {
        this.taskApiProvider = taskApiProvider;
        TreeNode treeNode = this.taskApiProvider.getTaskModel().getContributionTreeNode(this);
    }

    @Override
    public String getTitle() {
        return "";
    }

    @Override
    public String getDisplayOnTree(Locale locale) {
//        Variable variable = getSelectedVariable();
//        if (variable == null) {
//            return ResourceSupport.tr(locale, "Counter") + " : " + ResourceSupport.tr(locale, "NullVariable");
//        } else {
//            return ResourceSupport.tr(locale, "Counter") + " : " + variable.getDisplayName();
//        }
        return ResourceSupport.tr("TaskNodeTest");
    }

    @Override
    public boolean isDefined() {
//        // 判断前置点/焊接点/后置点至少有一组数据，满足即判定完成
//        boolean hasPre = !CollectionUtils.isEmpty(prePoints);
//        boolean hasWeld = !CollectionUtils.isEmpty(weldPoints);
//        boolean hasPost = !CollectionUtils.isEmpty(postPoints);
        // 有任意点位就代表配置完毕
//        return hasPre || hasWeld || hasPost;
        return true;
    }

    @Override
    public void setTaskNodeContributionViewProvider(TaskExtensionNodeViewProvider taskExtensionNodeViewProvider) {

    }

    @Override
    public void onViewOpen() {

    }

    @Override
    public void onViewClose() {

    }

    @Override
    public void generateScript(ScriptWriter scriptWriter) {

        scriptWriter.appendLine("sleep(0.01)");

        scriptWriter.writeChildren();
    }
}
