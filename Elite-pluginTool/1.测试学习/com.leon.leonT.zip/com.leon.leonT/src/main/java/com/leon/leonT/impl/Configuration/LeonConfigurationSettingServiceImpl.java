package com.leon.leonT.impl.Configuration;

import cn.elibot.robot.plugin.contribution.configuration.ConfigurationAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.ConfigurationViewAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.ContributionConfiguration;
import cn.elibot.robot.plugin.contribution.configuration.SwingConfigurationNodeService;
import cn.elibot.robot.plugin.domain.data.DataModelWrapper;
import com.leon.leonT.impl.resource.ResourceSupport;

import java.util.Locale;

public class LeonConfigurationSettingServiceImpl implements SwingConfigurationNodeService<LeonConfigurationContribution,LeonConfigurationNodeView> {
    @Override
    public void configureContribution(ContributionConfiguration contributionConfiguration) {

    }

    @Override
    public String getTitle(Locale locale) {
        String title = "ConfigurationPlugin";
        return ResourceSupport.tr(locale, title);
    }

    @Override
    public LeonConfigurationNodeView createView(ConfigurationViewAPIProvider configurationViewAPIProvider) {
        /*
        * 使用外部的一个Style来控制整体控件的通用布局
        * */
        return new LeonConfigurationNodeView(new Style(), configurationViewAPIProvider);
    }

    @Override
    public LeonConfigurationContribution createConfigurationNode(ConfigurationAPIProvider configurationAPIProvider, LeonConfigurationNodeView leonConfigurationNodeView, DataModelWrapper dataModelWrapper) {
        /*
        * 创建一个带有configurationapi，界面以及数据持久化的内容
        * */
        return new LeonConfigurationContribution(configurationAPIProvider,leonConfigurationNodeView,dataModelWrapper);
    }
}
