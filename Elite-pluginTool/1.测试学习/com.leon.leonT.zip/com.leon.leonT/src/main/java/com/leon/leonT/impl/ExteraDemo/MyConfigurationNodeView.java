package com.leon.leonT.impl.ExteraDemo;

import cn.elibot.robot.plugin.contribution.configuration.ConfigurationViewAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.SwingConfigurationNodeView;
import cn.elibot.robot.plugin.domain.robot.RobotMovementService;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveCallback;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveCancelEvent;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveCompleteEvent;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveErrorEvent;
import cn.elibot.robot.plugin.domain.robot.setposition.SetPositionCallback;
import cn.elibot.robot.plugin.domain.robot.setposition.SetPositionCompleteEvent;
import cn.elibot.robot.plugin.domain.utils.PoseUtils;
import cn.elibot.robot.plugin.domain.value.Angle;
import cn.elibot.robot.plugin.domain.value.Length;
import cn.elibot.robot.plugin.domain.value.Pose;
import cn.elibot.robot.plugin.ui.model.BaseKeyboardCallback;
import com.leon.leonT.impl.Configuration.Style;
import com.leon.leonT.impl.resource.ResourceSupport;

import javax.swing.*;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * @author ELITECO SDK API
 */
public class MyConfigurationNodeView implements SwingConfigurationNodeView<MyConfigurationContribution> {
    private final Style style;
    private final ConfigurationViewAPIProvider configurationViewApiProvider;
    private JTextField jTextField;

    public MyConfigurationNodeView(Style style, ConfigurationViewAPIProvider configurationViewApiProvider) {
        this.style = style;
        this.configurationViewApiProvider = configurationViewApiProvider;
    }

    @Override
    public void buildUI(JPanel jPanel, final MyConfigurationContribution configurationContribution) {
        jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));
        jPanel.add(createInfo());
        jPanel.add(createVerticalSpacing());
        jPanel.add(createInput(configurationContribution));
        jPanel.add(createVerticalSpacing());

        JButton moveToTarget = new JButton(ResourceSupport.tr("MoveToTarget"));
        moveToTarget.setPreferredSize(new Dimension(160, 40));
        moveToTarget.setMinimumSize(new Dimension(160, 40));
        moveToTarget.setMaximumSize(new Dimension(160, 40));
        moveToTarget.addActionListener(e -> {
            double[] pose = new double[6];
            pose[0] = -154;
            pose[1] = -19;
            pose[2] = 905;
            pose[3] = -68;
            pose[4] = -11;
            pose[5] = -110;
            Pose target = PoseUtils.newPose(pose, Length.Unit.MM, Angle.Unit.DEG);

            configurationViewApiProvider.getConfigurationAPIProvider().getRobotMovementService()
                .requestUserToMoveRobot(target, new AutoMoveCallback() {
                    @Override
                    public void onComplete(AutoMoveCompleteEvent autoMoveCompleteEvent) {
                        System.out.println("On continue");
                        System.out.println("Is at target position: " + autoMoveCompleteEvent.isAtTargetPosition());
                    }

                    @Override
                    public void onCancel(AutoMoveCancelEvent autoMoveCancelEvent) {
                        System.out.println("On cancel");
                        System.out.println("Is at target position: " + autoMoveCancelEvent.isAtTargetPosition());
                    }

                    @Override
                    public void onError(AutoMoveErrorEvent autoMoveErrorEvent) {
                        System.out.println("On Error");
                        System.out.println("Error type: " + autoMoveErrorEvent.getErrorType());
                    }
                });
        });
        jPanel.add(moveToTarget);
        jPanel.add(createVerticalSpacing());

        JButton setRobotPosition = new JButton(ResourceSupport.tr("SetRobotPosition"));
        setRobotPosition.setPreferredSize(new Dimension(160, 40));
        setRobotPosition.setMinimumSize(new Dimension(160, 40));
        setRobotPosition.setMaximumSize(new Dimension(160, 40));
        setRobotPosition.addActionListener(e -> configurationViewApiProvider.getConfigurationAPIProvider().getRobotMovementService()
            .requestUserToSetPosition(new RobotMovementService.ViewState(), new SetPositionCallback() {
                @Override
                public void onComplete(SetPositionCompleteEvent setPositionCompleteEvent) {
                    System.out.println("Set robot position on complete.");
                }
            }));
        jPanel.add(setRobotPosition);
        jPanel.add(createVerticalSpacing());

        JButton setDataModel = new JButton(ResourceSupport.tr("SetData"));
        setDataModel.setPreferredSize(new Dimension(160, 40));
        setDataModel.setMinimumSize(new Dimension(160, 40));
        setDataModel.setMaximumSize(new Dimension(160, 40));
        setDataModel.addActionListener(e -> configurationContribution.setDefaultValue());
        jPanel.add(setDataModel);

        JButton setDataModel2 = new JButton(ResourceSupport.tr("SetData"));
        setDataModel.setPreferredSize(new Dimension(160, 40));
        setDataModel.setMinimumSize(new Dimension(160, 40));
        setDataModel.setMaximumSize(new Dimension(160, 40));
        setDataModel.addActionListener(e -> configurationContribution.setDefaultValue());
        jPanel.add(setDataModel2);
    }

    private Box createInfo() {
        Box infoBox = Box.createVerticalBox();
        infoBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextPane pane = new JTextPane();
        pane.setBorder(BorderFactory.createEmptyBorder());
        SimpleAttributeSet attributeSet = new SimpleAttributeSet();
        StyleConstants.setLineSpacing(attributeSet, 0.5f);
        StyleConstants.setLeftIndent(attributeSet, 0f);
        pane.setParagraphAttributes(attributeSet, false);
        pane.setText(ResourceSupport.tr("Describe"));
        pane.setEditable(false);
        pane.setMaximumSize(pane.getPreferredSize());
        pane.setBackground(infoBox.getBackground());
        infoBox.add(pane);
        return infoBox;
    }

    private Box createInput(final MyConfigurationContribution myConfigurationContribution) {
        Box inputBox = Box.createHorizontalBox();
        inputBox.setAlignmentX(Component.LEFT_ALIGNMENT);

        inputBox.add(new JLabel(ResourceSupport.tr("ConfigurationVariable")));
        inputBox.add(createHorizontalSpacing());

        jTextField = new JTextField();
        jTextField.setFocusable(false);
        jTextField.setPreferredSize(style.getInputFieldSize());
        jTextField.setMaximumSize(jTextField.getPreferredSize());
        jTextField.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseReleased(MouseEvent e) {
                configurationViewApiProvider.getConfigurationAPIProvider().getComponentHubService().getKeyboardService()
                    .showLetterKeyboard(jTextField.getText(), "", new BaseKeyboardCallback() {
                        @Override
                        public void onOk(Object value) {
                            jTextField.setText((String) value);
                            myConfigurationContribution.setConfigVarValue((String) value);
                        }
                    });
            }
        });
        inputBox.add(jTextField);

        return inputBox;
    }

    private Component createHorizontalSpacing() {
        return Box.createRigidArea(new Dimension(style.getHorizontalSpacing(), 0));
    }

    private Component createVerticalSpacing() {
        return Box.createRigidArea(new Dimension(0, style.getVerticalSpacing()));
    }

    public void setPopupText(String t) {
        jTextField.setText(t);
    }

    @Override
    public void contributionViewDestruction() {

    }
}
