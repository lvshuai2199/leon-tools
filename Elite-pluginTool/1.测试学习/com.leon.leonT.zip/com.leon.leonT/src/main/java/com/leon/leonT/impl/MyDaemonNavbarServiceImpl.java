package com.leon.leonT.impl;

import cn.elibot.robot.plugin.contribution.navbar.NavbarContext;
import cn.elibot.robot.plugin.contribution.navbar.NavbarContribution;
import cn.elibot.robot.plugin.contribution.navbar.NavbarService;
import com.leon.leonT.impl.resource.ImageHelper;
import com.leon.leonT.impl.resource.ResourceSupport;

public class MyDaemonNavbarServiceImpl implements NavbarService {
    private final MyDaemonServiceImpl daemonService;
    private MyDaemonViewImpl myDaemonView;

    public MyDaemonNavbarServiceImpl(MyDaemonServiceImpl daemonService) {
        this.daemonService = daemonService;
    }

    @Override
    public void configure(NavbarContext navbarContext) {
        navbarContext.setNavbarIcon(ImageHelper.loadImage("daemon.png"));
        navbarContext.setNavbarName(ResourceSupport.tr("plugin_title"));
    }

    @Override
    public NavbarContribution createContribution() {
        if (myDaemonView == null) {
            myDaemonView = new MyDaemonViewImpl(this.daemonService);
        }
        return myDaemonView;
    }
}
