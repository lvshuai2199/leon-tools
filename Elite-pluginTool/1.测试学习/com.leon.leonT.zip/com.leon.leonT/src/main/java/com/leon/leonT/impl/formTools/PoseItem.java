package com.leon.leonT.impl.formTools;


/**
 * 点位实体：前置安全点 / 焊接点 / 后置安全点共用
 */
class PoseItem {
    // 点位名称 例如：焊接点1、前置安全点2
    public String name;
    // 机器人笛卡尔位姿 x,y,z,rx,ry,rz
//    public RobotPose pose;
//
//    public PoseItem(String name, RobotPose pose) {
//        this.name = name;
//        this.pose = pose;
//    }
}