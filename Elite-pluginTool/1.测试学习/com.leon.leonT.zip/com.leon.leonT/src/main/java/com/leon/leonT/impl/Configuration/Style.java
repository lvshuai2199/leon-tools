package com.leon.leonT.impl.Configuration;

import java.awt.*;

public class Style {
    private static final int HORIZONTAL_SPACING = 10;
    private static final int VERTICAL_SPACING = 10;

    public int getHorizontalSpacing() {
        return HORIZONTAL_SPACING;
    }

    public int getVerticalSpacing() {
        return VERTICAL_SPACING;
    }

    public Dimension getInputFieldSize() {
        return new Dimension(200, 30);
    }
}
