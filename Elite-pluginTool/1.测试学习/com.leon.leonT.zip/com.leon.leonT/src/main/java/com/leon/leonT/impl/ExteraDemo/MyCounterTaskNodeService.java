package com.leon.leonT.impl.ExteraDemo;


import cn.elibot.robot.plugin.contribution.task.*;
import com.leon.leonT.impl.resource.ResourceSupport;

import java.util.Locale;

public class MyCounterTaskNodeService implements SwingTaskNodeService<MyCounterTaskNodeContribution, MyCounterTaskNodeView> {
    @Override
    public String getId() {
        return "Counter";
    }

    @Override
    public String getTypeName(Locale locale) {
        return ResourceSupport.tr(locale, "Counter");
    }

    @Override
    public void configureContribution(TaskNodeFeatures taskNodeFeatures) {
        taskNodeFeatures.setChildrenAllowed(true);
        taskNodeFeatures.setDeprecated(false);
        taskNodeFeatures.setUserInsertable(true);
        taskNodeFeatures.setPlaceHolderRequired(false);
    }

    @Override
    public MyCounterTaskNodeView createView(TaskNodeViewApiProvider taskNodeViewApiProvider) {
        return new MyCounterTaskNodeView(taskNodeViewApiProvider);
    }

    @Override
    public MyCounterTaskNodeContribution createNode(TaskApiProvider taskApiProvider, TaskNodeDataModelWrapper taskNodeDataModelWrapper, boolean isCloningOrLoading) {
        return new MyCounterTaskNodeContribution(taskApiProvider, taskNodeDataModelWrapper);
    }
}
