package com.leon.leonT.impl.Nav;

import cn.elibot.robot.plugin.contribution.navbar.NavbarContext;
import cn.elibot.robot.plugin.contribution.navbar.NavbarContribution;
import cn.elibot.robot.plugin.contribution.navbar.NavbarService;
import com.leon.leonT.impl.MyDaemonServiceImpl;
import com.leon.leonT.impl.resource.ImageHelper;
import com.leon.leonT.impl.resource.ResourceSupport;

public class LeonNavbarServiceImpl implements NavbarService {

    private final MyDaemonServiceImpl daemonService;

    public LeonNavbarServiceImpl(MyDaemonServiceImpl daemonService) {
        this.daemonService = daemonService;
    }

    @Override
    public void configure(NavbarContext navbarContext) {
        navbarContext.setNavbarIcon(ImageHelper.loadImage("navbar.png"));
        navbarContext.setNavbarName(ResourceSupport.tr("welcomeNote"));
    }

    @Override
    public NavbarContribution createContribution() {
        return new LeonNavbarContributionImpl(this.daemonService);
    }
}
