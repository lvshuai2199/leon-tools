package com.leon.leonT.impl.Configuration;

import cn.elibot.robot.plugin.contribution.configuration.ConfigurationAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.ConfigurationNodeContribution;
import cn.elibot.robot.plugin.domain.data.DataModelWrapper;
import cn.elibot.robot.plugin.domain.script.ScriptWriter;
import cn.elibot.robot.plugin.domain.tcp.TCP;
import cn.elibot.robot.plugin.domain.value.*;

import java.util.Arrays;

public class LeonConfigurationContribution implements ConfigurationNodeContribution {
    private final DataModelWrapper model;

    public LeonConfigurationContribution(ConfigurationAPIProvider configurationAPIProvider, LeonConfigurationNodeView leonConfigurationNodeView, DataModelWrapper dataModelWrapper) {
        this.model = dataModelWrapper;
    }

    public DataModelWrapper getModel() {
        return this.model;
    }

    @Override
    public void onViewOpen() {

    }

    @Override
    public void onViewClose() {

    }

    @Override
    public void generateScript(ScriptWriter scriptWriter) {

    }

    @Override
    public void onModelChanged() {
        getDefaultValue();
    }

    public void getDefaultValue() {
        System.out.println("=========================================");
        System.out.println("Data model is changed. Show current data.");
        System.out.println("testInt: " + this.getModel().getInteger("testInt"));
        System.out.println("testDouble: " + this.getModel().getDouble("testDouble"));
        System.out.println("testBool: " + this.getModel().getBoolean("testBool"));
        System.out.println("testData: " + this.getModel().getData("testData", null));
        System.out.println("testString: " + this.getModel().getString("testString"));
        System.out.println("testBytes: " + Arrays.toString(this.getModel().get("testBytes", new byte[] {0})));
        System.out.println("testChars: " + Arrays.toString(this.getModel().get("testChars", new char[] {0})));
        System.out.println("testInts: " + Arrays.toString(this.getModel().get("testInts", new int[] {0})));
        System.out.println("testLongs: " + Arrays.toString(this.getModel().get("testLongs", new long[] {0})));
        System.out.println("testShorts: " + Arrays.toString(this.getModel().get("testShorts", new short[] {0})));
        System.out.println("testBooleans: " + Arrays.toString(this.getModel().get("testBooleans", new boolean[] {false})));
        System.out.println("testFloats: " + Arrays.toString(this.getModel().get("testFloats", new float[] {0.f})));
        System.out.println("testDoubles: " + Arrays.toString(this.getModel().get("testDoubles", new double[] {0})));
        System.out.println("testStrings: " + Arrays.toString(this.getModel().get("testStrings", new String[] {""})));
        System.out.println("*****************************************");
        System.out.println("*****************************************");

        TCP tcp = this.getModel().getTCP("TcpData");
        System.out.println("TcpData: " + tcp);

        Pose pose = this.getModel().getPose("PoseData");
        System.out.println("PoseData: " + pose);

        Acceleration acceleration = this.getModel().getAcceleration("AccelerationData");
        System.out.println("AccelerationData: " + acceleration);

        Angle angle = this.getModel().getAngle("AngleData");
        System.out.println("AngleData: " + angle);

        AngularAcceleration angularAcceleration = this.getModel().getAngularAcceleration("AngularAccelerationData");
        System.out.println("AngularAccelerationData: " + angularAcceleration);

        AngularSpeed angularSpeed = this.getModel().getAngularSpeed("AngularSpeedData");
        System.out.println("AngularSpeedData: " + angularSpeed);

        Current current = this.getModel().getCurrent("CurrentData");
        System.out.println("CurrentData: " + current);

        Force force = this.getModel().getForce("ForceData");
        System.out.println("ForceData: " + force);

        JointPosition jointPosition = this.getModel().getJointPosition("JointPositionData");
        System.out.println("JointPositionData: " + jointPosition);

        JointPositions jointPositions = this.getModel().getJointPositions("JointPositionsData");
        System.out.println("JointPositionsData: " + jointPositions);

        Length length = this.getModel().getLength("LengthData");
        System.out.println("LengthData: " + length);

        Momentum momentum = this.getModel().getMomentum("MomentumData");
        System.out.println("MomentumData: " + momentum);

        Position position = this.getModel().getPosition("PositionData");
        System.out.println("PositionData: " + position);

        Power power = this.getModel().getPower("PowerData");
        System.out.println("PowerData: " + power);

        Pressure pressure = this.getModel().getPressure("PressureData");
        System.out.println("PressureData: " + pressure);

        Rotation rotation = this.getModel().getRotation("RotationData");
        System.out.println("RotationData: " + rotation);

        Speed speed = this.getModel().getSpeed("SpeedData");
        System.out.println("SpeedData: " + speed);

        Time time = this.getModel().getTime("TimeData");
        System.out.println("TimeData: " + time);

        Torque torque = this.getModel().getTorque("TorqueData");
        System.out.println("TorqueData: " + torque);

        Voltage voltage = this.getModel().getVoltage("VoltageData");
        System.out.println("VoltageData: " + voltage);

        System.out.println("*****************************************");
        System.out.println("*****************************************");
        System.out.println("=========================================");
    }

    @Override
    public void contributionDestruction() {

    }
}
