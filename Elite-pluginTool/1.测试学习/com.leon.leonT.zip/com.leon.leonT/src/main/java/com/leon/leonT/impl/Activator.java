package com.leon.leonT.impl;

import cn.elibot.robot.commons.lang.resource.LocaleProvider;
import cn.elibot.robot.plugin.contribution.configuration.SwingConfigurationNodeService;
import cn.elibot.robot.plugin.contribution.daemon.DaemonService;
import cn.elibot.robot.plugin.contribution.navbar.NavbarService;
import cn.elibot.robot.plugin.contribution.task.SwingTaskNodeService;
import com.leon.leonT.impl.Configuration.LeonConfigurationSettingServiceImpl;
import com.leon.leonT.impl.ExteraDemo.MyConfigurationSettingServiceImpl;
import com.leon.leonT.impl.ExteraDemo.MyCounterTaskNodeService;
import com.leon.leonT.impl.Nav.LeonNavbarServiceImpl;
import com.leon.leonT.impl.WeldTaskNode.LeonWeldTaskNodeService;
import com.leon.leonT.impl.resource.ResourceSupport;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.framework.ServiceRegistration;

/**
 * Activator for the OSGi bundle com.leon.leonT.impl contribution
 */
public class Activator implements BundleActivator {
    private ServiceReference<LocaleProvider> localeProviderServiceReference;
    private ServiceRegistration<SwingConfigurationNodeService> registration;
    private ServiceRegistration<SwingConfigurationNodeService> registration2;
    private ServiceRegistration<SwingTaskNodeService> taskegistration;
    private ServiceRegistration<SwingTaskNodeService> weldtaskegistration;
    private ServiceRegistration<DaemonService> daemon;


    @Override
    public void start(BundleContext bundleContext) throws Exception {
        localeProviderServiceReference = bundleContext.getServiceReference(LocaleProvider.class);
        if (localeProviderServiceReference != null) {
            LocaleProvider localeProvider = bundleContext.getService(localeProviderServiceReference);
            if (localeProvider != null) {
                ResourceSupport.setLocaleProvider(localeProvider);
            }
        }


        this.registration = bundleContext.registerService(SwingConfigurationNodeService.class, new LeonConfigurationSettingServiceImpl(), null);
        this.registration2 = bundleContext.registerService(SwingConfigurationNodeService.class, new MyConfigurationSettingServiceImpl(), null);
        this.taskegistration = bundleContext.registerService(SwingTaskNodeService.class, new MyCounterTaskNodeService(), null);
        this.weldtaskegistration = bundleContext.registerService(SwingTaskNodeService.class, new LeonWeldTaskNodeService(),null);
        MyDaemonServiceImpl daemonService = new MyDaemonServiceImpl();
        this.daemon = bundleContext.registerService(DaemonService.class, daemonService, null);
        bundleContext.registerService(NavbarService.class, new MyDaemonNavbarServiceImpl(daemonService), null);
        bundleContext.registerService(NavbarService.class, new LeonNavbarServiceImpl(daemonService), null);
        System.out.println("com.leon.leonT.impl.Activator says Hello World!");
    }


    @Override
    public void stop(BundleContext bundleContext) throws Exception {
        this.registration.unregister();
        this.registration2.unregister();
        this.taskegistration.unregister();
        this.daemon.unregister();
        System.out.println("com.leon.leonT.impl.Activator says Goodbye World!");
    }
}
