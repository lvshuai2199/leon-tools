package com.leon.leonT.impl.Configuration;

import cn.elibot.robot.plugin.contribution.configuration.ConfigurationViewAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.SwingConfigurationNodeView;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class LeonConfigurationNodeView implements SwingConfigurationNodeView<LeonConfigurationContribution> {

    private final Style style;
    private final ConfigurationViewAPIProvider configurationViewApiProvider;

    public LeonConfigurationNodeView(Style style, ConfigurationViewAPIProvider configurationViewApiProvider) {
        this.style = style;
        this.configurationViewApiProvider = configurationViewApiProvider;
    }

    // 用于存放所有布局
    private JPanel contentPanel; // 用于存放所有页面的容器
    private CardLayout cardLayout; // 卡片布局管理器 // 卡片布局管理器
    @Override
    public void contributionViewDestruction() {

    }


    @Override
    public void buildUI(JPanel jPanel, final LeonConfigurationContribution leonConfigurationContribution) {

        // 3. 中间内容区：使用 CardLayout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);

        // 向 CardLayout 中添加不同的页面
        contentPanel.add(createMainMenuPage(), "MainMenu");
        contentPanel.add(createProcessParamPage(), "ProcessParams");
        contentPanel.add(createWelderSettingPage(), "WelderSettings");

        jPanel.add(contentPanel, BorderLayout.CENTER);

    }



    /**
     * 创建主菜单页面（第一层级）
     */
    private JPanel createMainMenuPage() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 50, 100));

        // 模块1：工艺参数
        JButton btnProcess = createModuleButton("工艺参数", new Color(9, 132, 227));
        btnProcess.addActionListener(e -> cardLayout.show(contentPanel, "ProcessParams"));

        // 模块2：焊机设置
        JButton btnWelder = createModuleButton("焊机设置", new Color(0, 184, 148));
        btnWelder.addActionListener(e -> cardLayout.show(contentPanel, "WelderSettings"));



        panel.add(btnProcess);
        panel.add(btnWelder);
        return panel;
    }

    /**
     * 创建工艺参数页面（第二层级 - 表格）
     */
    private JPanel createProcessParamPage() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // 页面标题
        JLabel pageTitle = new JLabel("工艺参数列表");
        pageTitle.setFont(new Font("微软雅黑", Font.BOLD, 18));
        panel.add(pageTitle, BorderLayout.NORTH);

        // 表格数据
        String[] columnNames = {"编号", "参数名称", "设定值", "单位", "备注"};
        Object[][] data = {
                {"001", "焊接电流", "120", "A", "稳定输出"},
                {"002", "焊接电压", "24", "V", "自动调节"},
                {"003", "送丝速度", "8.5", "m/min", ""},
                {"004", "保护气体流量", "15", "L/min", "氩气"}
        };
        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // 底部按钮栏
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnBack = new JButton("返回主菜单");
        btnBack.addActionListener(e -> cardLayout.show(contentPanel, "MainMenu"));
        JButton saveWeldParamBtn = new JButton("工艺参数存储");
        saveWeldParamBtn.addActionListener(e -> cardLayout.show(contentPanel, "MainMenu"));

        bottomBar.add(saveWeldParamBtn);
        bottomBar.add(btnBack);
        panel.add(bottomBar, BorderLayout.SOUTH);

        return panel;
    }

    /**
     * 创建焊机设置页面（占位）
     */
    private JPanel createWelderSettingPage() {
        JPanel panel = new JPanel(new GridBagLayout());
        JLabel label = new JLabel("焊机设置功能开发中...");
        JButton btnBack = new JButton("返回");
        btnBack.addActionListener(e -> cardLayout.show(contentPanel, "MainMenu"));

        panel.add(label);
        panel.add(btnBack);
        return panel;
    }

    /**
     * 辅助工具：创建一个方形的模块按钮
     */
    private JButton createModuleButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(150, 150)); // 设置为正方形
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setFont(new Font("微软雅黑", Font.BOLD, 16));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

}
