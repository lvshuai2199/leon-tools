package com.leon.leonT.impl.WeldTaskNode;

import cn.elibot.robot.plugin.contribution.task.*;
import com.leon.leonT.impl.resource.ResourceSupport;

import java.util.Locale;

public class LeonWeldTaskNodeService implements SwingTaskNodeService<LeonWeldTaskNodeContribution,LeonWeldTaskNodeView> {
    @Override
    public String getId() {
        return "weld-id";
    }

    @Override
    public String getTypeName(Locale locale) {
        String typeName = "TaskNodeTest";
        return ResourceSupport.tr(locale, typeName);
    }

    @Override
    public void configureContribution(TaskNodeFeatures taskNodeFeatures) {
        taskNodeFeatures.setChildrenAllowed(true);
        taskNodeFeatures.setDeprecated(false);
        taskNodeFeatures.setUserInsertable(true);
        taskNodeFeatures.setPlaceHolderRequired(false);
    }

    @Override
    public LeonWeldTaskNodeView createView(TaskNodeViewApiProvider taskNodeViewApiProvider) {
        return new LeonWeldTaskNodeView(taskNodeViewApiProvider);
    }

    @Override
    public LeonWeldTaskNodeContribution createNode(TaskApiProvider taskApiProvider, TaskNodeDataModelWrapper taskNodeDataModelWrapper, boolean b) {
        return new LeonWeldTaskNodeContribution(taskApiProvider,taskNodeDataModelWrapper);
    }
}
