package com.leon.leonT.impl.ExteraDemo;

import cn.elibot.robot.plugin.contribution.configuration.ConfigurationAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.ConfigurationViewAPIProvider;
import cn.elibot.robot.plugin.contribution.configuration.ContributionConfiguration;
import cn.elibot.robot.plugin.contribution.configuration.SwingConfigurationNodeService;
import cn.elibot.robot.plugin.domain.data.DataModelWrapper;
import com.leon.leonT.impl.Configuration.Style;
import com.leon.leonT.impl.resource.ResourceSupport;

import java.util.Locale;

/**
 * @author ELITECO SDK API
 */
public class MyConfigurationSettingServiceImpl
    implements SwingConfigurationNodeService<MyConfigurationContribution, MyConfigurationNodeView> {
    @Override
    public void configureContribution(ContributionConfiguration contributionConfiguration) {
    }

    @Override
    public String getTitle(Locale locale) {
        String title = "testConfigurationPlugin";
        return ResourceSupport.tr(locale, title);
    }

    @Override
    public MyConfigurationNodeView createView(ConfigurationViewAPIProvider viewApiProvider) {
        return new MyConfigurationNodeView(new Style(), viewApiProvider);
    }

    @Override
    public MyConfigurationContribution createConfigurationNode(ConfigurationAPIProvider configurationApiProvider,
                                                               MyConfigurationNodeView myConfigurationContributionView,
                                                               DataModelWrapper context) {
        return new MyConfigurationContribution(configurationApiProvider, myConfigurationContributionView, context);
    }
}
