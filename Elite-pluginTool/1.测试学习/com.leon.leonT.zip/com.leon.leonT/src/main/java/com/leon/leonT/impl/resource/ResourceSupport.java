package com.leon.leonT.impl.resource;


import cn.elibot.robot.commons.lang.resource.LocaleProvider;
import cn.elibot.robot.commons.lang.resource.UTF8Control;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * @author ELITECO SDK API
 */
public class ResourceSupport {
    private static final String PROPERTIES = "i18n.text";
    private static LocaleProvider provider;
    private static ResourceBundle defaultResourceBundle = null;

    public static void setLocaleProvider(LocaleProvider provider) {
        ResourceSupport.provider = provider;
    }

    public static String tr(String key) {
        try {
            if (defaultResourceBundle == null) {
                defaultResourceBundle = ResourceBundle.getBundle(PROPERTIES, provider.getLocale(), new UTF8Control());
            }
            return defaultResourceBundle.getString(key);
        } catch (Exception e) {
            return "!" + key;
        }
    }

    public static String tr(Locale locale, String key) {
        try {
            ResourceBundle resourceBundle = ResourceBundle.getBundle(PROPERTIES, locale, new UTF8Control());
            return resourceBundle.getString(key);
        } catch (Exception e) {
            return "!" + key;
        }
    }
}