package com.leon.leonT.impl.domain;

import cn.elibot.robot.plugin.domain.utils.JointPositionsUtils;
import cn.elibot.robot.plugin.domain.utils.PoseUtils;
import cn.elibot.robot.plugin.domain.value.JointPositions;
import cn.elibot.robot.plugin.domain.value.Pose;

public class WeldPoint {
    private Integer pointType;

    //点位名称
    private String pointName;

    //机器人TCP位姿
    Pose pose;

    JointPositions jointPositions;

    public String getPointName() {
        return pointName;
    }

    public void setPointName(String pointName) {
        this.pointName = pointName;
    }

    public Pose getPose() {
        return pose;
    }

    public void setPose(Pose pose) {
        this.pose = PoseUtils.newPose(pose);
    }

    public JointPositions getJointPositions() {
        return jointPositions;
    }

    public void setJointPositions(JointPositions jointPositions) {
        // 增加判空保护
        if (jointPositions == null) {
            System.err.println("警告：传入JointPositions为null，不执行复制");
            return;
        }
//        this.jointPositions.setJointPosition(JointType.BASE, jointPositions.getJointPosition(JointType.BASE).getPosition(Angle.Unit.DEG));
//        this.jointPositions.setJointPosition(JointType.SHOULDER, jointPositions.getJointPosition(JointType.SHOULDER));
//        this.jointPositions.setJointPosition(JointType.ELBOW, jointPositions.getJointPosition(JointType.ELBOW));
//        this.jointPositions.setJointPosition(JointType.WRIST1, jointPositions.getJointPosition(JointType.WRIST1));
//        this.jointPositions.setJointPosition(JointType.WRIST2, jointPositions.getJointPosition(JointType.WRIST2));
//        this.jointPositions.setJointPosition(JointType.WRIST3, jointPositions.getJointPosition(JointType.WRIST3));
        // 替代你6行set，可以直接整体拷贝
        this.jointPositions = JointPositionsUtils.newJointPositions(jointPositions);
    }
}
