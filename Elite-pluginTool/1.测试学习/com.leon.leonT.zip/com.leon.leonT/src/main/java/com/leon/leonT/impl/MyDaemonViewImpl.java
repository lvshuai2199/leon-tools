package com.leon.leonT.impl;


import cn.elibot.robot.plugin.contribution.daemon.DaemonContribution;
import cn.elibot.robot.plugin.contribution.navbar.NavbarContribution;
import cn.elibot.robot.plugin.ui.SwingService;
import cn.elibot.robot.plugin.ui.model.BaseKeyboardCallback;
import com.leon.leonT.impl.formTools.FormTools;
import com.leon.leonT.impl.resource.ResourceSupport;
import org.apache.xmlrpc.XmlRpcException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MyDaemonViewImpl implements NavbarContribution {

    private final MyDaemonServiceImpl daemonService;
    private final XmlRpcMyDaemonFacade xmlRpcMyDaemonFacade;
//    private final String host = "127.0.0.1";
    private final String host = "127.0.0.1";
    private final int rpcPort = 3333;
    private JButton startButton;
    private JButton stopButton;
    private JTextField textField;


    public MyDaemonViewImpl(MyDaemonServiceImpl daemonService) {
        this.daemonService = daemonService;
        this.xmlRpcMyDaemonFacade = new XmlRpcMyDaemonFacade(host, rpcPort);
    }

    @Override
    public void buildUI(JPanel panel) {

        panel.setLayout(new GridBagLayout());

        JLabel label = new JLabel(ResourceSupport.tr("daemon_view"));
        textField = new JTextField("Hello, leon-test");
        textField.setPreferredSize(new Dimension(200, 32));
        startButton = new JButton(ResourceSupport.tr("start_daemon"));
        stopButton = new JButton(ResourceSupport.tr("stop_daemon"));

        textField.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                SwingService.keyboardService.showLetterKeyboard(textField, null, false, new BaseKeyboardCallback() {
                    @Override
                    public void onOk(Object o) {
                        try {
                            xmlRpcMyDaemonFacade.setMessage(textField.getText());
                        } catch (XmlRpcException ex) {
                            ex.printStackTrace();
                        }
                    }
                });
            }
        });

        startButton.addActionListener(e -> startDaemon());

        stopButton.addActionListener(e -> stopDaemon());

        FormTools.addComponent(panel, label, 0, 0, 2, 1, 0.0D, 0.0D, 0, 0, 0, 0, 1, 10);
        FormTools.addComponent(panel, textField, 0, 1, 2, 1, 0.0D, 0.0D, 20, 0, 0, 0, 1, 10);
        FormTools.addComponent(panel, startButton, 0, 2, 1, 1, 0.0D, 0.0D, 20, 0, 0, 0, 3, 17);
        FormTools.addComponent(panel, stopButton, 1, 2, 1, 1, 0.0D, 0.0D, 20, 0, 0, 0, 3, 13);

        // 如果Daemon启动，则调用状态更新函数，切换按钮的可点击状态
        daemonService.getDaemon().addDaemonStateListener(this::updateStatus);

        // 增加按钮，发送mes数据
        JButton jButton = new JButton("SendData");
        jButton.addActionListener(e->{
            System.out.println("get textField data" + textField.getText());
            try {
                xmlRpcMyDaemonFacade.setMessage(textField.getText());
            } catch (XmlRpcException ex) {
                ex.printStackTrace();
            }
        });
        JButton jButton1 = new JButton("robotStartUp");
        jButton1.addActionListener(e-> {
            System.out.println("get textField data" + textField.getText());
            try {
                xmlRpcMyDaemonFacade.robotStartup();
            } catch (XmlRpcException ex) {
                ex.printStackTrace();
            }
        });

        FormTools.addComponent(panel, jButton, 0, 3, 1, 1, 0.0D, 0.0D, 20, 0, 0, 0, 3, 13);
        FormTools.addComponent(panel, jButton1, 1, 3, 1, 1, 0.0D, 0.0D, 20, 0, 0, 0, 3, 13);

    }

    public void updateStatus(DaemonContribution.State state) {
        if (state == DaemonContribution.State.RUNNING) {
            startButton.setEnabled(false);
            stopButton.setEnabled(true);
            textField.setEnabled(true);
        } else {
            startButton.setEnabled(true);
            stopButton.setEnabled(false);
            textField.setEnabled(false);
        }
    }

    public void startDaemon() {
        System.out.println("my daemon start!");
        daemonService.getDaemon().start();
    }

    public void stopDaemon() {
        System.out.println("my daemon stop!");
        daemonService.getDaemon().stop();
    }

    @Override
    public void openView() {
//        startDaemon();
    }

    @Override
    public void closeView() {
//        stopDaemon();
    }
}