package com.leon.leonT.impl.WeldTaskNode;

import cn.elibot.robot.plugin.contribution.configuration.ConfigurationAPIProvider;
import cn.elibot.robot.plugin.contribution.task.SwingTaskNodeView;
import cn.elibot.robot.plugin.contribution.task.TaskApiProvider;
import cn.elibot.robot.plugin.contribution.task.TaskNodeViewApiProvider;
import cn.elibot.robot.plugin.domain.RpcService;
import cn.elibot.robot.plugin.domain.robot.RobotMovementService;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveCallback;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveCancelEvent;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveCompleteEvent;
import cn.elibot.robot.plugin.domain.robot.automove.AutoMoveErrorEvent;
import cn.elibot.robot.plugin.domain.task.PluginEntityNameException;
import cn.elibot.robot.plugin.domain.task.nodes.TaskNodeFactory;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.MoveNode;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.WaypointNode;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.move.builders.MoveJointConfigBuilder;
import cn.elibot.robot.plugin.domain.task.nodes.builtin.waypoint.*;
import cn.elibot.robot.plugin.domain.task.structure.TreeNode;
import cn.elibot.robot.plugin.domain.task.structure.TreeStructureException;
import cn.elibot.robot.plugin.domain.value.*;
import com.leon.leonT.impl.domain.WeldPoint;
import com.leon.leonT.impl.resource.ImageHelper;
import com.leon.leonT.impl.resource.ResourceSupport;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class LeonWeldTaskNodeView implements SwingTaskNodeView<LeonWeldTaskNodeContribution> {
    private final TaskNodeViewApiProvider taskNodeViewApiProvider;
    private final TaskApiProvider taskApiProvider;
    private final ConfigurationAPIProvider configurationAPIProvider;

    private final ImageIcon errorIcon;

    private final RpcService rpcService;

    private List<WeldPoint> prePoints = new ArrayList<>();
    private List<WeldPoint> weldPoints = new ArrayList<>();
    private List<WeldPoint> postPoints = new ArrayList<>();
    private LeonWeldTaskNodeContribution contribution;


    public LeonWeldTaskNodeView(TaskNodeViewApiProvider taskNodeViewApiProvider) {
        this.taskNodeViewApiProvider = taskNodeViewApiProvider;
        this.taskApiProvider = this.taskNodeViewApiProvider.getTaskApiProvider();
        this.errorIcon = getErrorIcon();
        this.configurationAPIProvider = this.taskApiProvider.getConfigurationApi();
        this.rpcService = this.taskApiProvider.getRpcService();

    }

    private ImageIcon getErrorIcon() {
        return ImageHelper.loadImage("errorIcon.png");
    }

    @Override
    public void buildUI(JPanel jPanel, LeonWeldTaskNodeContribution leonWeldTaskNodeContribution) {
        this.contribution = leonWeldTaskNodeContribution;

        jPanel.setLayout(new BorderLayout());
        jPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 卡片布局：全屏切换页面
        CardLayout cardLayout = new CardLayout();
        JPanel viewContainer = new JPanel(cardLayout);

        // 页面名称常量
        final String PAGE_HOME = "HOME";
        final String PAGE_MOVE_SCRIPT = "MOVE_SCRIPT";
        final String PAGE_DATA_WRITE = "DATA_WRITE";
        final String PAGE_CREATE_WELD = "CREATE_WELD";

        // 构建所有页面
        JPanel homePage = buildHomePage(cardLayout, viewContainer, PAGE_HOME, PAGE_MOVE_SCRIPT, PAGE_DATA_WRITE, PAGE_CREATE_WELD);
        JPanel moveScriptPage = buildMoveScriptPage(cardLayout, viewContainer, PAGE_HOME);
        JPanel dataWritePage = buildDataWritePage(cardLayout, viewContainer, PAGE_HOME);
        JPanel weldPage = buildCreateWeldPage(cardLayout, viewContainer, PAGE_HOME);

        // 注册页面
        viewContainer.add(homePage, PAGE_HOME);
//        viewContainer.add(moveScriptPage, PAGE_MOVE_SCRIPT);
        viewContainer.add(dataWritePage, PAGE_DATA_WRITE);
        viewContainer.add(weldPage, PAGE_CREATE_WELD);

        // 容器直接铺满整个面板
        jPanel.add(viewContainer, BorderLayout.CENTER);
    }

    /**
     * 首页：功能选择菜单（初始展示页面）
     */
    private JPanel buildHomePage(CardLayout layout, JPanel container, String homeKey,
                                 String moveKey, String dataKey, String weldKey) {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 1, 12, 12));
        panel.setBorder(BorderFactory.createTitledBorder(ResourceSupport.tr("FunctionSelect")));

        JButton btnTaskGCData = new JButton(ResourceSupport.tr("TaskGCData"));
        btnTaskGCData.addActionListener(e -> layout.show(container, moveKey));

        JButton btnDataWrite = new JButton(ResourceSupport.tr("Task-DataWrite"));
        btnDataWrite.addActionListener(e -> layout.show(container, dataKey));

        JButton btnCreateLineWeld = new JButton(ResourceSupport.tr("createLineWeld"));
        btnCreateLineWeld.addActionListener(e -> layout.show(container, weldKey));


        panel.add(btnTaskGCData);
        panel.add(btnDataWrite);
        panel.add(btnCreateLineWeld);

        JPanel wrapPanel = new JPanel(new BorderLayout());
        wrapPanel.add(panel, BorderLayout.CENTER);
        wrapPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        return wrapPanel;
    }

    /**
     * 点位运动脚本页面
     */
    private JPanel buildMoveScriptPage(CardLayout layout, JPanel container, String homeKey) {
        JPanel panel = new JPanel();

        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(ResourceSupport.tr("Task-DataWrite")));

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backBtn = new JButton("← " + ResourceSupport.tr("Back"));
        backBtn.addActionListener(e -> layout.show(container, homeKey));
        topBar.add(backBtn);

        panel.add(topBar, BorderLayout.NORTH);
        panel.add(new JLabel("功能区域：数据写入（待开发）", SwingConstants.CENTER), BorderLayout.CENTER);
        return panel;
    }

    /**
     * 数据写入页面
     */
    private JPanel buildDataWritePage(CardLayout layout, JPanel container, String homeKey) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(ResourceSupport.tr("TaskGCData")));

        // 顶部按钮栏：返回 + 执行脚本
        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backBtn = new JButton("← " + ResourceSupport.tr("Back"));
        backBtn.addActionListener(e -> layout.show(container, homeKey));

        JButton runScriptBtn = new JButton(ResourceSupport.tr("RunScript"));
        runScriptBtn.addActionListener(event -> {
            System.out.println("Current all TCPs:");
            configurationAPIProvider.getTCPModel().getTCPs()
                    .forEach(tcp -> System.out.println(tcp.getDisplayName()));

            String script = "def moveJoint():\n" +
                    "    global u36335u28857_1_p\n" +
                    "    u36335u28857_1_p = [0.38408322662661437, -0.14749999998051516, 0.5791660826988158, 3.141590486727266, 2.0510342851484963E-10, -1.570796326794897]\n" +
                    "    global u36335u28857_1_q\n" +
                    "    u36335u28857_1_q = [0.0,-1.3553166793699976,-1.5417435069442484,-1.815330960932971,1.570796327,0.0]\n" +
                    "    global u36335u28857_2_p\n" +
                    "    u36335u28857_2_p = [0.384082379510545, -0.14749999998051516, 0.47530833400077926, -3.141590901884441, 2.051034285150165E-10, -1.5707963267948963]\n" +
                    "    global u36335u28857_2_q\n" +
                    "    u36335u28857_2_q = [0.0,-1.327509509546772,-1.8310296704013531,-1.5538480487312125,1.570796327,0.0]\n" +
                    "    global u36335u28857_3_p\n" +
                    "    u36335u28857_3_p = [0.3840815975778526, 0.06940005726177045, 0.4753079998448488, -3.141591470706301, 7.522785813227031E-7, -1.570795659007012]\n" +
                    "    global u36335u28857_3_q\n" +
                    "    u36335u28857_3_q = [0.56630344846347,-1.2721295632916005,-1.870202375828231,-1.5700556394316383,1.570796327,0.5663027806760305]\n" +
                    "    movej(get_inverse_kin(u36335u28857_1_p, qnear=u36335u28857_1_q), a=1.3962634015954636, v=1.0471975511965976)\n" +
                    "    movej(get_inverse_kin(u36335u28857_2_p, qnear=u36335u28857_2_q), a=1.3962634015954636, v=1.0471975511965976)\n" +
                    "    movej(get_inverse_kin(u36335u28857_3_p, qnear=u36335u28857_3_q), a=1.3962634015954636, v=1.0471975511965976)\n" +
                    "end\n" +
                    "moveJoint()";
            rpcService.runScript(script);
        });

        topBar.add(backBtn);
        topBar.add(runScriptBtn);
        panel.add(topBar, BorderLayout.NORTH);
        panel.add(new JLabel("功能区域：运动脚本执行", SwingConstants.CENTER), BorderLayout.CENTER);
        return panel;

    }

    /**
     * 创建焊缝页面
     */
    private JPanel buildCreateWeldPage(CardLayout layout, JPanel container, String homeKey) {
        JPanel panel = new JPanel(new BorderLayout(10, 10));

        panel.setLayout(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder(ResourceSupport.tr("Task-DataWrite")));

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton backBtn = new JButton("← " + ResourceSupport.tr("Back"));
        backBtn.addActionListener(e -> layout.show(container, homeKey));
        topBar.add(backBtn);

        panel.add(topBar, BorderLayout.NORTH);
        // ========== 顶部区域（如果你原来有topBar，请自行恢复补充 ==========
        // JPanel topBar = new JPanel();
        // panel.add(topBar, BorderLayout.NORTH);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.weighty = 1;
        gbc.insets = new Insets(5, 5, 5, 5);

        JPanel pointGroupPanel = new JPanel(new GridBagLayout());

        // ---------------- 前置安全点区域 ----------------
        JPanel prePointPanel = new JPanel(new BorderLayout(5, 5));
        prePointPanel.setBorder(BorderFactory.createTitledBorder(ResourceSupport.tr("pre_safe_point")));
        JPanel prePointContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        prePointContainer.setPreferredSize(new Dimension(120, 60));

        JButton delPreBtn = new JButton(ResourceSupport.tr("delete"));
        delPreBtn.addActionListener(e -> {
            prePointContainer.removeAll();
            prePointContainer.revalidate();
            prePointContainer.repaint();
        });
        JPanel preBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        preBtnPanel.add(delPreBtn);
        prePointPanel.add(new JScrollPane(prePointContainer), BorderLayout.CENTER);
        prePointPanel.add(preBtnPanel, BorderLayout.SOUTH);

        // ---------------- 焊接点区域 ----------------
        JPanel weldPointPanel = new JPanel(new BorderLayout(5, 5));
        weldPointPanel.setBorder(BorderFactory.createTitledBorder(ResourceSupport.tr("weld_point")));
        JPanel weldPointContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        weldPointContainer.setPreferredSize(new Dimension(120, 60));

        JButton delWeldBtn = new JButton(ResourceSupport.tr("delete"));
        delWeldBtn.addActionListener(e -> {
            weldPointContainer.removeAll();
            weldPointContainer.revalidate();
            weldPointContainer.repaint();
        });
        JPanel weldBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        weldBtnPanel.add(delWeldBtn);
        weldPointPanel.add(new JScrollPane(weldPointContainer), BorderLayout.CENTER);
        weldPointPanel.add(weldBtnPanel, BorderLayout.SOUTH);

        // ---------------- 后置安全点区域 ----------------
        JPanel postPointPanel = new JPanel(new BorderLayout(5, 5));
        postPointPanel.setBorder(BorderFactory.createTitledBorder(ResourceSupport.tr("post_safe_point")));
        JPanel postPointContainer = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 4));
        postPointContainer.setPreferredSize(new Dimension(120, 60));

        JButton delPostBtn = new JButton(ResourceSupport.tr("delete"));
        delPostBtn.addActionListener(e -> {
            postPointContainer.removeAll();
            postPointContainer.revalidate();
            postPointContainer.repaint();
        });
        JPanel postBtnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        postBtnPanel.add(delPostBtn);
        postPointPanel.add(new JScrollPane(postPointContainer), BorderLayout.CENTER);
        postPointPanel.add(postBtnPanel, BorderLayout.SOUTH);

        // 横向摆放三块面板
        gbc.gridx = 0;
        gbc.gridy = 0;
        pointGroupPanel.add(prePointPanel, gbc);

        gbc.gridx = 1;
        pointGroupPanel.add(weldPointPanel, gbc);

        gbc.gridx = 2;
        pointGroupPanel.add(postPointPanel, gbc);

        // ========== 底部：仅两个按钮【安全点】【直线焊接点】 ==========
        JPanel bottomBtnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        JButton addSafePointBtn = new JButton(ResourceSupport.tr("safe_point"));
        JButton addLineWeldBtn = new JButton(ResourceSupport.tr("line_weld_point"));
        JButton addWeldTaskBtn = new JButton(ResourceSupport.tr("create_weld_task"));

        // 安全点：弹窗选择前置 / 后置
        addSafePointBtn.addActionListener(e -> {
            String[] options = {"前置安全点", "后置安全点"};
            int select = JOptionPane.showOptionDialog(panel,
                    "请选择安全点类型",
                    "新增安全点",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    options,
                    options[0]);
            if (select == 0) {
                JointPositions currentJoint = configurationAPIProvider.getRobotMovementService().getCurrentJointPositions();
                Pose pose = configurationAPIProvider.getRobotMovementService().getCurrentTCPPose();
                // 【关键调试语句】
                System.out.println("currentJoint == null ? >>> " + (currentJoint == null));

                if (currentJoint == null) {
                    JOptionPane.showMessageDialog(null, "获取机械臂关节位置失败，无法保存点位！");
                    return; // 直接终止，下面代码不再执行
                }

                double[] data = currentJoint.toArray(Angle.Unit.RAD);
                System.out.println("本次读取关节：" + Arrays.toString(data));

                WeldPoint weldPoint = new WeldPoint();
                // 保存点位信息
                weldPoint.setPointName("前置安全点" + (prePoints.size() + 1));
                weldPoint.setJointPositions(currentJoint);
                weldPoint.setPose(pose);
                this.prePoints.add(weldPoint);

                // 别忘了创建点位按钮
                createPointButton(weldPoint, prePointContainer, prePoints);
            } else if (select == 1) {

                JointPositions currentJoint = configurationAPIProvider.getRobotMovementService().getCurrentJointPositions();
                Pose pose = configurationAPIProvider.getRobotMovementService().getCurrentTCPPose();
                // 【关键调试语句】
                System.out.println("currentJoint == null ? >>> " + (currentJoint == null));

                if (currentJoint == null) {
                    JOptionPane.showMessageDialog(null, "获取机械臂关节位置失败，无法保存点位！");
                    return; // 直接终止，下面代码不再执行
                }

                double[] data = currentJoint.toArray(Angle.Unit.RAD);
                System.out.println("本次读取关节：" + Arrays.toString(data));

                WeldPoint weldPoint = new WeldPoint();
                // 保存点位信息
                weldPoint.setPointName("后置安全点" + (postPoints.size() + 1));
                weldPoint.setJointPositions(currentJoint);
                weldPoint.setPose(pose);
                this.postPoints.add(weldPoint);

                // 别忘了创建点位按钮
                createPointButton(weldPoint, postPointContainer, postPoints);

            }
        });

        // 直线焊接点，直接添加到焊接区域
        addLineWeldBtn.addActionListener(e -> {
            JointPositions currentJoint = configurationAPIProvider.getRobotMovementService().getCurrentJointPositions();
            Pose pose = configurationAPIProvider.getRobotMovementService().getCurrentTCPPose();
            // 【关键调试语句】
            System.out.println("pose == null ? >>> " + (pose == null));

            if (pose == null) {
                JOptionPane.showMessageDialog(null, "获取机械臂Pose位置失败，无法保存点位！");
                return; // 直接终止，下面代码不再执行
            }

            double[] data = pose.toArray(Length.Unit.M,Angle.Unit.DEG);
            System.out.println("本次笛卡尔位置：" + Arrays.toString(data));

            WeldPoint weldPoint = new WeldPoint();
            // 保存点位信息
            weldPoint.setPointName("直线焊接点" + (weldPoints.size() + 1));
            weldPoint.setJointPositions(currentJoint);
            weldPoint.setPose(pose);
            this.weldPoints.add(weldPoint);

            // 别忘了创建点位按钮
            createPointButton(weldPoint, weldPointContainer, weldPoints);
        });

        addWeldTaskBtn.addActionListener(e-> {
            // 判断安全点,前置点,后置点是否完成,生成对应的节点
            System.out.println("开始生成节点");
            TreeNode treeNode = LeonWeldTaskNodeView.this.taskApiProvider.getTaskModel()
                    .getContributionTreeNode(LeonWeldTaskNodeView.this.contribution);
            LeonWeldTaskNodeView.this.taskApiProvider.getUndoRedoManager().recordChanges(() -> {
                addWaypointByList(treeNode);
            });
        });

        bottomBtnPanel.add(addSafePointBtn);
        bottomBtnPanel.add(addLineWeldBtn);
        bottomBtnPanel.add(addWeldTaskBtn);

        // ========== 组装整体页面 ==========
        JPanel centerContainer = new JPanel();
        centerContainer.setLayout(new BorderLayout(15, 15));
        centerContainer.add(pointGroupPanel, BorderLayout.CENTER);
        centerContainer.add(bottomBtnPanel, BorderLayout.SOUTH);

        panel.add(centerContainer, BorderLayout.CENTER);

        return panel;
    }

    /**
     * 创建点位按钮组件
     *
     * @param weldPoint 点位数据
     * @param container 按钮存放面板
     * @param pointList 点位集合（prePoints/weldPoints/postPoints）
     */
    private void createPointButton(WeldPoint weldPoint, JPanel container, List<WeldPoint> pointList) {
        // 一行布局：点位名称按钮
        JPanel linePanel = new JPanel();
        linePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 5, 3));

        JButton pointBtn = new JButton(weldPoint.getPointName());
        pointBtn.setPreferredSize(new Dimension(140, 30));

        // ==========点击点位按钮：弹出自定义操作弹窗 ==========
        pointBtn.addActionListener(e -> {
            // 构建弹窗面板
            JPanel dialogPanel = new JPanel();
            dialogPanel.setLayout(new BoxLayout(dialogPanel, BoxLayout.Y_AXIS));
            dialogPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

            // 三个功能按钮
            JButton moveBtn = new JButton("移动到此位置");
            JButton editBtn = new JButton("修改点位");
            JButton delBtn = new JButton("删除点位");

            dialogPanel.add(new JLabel("点位：" + weldPoint.getPointName()));
            dialogPanel.add(Box.createVerticalStrut(8));
            dialogPanel.add(moveBtn);
            dialogPanel.add(Box.createVerticalStrut(5));
            dialogPanel.add(editBtn);
            dialogPanel.add(Box.createVerticalStrut(5));
            dialogPanel.add(delBtn);

            // 创建对话框
            JDialog dialog = new JDialog();
            dialog.setTitle("点位操作");
            dialog.setModal(true);
            dialog.setSize(260, 220);
            dialog.setLocationRelativeTo(null);
            dialog.setContentPane(dialogPanel);

            // 1、移动到此位置（调用SDK示教移动弹窗）
            moveBtn.addActionListener(ev -> {
                dialog.dispose(); //先关闭操作弹窗
                JointPositions targetJoint = weldPoint.getJointPositions();
                if(targetJoint == null){
                    JOptionPane.showMessageDialog(null,"点位关节数据为空！");
                    return;
                }
                RobotMovementService movementService = configurationAPIProvider.getRobotMovementService();
                movementService.requestUserToMoveRobot(targetJoint, new AutoMoveCallback() {
                    @Override
                    public void onComplete(AutoMoveCompleteEvent autoMoveCompleteEvent) {
                        System.out.println("确认移动到点位：" + weldPoint.getPointName());
                    }
                    @Override
                    public void onCancel(AutoMoveCancelEvent autoMoveCancelEvent) {
                        System.out.println("取消移动");
                    }
                    @Override
                    public void onError(AutoMoveErrorEvent autoMoveErrorEvent) {
                        JOptionPane.showMessageDialog(null,"移动失败："+autoMoveErrorEvent.getErrorType());
                    }
                });
            });

            // 2、修改点位：读取当前机器人关节，覆盖旧点位
            editBtn.addActionListener(ev -> {
                dialog.dispose();
                JointPositions newJoint = configurationAPIProvider.getRobotMovementService().getCurrentJointPositions();
                if(newJoint == null){
                    JOptionPane.showMessageDialog(null,"读取当前机器人关节失败！");
                    return;
                }
                // 使用工具类深度拷贝，规避空对象问题
                weldPoint.setJointPositions(newJoint);
                JOptionPane.showMessageDialog(null,"点位更新成功！");
            });

            //3、删除点位
            delBtn.addActionListener(ev -> {
                int opt = JOptionPane.showConfirmDialog(null,"确定删除【"+weldPoint.getPointName()+"】？","确认",JOptionPane.YES_NO_OPTION);
                if(opt == JOptionPane.YES_OPTION){
                    dialog.dispose();
                    pointList.remove(weldPoint);
                    container.remove(linePanel);
                    container.revalidate();
                    container.repaint();
                }
            });

            dialog.setVisible(true);
        });

        linePanel.add(pointBtn);
        container.add(linePanel);
        container.revalidate();
        container.repaint();
    }


    private void addWaypointByList(TreeNode treeNode) {
        System.out.println("treeNode接收完成,开始创建");
        if (prePoints.size() <= 0){
            System.out.println("缺少前置点");
        }else if (weldPoints.size() <= 1){
            System.out.println("需要添加直线焊点");
        } else if (postPoints.size() <= 0) {
            System.out.println("缺少后置点");
        }

        ValueFactory valueFactory = LeonWeldTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = LeonWeldTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        // 创建基础的MoveJ节点
        MoveNode moveJ = factory.createMoveNode();

        MoveJointConfigBuilder moveJointConfigBuilder = moveJ.getConfigBuilderFactory().createMoveJConfigBuilder();
        moveJointConfigBuilder.setDescribe("前置点");
        moveJointConfigBuilder.setJointSpeed(valueFactory.createAngularSpeed(80.0D, AngularSpeed.Unit.DEG_S));
        moveJointConfigBuilder.setJointAcceleration(
                valueFactory.createAngularAcceleration(1200.0D, AngularAcceleration.Unit.DEG_S2));
        moveJointConfigBuilder.setTCPSelection(moveJ.getTCPSelectionFactory().createIgnoreActiveTCPSelection());

        moveJointConfigBuilder.setAllowTemporaryFrame(true);
        moveJ.setConfig(moveJointConfigBuilder.build());

        TreeNode movej = null;
        try {
            movej = treeNode.addChild(moveJ);

        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }


        // 创建基础的MoveJ节点
        MoveNode weldMoveLine = factory.createMoveNode();

        MoveJointConfigBuilder weldMoveLineConfigBuilder = moveJ.getConfigBuilderFactory().createMoveJConfigBuilder();
        weldMoveLineConfigBuilder.setDescribe("直线");
        weldMoveLineConfigBuilder.setJointSpeed(valueFactory.createAngularSpeed(80.0D, AngularSpeed.Unit.DEG_S));
        weldMoveLineConfigBuilder.setJointAcceleration(
                valueFactory.createAngularAcceleration(1200.0D, AngularAcceleration.Unit.DEG_S2));
        weldMoveLineConfigBuilder.setTCPSelection(moveJ.getTCPSelectionFactory().createIgnoreActiveTCPSelection());

        weldMoveLineConfigBuilder.setAllowTemporaryFrame(true);
        weldMoveLine.setConfig(weldMoveLineConfigBuilder.build());

        TreeNode weldMoveLineChild = null;
        try {
            weldMoveLineChild = treeNode.addChild(weldMoveLine);

        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }


        // 创建基础的MoveJ节点
        MoveNode postMoveJ = factory.createMoveNode();

        MoveJointConfigBuilder postMoveJConfigBuilder = moveJ.getConfigBuilderFactory().createMoveJConfigBuilder();
        postMoveJConfigBuilder.setDescribe("后置点");
        postMoveJConfigBuilder.setJointSpeed(valueFactory.createAngularSpeed(80.0D, AngularSpeed.Unit.DEG_S));
        postMoveJConfigBuilder.setJointAcceleration(
                valueFactory.createAngularAcceleration(1200.0D, AngularAcceleration.Unit.DEG_S2));
        postMoveJConfigBuilder.setTCPSelection(moveJ.getTCPSelectionFactory().createIgnoreActiveTCPSelection());

        postMoveJConfigBuilder.setAllowTemporaryFrame(true);
        postMoveJ.setConfig(moveJointConfigBuilder.build());

        TreeNode postMoveJChild = null;
        try {
            postMoveJChild = treeNode.addChild(postMoveJ);
        } catch (TreeStructureException treeStructureException) {
            treeStructureException.printStackTrace();
        }

        for (WeldPoint e : prePoints){
            addWaypoint(movej,e);
        }

        for (WeldPoint e : weldPoints){
            addWaypoint(weldMoveLineChild,e);
        }

        for (WeldPoint e : postPoints){
            addWaypoint(postMoveJChild,e);
        }



    }

    private void addWaypoint(TreeNode treeNode, WeldPoint weldPoint) {
        System.out.println("当前的前置点数据" + weldPoint.getJointPositions());
        ValueFactory valueFactory = LeonWeldTaskNodeView.this.taskApiProvider.getValueFactory();
        TaskNodeFactory factory = LeonWeldTaskNodeView.this.taskApiProvider.getTaskModel().getTaskNodeFactory();

        WaypointNode waypointNode = factory.createWaypointNode();
        WaypointNodeConfigFactory waypointNodeConfigFactory = waypointNode.getWaypointNodeConfigFactory();
        Length transitionRadius = valueFactory.createLength(-60.0D, Length.Unit.MM);
        TransitionSelection transitionSelection = waypointNodeConfigFactory.createWaypointTransitionSelection(transitionRadius);
//        FixedPositionConfig fixedPositionConfig = waypointNodeConfigFactory.createFixedPositionConfig(transitionSelection,
//                waypointNodeConfigFactory.createInheritedMotion());

        System.out.println("传参写入targetJoints");
        System.out.println("创建固定点位数据");
        FixedDefinedPositionConfig fixedPositionConfig = waypointNodeConfigFactory.createFixedPositionConfig(
                weldPoint.getPose(),
                weldPoint.getJointPositions(),
                waypointNodeConfigFactory.createInheritedMotion(),
                transitionSelection
        );
        System.out.println("固定点位数据创建完成");


        waypointNode.setConfig(fixedPositionConfig);
        System.out.println("配置设置成功");
        try {
            treeNode.addChild(waypointNode);
            waypointNode.setName(weldPoint.getPointName());
            System.out.println("节点增加完成");
        } catch (TreeStructureException | PluginEntityNameException treeStructureException) {
            treeStructureException.printStackTrace();
        }
    }

}
