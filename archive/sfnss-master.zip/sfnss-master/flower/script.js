document.addEventListener('DOMContentLoaded', function() {
    const petals = document.querySelectorAll('.petal');
    petals.forEach(petal => {
        petal.classList.add('open');
    });
});