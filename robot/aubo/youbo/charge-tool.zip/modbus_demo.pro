#----------------------------------------------------------------------------
#
# Project created by QtCreator 2016-06-30T14:57:34
# Copyright (C) 2015-2018 Aubo(Beijing) Intelligent Technology Co., Ltd.
# Contact : http://www.aubo-robotics.com/
# Author  : Yifei Pan
# Version : V4.x.x
#
#----------------------------------------------------------------------------

include(teachpendant.pri)

#Qt version check
!minQtVersion(5, 5, 0) {
    !build_pass \
    :message("Cannot build Qt Creator with Qt version $${QT_VERSION}.")
    error("Use at least Qt 5.5.0.")
}

TEMPLATE = subdirs
CONFIG += ordered

SUBDIRS += \
    src/plugins \
    src/app \
