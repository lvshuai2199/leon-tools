depfile = $$replace(_PRO_FILE_PWD_, ([^/]+$), \\1/\\1_dependencies.pri)
exists($$depfile) {
    include($$depfile)
    isEmpty(TP_PLUGIN_NAME): \
        error("$$basename(depfile) does not define TP_PLUGIN_NAME.")
} else {
    isEmpty(TP_PLUGIN_NAME): \
        error("TP_PLUGIN_NAME is empty. Maybe you meant to create $$basename(depfile)?")
}
TARGET = $$TP_PLUGIN_NAME

DEFINES += $$shell_quote(TP_PLUGIN_NAME=\"$$TP_PLUGIN_NAME\")
DEFINES += $$shell_quote(TP_PLUGIN_JSON_FILE_NAME=\"$${TP_PLUGIN_NAME}.json\")

plugin_deps = $$TP_PLUGIN_DEPENDS

include(../teachpendant.pri)

RELATIVE_PLUGIN_SHARE_PATH = $$RELATIVE_SHARE_PATH/plugins/$$TP_PLUGIN_NAME
DEFINES += $$shell_quote(RELATIVE_PLUGIN_SHARE_PATH=\"$$RELATIVE_PLUGIN_SHARE_PATH\")

PLUGIN_SOURCE_TREE = $$TP_PLUGIN_DIRS/$$lower($$TP_PLUGIN_NAME)plugin
DEFINES += $$shell_quote(PLUGIN_SOURCE_TREE=\"$$PLUGIN_SOURCE_TREE\")

defineReplace(dependencyName) {
    dependencies_file =
    for(dir, TP_PLUGIN_DIRS) {
        exists($$dir/$$1/$${1}_dependencies.pri) {
            dependencies_file = $$dir/$$1/$${1}_dependencies.pri
            break()
        }
    }
    isEmpty(dependencies_file): \
        error("Plugin dependency $$dep not found")
    include($$dependencies_file)
    return($$TP_PLUGIN_NAME)
}

# for substitution in the .json
dependencyList =
for(dep, plugin_deps) {
    dependencyList += "        { \"Name\" : \"$$dependencyName($$dep)\", \"Version\" : \"$$TP_VERSION\" }"
}
dependencyList = $$join(dependencyList, ",$$escape_expand(\\n)")

dependencyList = "\"Dependencies\" : [$$escape_expand(\\n)$$dependencyList$$escape_expand(\\n)    ]"

DESTDIR = $$TP_PLUGIN_PATH

QMAKE_POST_LINK += $$quote(cp $$replace(_PRO_FILE_PWD_, ([^/]+$), \\1/\\1.h) $$OUT_PWD$$escape_expand(\\n\\t))
LIBS += -L$$DESTDIR
INCLUDEPATH += $$OUT_PWD

# copy the plugin spec
isEmpty(TARGET) {
    error("teachpendantplugin.pri: You must provide a TARGET")
}

PLUGINJSON = $$_PRO_FILE_PWD_/$${TARGET}.json
PLUGINJSON_IN = $${PLUGINJSON}.in
exists($$PLUGINJSON_IN) {
    DISTFILES += $$PLUGINJSON_IN
    QMAKE_SUBSTITUTES += $$PLUGINJSON_IN
    PLUGINJSON = $$OUT_PWD/$${TARGET}.json
} else {
    # need to support that for external plugins
    DISTFILES += $$PLUGINJSON
}

TEMPLATE = lib
CONFIG += plugin plugin_with_soname

TARGET = $$qtLibraryTargetName($$TARGET)
