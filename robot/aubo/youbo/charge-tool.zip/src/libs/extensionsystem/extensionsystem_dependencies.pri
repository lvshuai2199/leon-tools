TP_LIB_NAME = ExtensionSystem
TP_LIB_DEPENDS += \
    stl
