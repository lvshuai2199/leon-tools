/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of Qt Creator.
**
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3 as published by the Free Software
** Foundation with exceptions as appearing in the file LICENSE.GPL3-EXCEPT
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-3.0.html.
**
****************************************************************************/

#pragma once

#include "extensionsystem_global.h"
#include "abscondinfo/abscondinfo.h"

#include <QObject>
#include <QtPlugin>

namespace ExtensionSystem {

namespace Internal {
    class IPluginPrivate;
    class PluginSpecPrivate;
}

class PluginManager;
class PluginSpec;

class EXTENSIONSYSTEM_EXPORT IPlugin : public QObject
{
    Q_OBJECT

public:
    IPlugin();
    virtual ~IPlugin();

    //plugin common interface
    virtual bool pluginCommonInterface(
            const QString &parm, QString &retValue) = 0;

    //Call the initialization function before the project starts
    virtual bool initParms() = 0;
    //Call the pause function before the project is paused
    virtual bool pausePlugin() = 0;
    //Call the continue function before the project continues
    virtual bool continuePlugin() = 0;
    //Call the stop function before the project is stopped
    virtual bool stopPlugin() = 0;

    virtual QWidget *createUI(QWidget *parent) = 0;

    //Set the plugin relative path
    virtual void setPluginSharedFilePath(const QString &pluginPath) = 0;

    //Set the parent class of messagebox.
    virtual void setPluginMessageBoxParentWidget(
            QWidget *messageBoxParent) = 0;

    //Load language
    virtual void loadTranslator(const QString &language) = 0;

    //Enable edit UI
    virtual void enableEdit(const bool &enable) = 0;

private:
    Internal::IPluginPrivate *d;

    friend class Internal::PluginSpecPrivate;
};

} // namespace ExtensionSystem
