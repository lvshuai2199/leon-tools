#pragma once

#include "extensionsystem_global.h"

#include <QObject>
#include <QReadWriteLock>
#include <QReadLocker>

class AbsCondInfo;

namespace ExtensionSystem {
class PluginSpec;

namespace Internal { class PluginManagerPrivate; }

class EXTENSIONSYSTEM_EXPORT PluginManager : public QObject
{
    Q_OBJECT

public:
    static PluginManager *instance();

    PluginManager();
    ~PluginManager();

    // Object pool operations
    static void addObject(QObject *obj);
    static QList<QObject *> allObjects();
    static QReadWriteLock *listLock();

    // This is useful for soft dependencies using pure interfaces.
    template <typename T> static T *getObject() {
        QReadLocker lock(listLock());
        Q_UNUSED(lock)
        QList<QObject *> all = allObjects();

        for (auto *obj : all) {
            if (T *result = qobject_cast<T *>(obj))
                return result;
        }

        return 0;
    }

    static QObject *getObjectByName(const QString &name);
    static QObject *getObjectByClassName(const QString &className);

    static QList<PluginSpec *> loadQueue();
    static void loadPlugins();
    static QStringList pluginPaths();
    static void setPluginPaths(
            const QStringList &paths,
            QStringList disabledPlugins = QStringList());
    static QString pluginIID();
    static void setPluginIID(const QString &iid);

    static QMap<QString, QList<PluginSpec *>> pluginCategories();

    static QWidget *getPluginMessageBoxParentWidget();
    static void setPluginMessageBoxParentWidget(QWidget *widget);

    static QWidget *getPluginParentWidget();
    static void setPluginParentWidget(QWidget *widget);

    static QObject *getLogicTreeModel();
    static void setLogicTreeModel(QObject *obj);

    static QString curCondType();
    static void saveCondInfo(AbsCondInfo *absCondInfo);
    static void removeCondItem();

signals:
    void signal_start();

private slots:
    void slot_timeout();

private:
    friend class Internal::PluginManagerPrivate;
};

} // namespace ExtensionSystem
