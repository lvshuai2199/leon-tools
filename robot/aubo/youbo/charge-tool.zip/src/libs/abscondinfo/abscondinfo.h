﻿#pragma once

#include <QObject>

class AbsCondInfo : public QObject
{
public:
    AbsCondInfo() {}
    virtual ~AbsCondInfo() {}

    AbsCondInfo(
            const QString &condType, const QString &alias,
            QString xmlInfo = QString(), QString exp = QString());
    AbsCondInfo(const AbsCondInfo &other);
    AbsCondInfo operator = (
            const AbsCondInfo &other);

    QString getXmlInfo() const;
    void setXmlInfo(const QString &info);

    QString getAlias() const;
    void setAlias(const QString &alias);

    QString getCondType() const;
    void setCondType(const QString &condType);

    QString getScriptExp() const;
    void setScriptExp(const QString &scriptExp);

    QString getExp() const;
    void setExp(const QString &exp);

private:
    QString m_condType;
    QString m_alias;
    QString m_xmlInfo;
    QString m_exp;
    QString m_scriptExp;

    void copyOthertoSelf(const AbsCondInfo &other);
};
