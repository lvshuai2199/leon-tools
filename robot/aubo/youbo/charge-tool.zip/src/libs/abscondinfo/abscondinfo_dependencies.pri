TP_LIB_NAME = AbsCondInfo
