include(../../pluginmanager.pri)

TEMPLATE  = subdirs

SUBDIRS   = \
    extensionsystem \
    #abscondInfo \
    stl \

