#include "modbus_demo_plugin.h"

#include <QWidget>
#include <QTranslator>
#include <QApplication>
#include "tracelog.h"


ModbusDemoPlugin::ModbusDemoPlugin(QObject *)
{
    m_translator = new QTranslator(qApp);
}

bool ModbusDemoPlugin::pluginCommonInterface(const QString &data,
                                             QString &retValueOrError)
{
    (void)data;
    (void)retValueOrError;

    return true;
}

QWidget *ModbusDemoPlugin::createUI(QWidget *parent)
{
    connect(TraceLog::getTraceLogHandle(),
            SIGNAL(signal_sendTraceInfo(int, QString)), parent,
            SIGNAL(signal_sendTraceInfo(int, QString)));

    QWidget *formShow = new chargeform(parent);

    return formShow;
}

void ModbusDemoPlugin::setPluginMessageBoxParentWidget(
    QWidget *messageBoxParent)
{
    (void)messageBoxParent;
}

void ModbusDemoPlugin::setPluginSharedFilePath(const QString &pluginPath)
{
    (void)pluginPath;
}

void ModbusDemoPlugin::loadTranslator(const QString &language)
{
    m_translator->load(
        QString(":/Translations/Translations/%1_template_plugin.qm")
            .arg(language));

    qApp->installTranslator(m_translator);
}

QWidget *ModbusDemoPlugin::createCondUI(QWidget *parent)
{

    return new chargeconditionform(parent);
}

void ModbusDemoPlugin::updateCondForm(AbsCondInfo *absCond)
{
    chargeconditionform::instance()->updateCondForm(absCond);
}

//AbsCondInfo *ModbusDemoPlugin::copyAbsCond(AbsCondInfo *absCondInfo)
//{
//    return new Gripper2FConditionClass(
//                *dynamic_cast<Gripper2FConditionClass*>(absCondInfo));
//}

//bool ModbusDemoPlugin::checkCondInfo(
//        AbsCondInfo *absCondInfo, QString &errorInfo)
//{
//    return chargeconditionform::instance()->checkCondInfo(
//              *dynamic_cast<Gripper2FConditionClass*>(
//                    absCondInfo), errorInfo);
//}

//AbsCondInfo *ModbusDemoPlugin::xmlInfoToCondInfo(
//        const QString &alias, const QString &xmlInfoParm)
//{
//    return Gripper2FConditionClass::xmlInfo2CondInfo(alias, xmlInfoParm);
//}

//QString ModbusDemoPlugin::condInfo2ScriptInfo(AbsCondInfo *absCondInfo)
//{
//    return Gripper2FConditionClass::condInfo2ScriptInfo(absCondInfo);
//}
