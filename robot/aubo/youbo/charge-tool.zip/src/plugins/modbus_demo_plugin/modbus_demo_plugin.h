#pragma once

#include "extensionsystem/iplugin.h"

#include "chargeform.h"
#include "chargeconditionform.h"

class QTranslator;

class ModbusDemoPlugin : public ExtensionSystem::IPlugin
{
    Q_OBJECT

    Q_PLUGIN_METADATA(
        IID
        "com.qt-project.AUBO.TeachPendantPlugin" FILE TP_PLUGIN_JSON_FILE_NAME)

public:
    explicit ModbusDemoPlugin(QObject *parent = 0);

    bool pluginCommonInterface(const QString &data, QString &retValueOrError);

    /*
     * 以下四个接口分别对应示教器在线编程中的开始、暂定、继续和停止。
     * 对于所有插件的阻塞接口，阻塞阈值是1000ms，超过上限阻塞接口必须返回。
     * 原则上所有的阻塞函数要支持实时外部调用打断，ms级响应，
     * 当示教器在线编程暂定或停止时，插件中的阻塞接口越开返回越好。
     *
     * 该处的业务逻辑根据实际情况自行实现
     */
    bool initParms() { return true; }
    bool pausePlugin() { return true; }
    bool continuePlugin() { return true; }
    bool stopPlugin() { return true; }

    QWidget *createUI(QWidget *parent);
    void setPluginSharedFilePath(const QString &pluginPath);
    void setPluginMessageBoxParentWidget(QWidget *messageBoxParent);
    void loadTranslator(const QString &language);
    void enableEdit(const bool & /*enable*/) {}

    //condition plugin interface
    Q_INVOKABLE QWidget *createCondUI(QWidget *parent);
    Q_INVOKABLE void updateCondForm(AbsCondInfo *absCond);
    Q_INVOKABLE AbsCondInfo *copyAbsCond(AbsCondInfo *srcAbsCond);
    Q_INVOKABLE bool checkCondInfo(
            AbsCondInfo *absCondInfo, QString &errorInfo);
    Q_INVOKABLE AbsCondInfo *xmlInfoToCondInfo(
            const QString &alias, const QString &xmlInfo);
    Q_INVOKABLE QString condInfo2ScriptInfo(AbsCondInfo *absCondInfo);

private:
    QTranslator *m_translator;
    chargeform *m_chargeform;
};
