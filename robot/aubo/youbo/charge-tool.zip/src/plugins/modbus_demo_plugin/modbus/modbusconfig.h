#pragma once

#include <string>
#include <map>

#define MODBUS_MODE_TCP "TCP"
#define MODBUS_MODE_RTU "RTU"
#define MODBUS_RESULT_SUCC         0
#define MODBUS_RESULT_FAILED      -1
#define MODBUS_RESULT_NO_INIT     -2
#define MODBUS_RESULT_IO_NOFOUND  -3
#define MODBUS_DISCONNECT         -4

//CREATE TABLE modbus_device (
//    modbus_name varchar(256) NOT NULL,
//    modbus_mode varchar(256)  NOT NULL,
//    slave varchar(256) NOT NULL,
//    response varchar(256) NOT NULL,
//    frequency varchar(256) NOT NULL,
//    device varchar(256)  NOT NULL,
//    baud varchar(256) NOT NULL,
//    parity varchar(256) NOT NULL,
//    data_bits varchar(256) NOT NULL,
//    stop_bits varchar(256) NOT NULL,
//    ip varchar(256) NOT NULL,
//    port varchar(256) NOT NULL,
//    PRIMARY KEY (modbus_name)
//);

typedef struct
{
    std::string modbus_name;  //modbus dev's name
    std::string modbus_mode;  //"TCP", "RTU"
    int         slave;        //example:slave id 0x01
    std::string ip;           //example:"192.168.6.3"
    int         port;         //example:1099
    std::string device;       //example:"/dev/ttyS0'
    int         baud;         //9600,19200,115200,etc
    char        parity;       //E O N "even", "odd", "none"
    int         data_bits;    //5, 6, 7, 8
    int         stop_bits;    //1, 2
    int         response;     //50ms
    int         frequency;    //100hz
}ModbusConfig;

//CREATE TABLE modbus_io (
//    io_name varchar(256) NOT NULL,
//    modbus_name varchar(256) NOT NULL,
//    addr_type varchar(256)  NOT NULL,
//    addr varchar(256) NOT NULL,
//    PRIMARY KEY (io_name),
//    FOREIGN KEY (modbus_name) REFERENCES modbus_device(modbus_name)
//);

typedef struct
{
    std::string io_name;
    std::string modbus_name;
    std::string addr_type;
    int addr;
}ModbusIO;

typedef struct
{
    std::string io_name;
    uint16_t value;
}ModbusIoValue;

typedef struct
{
    std::string modbus_name;
    std::string last_error_msg;
    int last_error_code;
}ModbusDeviceStatus;

enum ModbusAddrTypeDefine {
    MAT_DigitalInput,
    MAT_DigitalOutput,
    MAT_ReisterInput,
    MAT_RegisterOutput,
    MAT_RegistersOutput,
    MAT_CoilsOutput,
    MAT_Count,
    MAT_None
};
