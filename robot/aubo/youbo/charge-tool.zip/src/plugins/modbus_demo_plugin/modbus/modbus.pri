!isEmpty(MODBUSCONTROL_PRI_INCLUDED):error("modbuscontrol.pri already included")
MODBUSCONTROL_PRI_INCLUDED = 1

INCLUDEPATH += $$PWD

HEADERS += \
    $$PWD/modbusconfig.h \
    $$PWD/modbusdev.h

SOURCES += \
    $$PWD/modbusdev.cpp



unix {
    contains(QT_ARCH, i386) {
        INCLUDEPATH += \
            $$PWD/3rd/linux_x32/inc \

        DEPENDPATH += \
            $$PWD/3rd/linux_x32/lib \

        LIBS += \
            -L$$PWD/3rd/linux_x32/lib -lmodbus \
    }
    contains(QT_ARCH, x86_64) {
        INCLUDEPATH += \
            $$PWD/3rd/linux_x64/inc \

        DEPENDPATH += \
            $$PWD/3rd/linux_x64/lib \

        LIBS += \
            -L$$PWD/3rd/linux_x64/lib -lmodbus \
    }
}
