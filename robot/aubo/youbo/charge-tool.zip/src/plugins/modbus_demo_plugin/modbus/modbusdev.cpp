#include "modbusdev.h"
#include <iostream>
#include "errno.h"
#include <unistd.h>
#include "tracelog.h"
//#include <QString>

#define MODBUS_RETRY_INTERVAL 10 * 1000 // ms

ModbusDev::ModbusDev()
    : m_ctx(NULL), m_lastErrorMsg(""), m_lastErrorCode(MODBUS_RESULT_SUCC),
      m_initFlag(false)
{
}

ModbusDev::~ModbusDev()
{
    modbusClose();
}

int ModbusDev::modbusConnectRtu(const char *device, int baud, char parity,
                                int data_bit, int stop_bit, int slave,
                                int response_timeout)
{
    int result = MODBUS_RESULT_FAILED;

    modbusClose();

    std::cout << "connect:" << device << " baud:" << baud
              << " parity:" << parity << " data_bit:" << data_bit
              << " stop_bit:" << stop_bit << " slave:" << slave << std::endl;
    W_INFO("modbusConnectRtu ");

    m_ctx = modbus_new_rtu(device, baud, parity, data_bit, stop_bit);

    if (m_ctx == NULL) {
        setLastError("Unable to create the libmodbus context!", result);
    } else {
        if (MODBUS_RESULT_FAILED == modbus_connect(m_ctx)) {
            setLastError(modbus_strerror(errno), errno);
            modbus_free(m_ctx);
            m_ctx = NULL;
        } else {
            //            modbus_set_error_recovery(
            //                        m_ctx,
            //                        static_cast<modbus_error_recovery_mode>
            //                        (MODBUS_ERROR_RECOVERY_LINK |
            //                         MODBUS_ERROR_RECOVERY_PROTOCOL));
            modbus_set_error_recovery(m_ctx,
                                      static_cast<modbus_error_recovery_mode>(
                                          MODBUS_ERROR_RECOVERY_NONE));

            if (MODBUS_RESULT_FAILED == modbus_set_slave(m_ctx, slave)) {
                setLastError(modbus_strerror(errno), errno);
                modbus_free(m_ctx);
                m_ctx = NULL;
            } else {
                // set response timeout.
                timeval timeout;
                timeout.tv_sec = response_timeout / 1000;
                timeout.tv_usec = (response_timeout % 1000) * 1000;
                modbusSetResponseTimeout(timeout);
                modbusFlush();
                result = MODBUS_RESULT_SUCC;
                setLastError("", result);
            }
        }
    }

    if (MODBUS_RESULT_SUCC == result)
        m_initFlag = true;

    return result;
}

int ModbusDev::modbusConnectTcp(const char *ip, int port, int slave,
                                int response_timeout)
{
    int result = MODBUS_RESULT_FAILED;

    modbusClose();

    std::cout << "connect:" << ip << ":" << port << "..." << std::endl;

    m_ctx = modbus_new_tcp(ip, port);
    if (m_ctx == NULL) {
        setLastError(modbus_strerror(errno), errno);
        W_ERROR("Modbus modbus_new_tcp failed >>>>>>>>>");
    } else {
        if (MODBUS_RESULT_FAILED == modbus_set_slave(m_ctx, slave)) {
            setLastError(modbus_strerror(errno), errno);
            modbus_close(m_ctx);
            modbus_free(m_ctx);
            modbus_flush(m_ctx);
            m_ctx = NULL;
            W_ERROR("Modbus modbus_set_slave failed >>>>>>>");
        } else {
            if (MODBUS_RESULT_FAILED == modbus_connect(m_ctx)) {
                setLastError(modbus_strerror(errno), errno);
                modbus_close(m_ctx);
                modbus_free(m_ctx);
                modbus_flush(m_ctx);
                m_ctx = NULL;
                W_ERROR("Modbus modbus_connect failed >>>>>>>");
            } else {
                modbus_set_error_recovery(
                    m_ctx, static_cast<modbus_error_recovery_mode>(
                               MODBUS_ERROR_RECOVERY_LINK |
                               MODBUS_ERROR_RECOVERY_PROTOCOL));
                //                modbus_set_error_recovery(
                //                            m_ctx,
                //                            static_cast<modbus_error_recovery_mode>
                //                            (MODBUS_ERROR_RECOVERY_NONE));

                // set response timeout.
                timeval timeout;
                timeout.tv_sec = response_timeout / 1000;
                timeout.tv_usec = (response_timeout % 1000) * 1000;
                modbusSetResponseTimeout(timeout);
                modbusFlush();
                result = MODBUS_RESULT_SUCC;
                setLastError("", result);
                W_INFO(
                    "Modbus modbus_connect success modbusConnectTcp >>>>>>>");
            }
        }
    }

    return result;
}

int ModbusDev::modbusOpen()
{
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    if (m_config.modbus_mode == MODBUS_MODE_RTU) {
        result = this->modbusConnectRtu(m_config.device.c_str(), m_config.baud,
                                        m_config.parity, m_config.data_bits,
                                        m_config.stop_bits, m_config.slave,
                                        m_config.response);
    } else {
        result = this->modbusConnectTcp(m_config.ip.c_str(), m_config.port,
                                        m_config.slave, m_config.response);
    }

    return result;
}

void ModbusDev::modbusClose()
{
    setLastError("", MODBUS_RESULT_SUCC);

    if (m_ctx != NULL) {
        modbus_close(m_ctx);
        modbus_free(m_ctx);
        modbus_flush(m_ctx);
        W_INFO("Modbus init resourse>>>>>>>>>");
        m_ctx = NULL;
    }

    m_initFlag = false;
}

int ModbusDev::modbusFlush()
{
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_FAILED;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        W_ERROR("Modbus connect success but m_ctx is NULL >>>>>>>");
        result = MODBUS_RESULT_NO_INIT;
    } else {
        result = modbus_flush(m_ctx);

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
    }

    return result;
}

void ModbusDev::modbusSetDebug(int flag)
{
    setLastError("", MODBUS_RESULT_SUCC);

    if (m_ctx == NULL)
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
    else
        modbus_set_debug(m_ctx, flag);
}

void ModbusDev::modbusGetResponseTimeout(timeval *timeout)
{
    setLastError("", MODBUS_RESULT_SUCC);

    if (m_ctx == NULL)
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
    else
        modbus_get_response_timeout(m_ctx, timeout);
}

void ModbusDev::modbusSetResponseTimeout(struct timeval timeout)
{
    setLastError("", MODBUS_RESULT_SUCC);

    if (m_ctx == NULL)
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
    else
        modbus_set_response_timeout(m_ctx, &timeout);
}

int ModbusDev::modbusReadBits(int addr, int nb, uint8_t *dest)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_read_bits(m_ctx, addr, nb, dest)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_read_bits error, " << count << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusReadInputBits(int addr, int nb, uint8_t *dest)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_read_input_bits(m_ctx, addr, nb, dest)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_read_input_bits error, " << count << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusReadRegisters(int addr, int nb, uint16_t *dest)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_read_registers(m_ctx, addr, nb, dest)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_read_registers error, " << count << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusReadInputRegisters(int addr, int nb, uint16_t *dest)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED == (result = modbus_read_input_registers(
                                            m_ctx, addr, nb, dest)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_read_input_registers error, " << count
                      << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusWriteBit(int coil_addr, int status)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_write_bit(m_ctx, coil_addr, status)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_write_bit error, " << count << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusWriteRegister(int reg_addr, int value)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_write_register(m_ctx, reg_addr, value)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_write_register error, " << count << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusWriteBits(int addr, int nb, const uint8_t *data)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int count = 0;

    int result = MODBUS_RESULT_SUCC;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_write_bits(m_ctx, addr, nb, data)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_write_bits error, " << count << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusWriteRegisters(int addr, int nb, const uint16_t *data)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_write_registers(m_ctx, addr, nb, data)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_write_registers error, " << count << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

int ModbusDev::modbusWriteAndReadRegisters(int write_addr, int write_nb,
                                           const uint16_t *src, int read_addr,
                                           int read_nb, uint16_t *dest)
{
    std::unique_lock<std::mutex> lk(rw_mutex_);
    setLastError("", MODBUS_RESULT_SUCC);

    int result = MODBUS_RESULT_SUCC;

    int count = 0;

    if (m_ctx == NULL) {
        setLastError("libmodbus context uninitialized!", MODBUS_RESULT_NO_INIT);
        result = MODBUS_RESULT_NO_INIT;
    } else {
        while (MODBUS_RESULT_FAILED ==
                   (result = modbus_write_and_read_registers(
                        m_ctx, write_addr, write_nb, src, read_addr, read_nb,
                        dest)) &&
               count++ < 3) {
            usleep(MODBUS_RETRY_INTERVAL);
            std::cerr << "modbus_write_and_read_registers error, " << count
                      << std::endl;
        }

        if (MODBUS_RESULT_FAILED == result)
            setLastError(modbus_strerror(errno), errno);
        else
            result = MODBUS_RESULT_SUCC;
    }

    return result;
}

void ModbusDev::setModbusConfig(const ModbusConfig &config)
{
    m_config = config;
}

const ModbusConfig *ModbusDev::getModbusConfig()
{
    return &m_config;
}
std::string ModbusDev::getLastErrorMsg() const
{
    return m_lastErrorMsg;
}

int ModbusDev::getLastErrorCode() const
{
    return m_lastErrorCode;
}

std::string ModbusDev::setLastError(const std::string &lastErrorMsg,
                                    int lastErrorCode)
{
    m_lastErrorMsg = lastErrorMsg;
    m_lastErrorCode = lastErrorCode;

    //#ifdef _DEBUG
    if (m_lastErrorCode != MODBUS_RESULT_SUCC)
        std::cerr << m_lastErrorMsg << std::endl;
    //#endif

    return m_lastErrorMsg;
}
