#pragma once

#include <modbus/modbus.h>
#include "modbusconfig.h"
#include <mutex>

#define DEBUG_MODBUSDEV

class ModbusDev
{
public:
    ModbusDev();
    ~ModbusDev();

public:
    int modbusConnectRtu(const char *device, int baud, char parity,
                         int data_bit, int stop_bit, int slave,
                         int response_timeout);
    int modbusConnectTcp(const char *ip, int port, int slave,
                         int response_timeout);

public:
    int modbusOpen(void);
    void modbusClose(void);
    int modbusFlush(void);
    void modbusSetDebug(int flag);
    void modbusGetResponseTimeout(struct timeval *timeout);
    void modbusSetResponseTimeout(struct timeval timeout);
    int modbusReadBits(int addr, int nb, uint8_t *dest);
    int modbusReadInputBits(int addr, int nb, uint8_t *dest);
    int modbusReadRegisters(int addr, int nb, uint16_t *dest);
    int modbusReadInputRegisters(int addr, int nb, uint16_t *dest);
    int modbusWriteBit(int coil_addr, int status);
    int modbusWriteRegister(int reg_addr, int value);
    int modbusWriteBits(int addr, int nb, const uint8_t *data);
    int modbusWriteRegisters(int addr, int nb, const uint16_t *data);
    int modbusWriteAndReadRegisters(int write_addr, int write_nb,
                                    const uint16_t *src, int read_addr,
                                    int read_nb, uint16_t *dest);

    // modbus config.
    void setModbusConfig(const ModbusConfig &config);
    const ModbusConfig *getModbusConfig();

    std::string getLastErrorMsg() const;
    int getLastErrorCode() const;

private:
    std::string setLastError(const std::string &getLastErrorMsg,
                             int lastErrorCode);

private:
    modbus_t *m_ctx;
    ModbusConfig m_config;
    std::string m_lastErrorMsg;
    int m_lastErrorCode;
    bool m_initFlag;
    std::mutex rw_mutex_;
};
