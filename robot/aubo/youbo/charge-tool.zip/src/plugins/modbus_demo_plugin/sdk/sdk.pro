TEMPLATE = app
CONFIG += console
CONFIG -= app_bundle
CONFIG -= qt

SOURCES += main.cpp

include(deployment.pri)
qtcAddDeployment()



!isEmpty(FORM_PRI_INCLUDED):error("form.pri already included")
FORM_PRI_INCLUDED = 1

FORMS += \
    $$PWD/modbusdemoform.ui \
    $$PWD/mainform.ui \
    $$PWD/pagesettingform.ui \
    $$PWD/chargeform.ui

HEADERS += \
    $$PWD/modbusdemoform.h \
    $$PWD/mainform.h \
    $$PWD/pagesettingform.h \
    $$PWD/chargeform.h

SOURCES += \
    $$PWD/modbusdemoform.cpp \
    $$PWD/mainform.cpp \
    $$PWD/pagesettingform.cpp \
    $$PWD/chargeform.cpp


