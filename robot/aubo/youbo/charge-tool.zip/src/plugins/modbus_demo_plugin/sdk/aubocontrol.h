#ifndef AUBOCONTROL_H
#define AUBOCONTROL_H

#include <QObject>
#include <AuboRobotMetaType.h>
#include <serviceinterface.h>
//#include "util.h"
#include <QDebug>
class AuboControl : public QObject
{
    Q_OBJECT
public:
    explicit AuboControl(QObject *parent = 0);

signals:

public slots:
    void slot_openRobot();//机器人上电开启
    void slot_robotMotionInit();//初始化机器人运动参数
    void slot_robotJointMove();//轴动
    void slot_getCurrentRobotBasicInfo();//获取机器人的基本信息

private:
    ServiceInterface robotService;
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};         //机械臂关节
    aubo_robot_namespace::wayPoint_S mWayPoint_S;//路点

    aubo_robot_namespace::JointParam mJointParam;//关节角

    aubo_robot_namespace::Ori mOri;//姿态的四元素表示法

    aubo_robot_namespace::Rpy mRpy;//姿态的欧拉角表示法
    //位置
    double posX;
    double posY;
    double posZ;
    //姿态
    double oriX;
    double oriY;
    double oriZ;
    double oriW;
    //RX,RY,RZ
    double rx;
    double ry;
    double rz;
    //关节角
    double joint1;
    double joint2;
    double joint3;
    double joint4;
    double joint5;
    double joint6;


    double valueDO00=1.0;
    double valueDO01=1.0;

    //接口板用户DI地址
    const int ROBOT_IO_F1 = 30;
    const int ROBOT_IO_F2 = 31;
    const int ROBOT_IO_F3 = 32;
    const int ROBOT_IO_F4 = 33;
    const int ROBOT_IO_F5 = 34;
    const int ROBOT_IO_F6 = 35;
    const int ROBOT_IO_U_DI_00 = 36;
    const int ROBOT_IO_U_DI_01 = 37;
    const int ROBOT_IO_U_DI_02 = 38;
    const int ROBOT_IO_U_DI_03 = 39;
    const int ROBOT_IO_U_DI_04 = 40;
    const int ROBOT_IO_U_DI_05 = 41;
    const int ROBOT_IO_U_DI_06 = 42;
    const int ROBOT_IO_U_DI_07 = 43;
    const int ROBOT_IO_U_DI_10 = 44;
    const int ROBOT_IO_U_DI_11 = 45;
    const int ROBOT_IO_U_DI_12 = 46;
    const int ROBOT_IO_U_DI_13 = 47;
    const int ROBOT_IO_U_DI_14 = 48;
    const int ROBOT_IO_U_DI_15 = 49;
    const int ROBOT_IO_U_DI_16 = 50;
    const int ROBOT_IO_U_DI_17 = 51;

    //接口板用户DO地址
    const int ROBOT_IO_U_DO_00 = 32;
    const int ROBOT_IO_U_DO_01 = 33;
    const int ROBOT_IO_U_DO_02 = 34;
    const int ROBOT_IO_U_DO_03 = 35;
    const int ROBOT_IO_U_DO_04 = 36;
    const int ROBOT_IO_U_DO_05 = 37;
    const int ROBOT_IO_U_DO_06 = 38;
    const int ROBOT_IO_U_DO_07 = 39;
    const int ROBOT_IO_U_DO_10 = 40;
    const int ROBOT_IO_U_DO_11 = 41;
    const int ROBOT_IO_U_DO_12 = 42;
    const int ROBOT_IO_U_DO_13 = 43;
    const int ROBOT_IO_U_DO_14 = 44;
    const int ROBOT_IO_U_DO_15 = 45;
    const int ROBOT_IO_U_DO_16 = 46;
    const int ROBOT_IO_U_DO_17 = 47;

};

#endif // AUBOCONTROL_H
