#include "aubocontrol.h"

#define SERVER_HOST "127.0.0.1"
#define SERVER_PORT 8899
#define PI 3.1415926
AuboControl::AuboControl(QObject *parent) :
    QObject(parent)
{
}

void AuboControl::slot_openRobot()
{
    qDebug()<<"joint move";

    //ServiceInterface robotService;

    qDebug()<<"joint move1";

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** 接口调用: 登录 ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
       // std::cerr<<"登录成功."<<std::endl;
        qDebug()<<"登录成功.";
        //emit signal_robotesponse(QString::fromLocal8Bit("登录成功"));
        //robotOpenState=true;

    }
    else
    {
        //std::cerr<<"登录成功."<<std::endl;
         qDebug()<<"登录失败.111111111111111111";
        // emit signal_robotesponse(QString::fromLocal8Bit("登录失败"));
        // robotOpenState=false;
    }

     //std::cerr<<"机械臂初始化....."<<std::endl;


//    /** 如果是连接真实机械臂，需要对机械臂进行初始化　**/
//    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

//    //工具动力学参数
//    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
//    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

//    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**工具动力学参数**/,
//                                               6        /*碰撞等级*/,
//                                               true     /*是否允许读取位姿　默认为true*/,
//                                               true,    /*保留默认为true */
//                                               1000,    /*保留默认为1000 */
//                                               result); /*机械臂初始化*/
//    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
//    {
//        std::cerr<<"机械臂初始化成功."<<std::endl;
//        robotOpenState=true;
//    }
//    else
//    {
//        std::cerr<<"机械臂初始化失败."<<std::endl;
//        robotOpenState=false;
//    }

}

void AuboControl::slot_robotMotionInit()
{
    /** 业务块 **/
    /** 接口调用: 初始化运动属性 ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** 接口调用: 设置关节型运动的最大加速度 ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //接口要求单位是弧度
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** 接口调用: 设置关节型运动的最大速度 ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //接口要求单位是弧度
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    /** Interface call: Set the maximum acceleration of the end type motion Linear motion belongs to the end type motion***/
    double lineMoveMaxAcc;
    lineMoveMaxAcc = 1;   //Units m/s2
    robotService.robotServiceSetGlobalMoveEndMaxLineAcc(lineMoveMaxAcc);
    robotService.robotServiceSetGlobalMoveEndMaxAngleAcc(lineMoveMaxAcc);

    /** Interface call: Set the maximum speed of the end type motion Linear motion belongs to the end type motion***/
    double lineMoveMaxVelc;
    lineMoveMaxVelc = 1;   //Units m/s
    robotService.robotServiceSetGlobalMoveEndMaxLineVelc(lineMoveMaxVelc);
    robotService.robotServiceGetGlobalMoveEndMaxAngleVelc(lineMoveMaxVelc);
}


void AuboControl::slot_robotJointMove()
{
        int ret = aubo_robot_namespace::InterfaceCallSuccCode;

        slot_robotMotionInit();
        /** 机械臂运动到零位姿态 **/
        double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
        jointAngle[0]=15.0/180.0*M_PI;
        jointAngle[1]=0.0/180.0*M_PI;
        jointAngle[2]=90.0/180.0*M_PI;
        jointAngle[3]=0.0/180.0*M_PI;
        jointAngle[4]=90.0/180.0*M_PI;
        jointAngle[5]=0.0/180.0*M_PI;

        //Util::initJointAngleArray(jointAngle, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
        ret = robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"运动至零位姿态失败.　ret:"<<ret<<std::endl;
        }

        for(int i=0;i<3;i++)
        {
            /** 接口调用: 设置偏移量**/
            aubo_robot_namespace::MoveRelative relativeMoveOnBase;
            relativeMoveOnBase.ena = true;
            relativeMoveOnBase.relativePosition[0] = 0;
            relativeMoveOnBase.relativePosition[1] = 0;
            relativeMoveOnBase.relativePosition[2] = 0.05*(i%4);   //单位米

            relativeMoveOnBase.relativeOri.w=1;
            relativeMoveOnBase.relativeOri.x=0;
            relativeMoveOnBase.relativeOri.y=0;
            relativeMoveOnBase.relativeOri.z=0;
            robotService.robotServiceSetMoveRelativeParam(relativeMoveOnBase);

            /** 路点1运动 **/
           // Util::initJointAngleArray(jointAngle, 0.0/180.0*M_PI,  0.0/180.0*M_PI,  90.0/180.0*M_PI, 0.0/180.0*M_PI, 90.0/180.0*M_PI, 0.0/180.0*M_PI);
            jointAngle[0]=0.0/180.0*M_PI;
            jointAngle[1]=0.0/180.0*M_PI;
            jointAngle[2]=90.0/180.0*M_PI;
            jointAngle[3]=0.0/180.0*M_PI;
            jointAngle[4]=90.0/180.0*M_PI;
            jointAngle[5]=0.0/180.0*M_PI;
            robotService.robotServiceJointMove(jointAngle, true);
            if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
            {
                std::cerr<<"运动至路点1失败.　ret:"<<ret<<std::endl;
                break;
            }

            /** 路点2运动 **/
           // Util::initJointAngleArray(jointAngle, 15.0/180.0*M_PI,  0.0/180.0*M_PI,  90.0/180.0*M_PI, 0.0/180.0*M_PI, 90.0/180.0*M_PI, 0.0/180.0*M_PI);
            jointAngle[0]=15.0/180.0*M_PI;
            jointAngle[1]=0.0/180.0*M_PI;
            jointAngle[2]=90.0/180.0*M_PI;
            jointAngle[3]=0.0/180.0*M_PI;
            jointAngle[4]=90.0/180.0*M_PI;
            jointAngle[5]=0.0/180.0*M_PI;
            robotService.robotServiceJointMove(jointAngle, true);
            if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
            {
                std::cerr<<"运动至路点2失败.　ret:"<<ret<<std::endl;
                break;
            }
        }
        /** 机械臂Shutdown **/
       // robotService.robotServiceRobotShutdown();

        /** 接口调用: 退出登录　**/
       // robotService.robotServiceLogout()
}

void AuboControl::slot_getCurrentRobotBasicInfo()
{
    int retGetCurrentWaypointInfo=robotService.robotServiceGetCurrentWaypointInfo(mWayPoint_S);
    qDebug()<<"retGetCurrentWaypointInfo:"<<retGetCurrentWaypointInfo;
    int retGetJointAngleInfo=robotService.robotServiceGetJointAngleInfo(mJointParam);
    qDebug()<<"retGetJointAngleInfo:"<<retGetJointAngleInfo;
    posX=mWayPoint_S.cartPos.position.x;
    posY=mWayPoint_S.cartPos.position.y;
    posZ=mWayPoint_S.cartPos.position.z;

    oriX=mWayPoint_S.orientation.x;
    oriY=mWayPoint_S.orientation.y;
    oriZ=mWayPoint_S.orientation.z;
    oriW=mWayPoint_S.orientation.w;

    mOri=mWayPoint_S.orientation;

    joint1=mJointParam.jointPos[0]*180/PI;//弧度转角度
    joint2=mJointParam.jointPos[1]*180/PI;
    joint3=mJointParam.jointPos[2]*180/PI;
    joint4=mJointParam.jointPos[3]*180/PI;
    joint5=mJointParam.jointPos[4]*180/PI;
    joint6=mJointParam.jointPos[5]*180/PI;

    int retQuaternionToRPY=robotService.quaternionToRPY(mOri,mRpy);
    qDebug()<<"retQuaternionToRPY:"<<retQuaternionToRPY;

    rx=mRpy.rx*180/PI;//弧度转角度
    ry=mRpy.ry*180/PI;
    rz=mRpy.rz*180/PI;
    qDebug()<<"posX:"<<posX<<"posY:"<<posY<<"posZ:"<<posZ;
    qDebug()<<"rx:"<<rx<<"ry:"<<ry<<"rz:"<<rz;
    qDebug()<<"joint1:"<<joint1<<"joint2:"<<joint2<<"joint3:"<<joint3<<"joint4:"<<joint4<<"joint5:"<<joint5<<"joint6:"<<joint6;
   // emit signal_getRobotBasicInfo(posX,posY,posZ,rx,ry,rz,joint1,joint2,joint3,joint4,joint5,joint6);//触发界面控件显示机器人基础数据
}
