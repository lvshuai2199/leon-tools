TP_PLUGIN_NAME = ModbusDemo
#TP_PLUGIN_DEPENDS += \
TP_LIB_DEPENDS += \
    extensionsystem \
    stl
