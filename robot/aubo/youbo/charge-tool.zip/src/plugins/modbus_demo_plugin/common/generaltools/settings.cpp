#include "settings.h"

Settings::Settings() :
    QSettings("aubope", "aubope_system")
{
}
