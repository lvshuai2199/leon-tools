#pragma once

#include <QSettings>

class Settings : public QSettings
{
    Q_OBJECT

public:
    explicit Settings();
};
