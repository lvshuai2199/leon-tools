#pragma once

#include <QEvent>
#include <QWidget>
#include <QMap>
#include <QDebug>
#include <QTableWidget>
#include "common.h"
#include "ui_chargeconditionform.h"

class AutoResizeOriginalData
{
public:
    QRect dataRect;
    int minimumWidth;
    int minimumHeight;
    int maximumWidth;
    int maximumHeight;
};

enum LayoutTypeEnum{ GridLayout, HBoxLayout, VBoxLayout};

class AutoLayoutOriginalData
{
public:
    LayoutTypeEnum layoutType;
    int leftMargin;
    int topMargin;
    int rightMargin;
    int bottomMargin;
    int horSpacing;
    int verSpacing;
};

template<class UI>
class AbstractWidget : public QWidget
{
public:
    AbstractWidget(
            QWidget *parent,
            const int &minimumWidth, const int &minimumHeight,
            int maximumWidth = -1, int maximumHeight = -1) :
        QWidget(parent), ui(new UI)
    {
        m_minimumWidth = minimumWidth;
        m_minimumHeight = minimumHeight;
        m_maximumWidth = maximumWidth < 0? minimumWidth : maximumWidth;
        m_maximumHeight = maximumHeight < 0? minimumHeight : maximumHeight;
        m_horRatio = Common::instance()->m_horRatio;
        m_verRatio = Common::instance()->m_verRatio;
    }

    void initAllComponents()
    {
        for (QWidget *widget : this->findChildren<QWidget *>()) {
            QString objName = widget->objectName();
            if (objName.startsWith("qt_") || objName.startsWith("tab_")
                    || objName.startsWith("page_")
                    || objName.isEmpty())
                continue;

            AutoResizeOriginalData resizeData;
            resizeData.dataRect = widget->geometry();
            resizeData.minimumWidth = widget->minimumWidth();
            resizeData.minimumHeight = widget->minimumHeight();
            resizeData.maximumWidth = widget->maximumWidth();
            resizeData.maximumHeight = widget->maximumHeight();
            m_componentMap[widget] = resizeData;
        }

        for (QLayout *layout : this->findChildren<QLayout*>()) {
            if (layout->objectName().isEmpty())
                continue;

            QString className = layout->metaObject()->className();

            AutoLayoutOriginalData layoutData;

            if ("QGridLayout" == className) {
                layoutData.layoutType = GridLayout;
                QGridLayout *gridLayout = dynamic_cast<QGridLayout*>(layout);
                layoutData.horSpacing = gridLayout->horizontalSpacing();
                layoutData.verSpacing = gridLayout->verticalSpacing();
            } else if ("QHBoxLayout" == className) {
                layoutData.layoutType = HBoxLayout;
                layoutData.horSpacing = layout->spacing();
            } else if ("QVBoxLayout" == className) {
                layoutData.layoutType = VBoxLayout;
                layoutData.verSpacing = layout->spacing();
            }

            layout->getContentsMargins(
                        &layoutData.leftMargin, &layoutData.topMargin,
                        &layoutData.rightMargin, &layoutData.bottomMargin);

            m_layoutMap[layout] = layoutData;
        }
    }

    void setupUi(QWidget *widget)
    {
        ui->setupUi(widget);
        initAllComponents();

        this->setMinimumSize(m_minimumWidth * m_horRatio + 0.5f,
                             m_minimumHeight * m_verRatio + 0.5f);
        this->setMaximumSize(m_maximumWidth * m_horRatio + 0.5f
                             > 16777215?
                                 16777215
                               : m_maximumWidth * m_horRatio + 0.5f,
                             m_maximumHeight * m_verRatio + 0.5f
                             > 16777215?
                                 16777215
                               : m_maximumHeight * m_verRatio + 0.5f);

        Common::instance()->setRatioStyleSheet(this);
    }

    UI *ui;

protected:
    void changeEvent(QEvent *event)
    {
        if (0 != event && QEvent::LanguageChange == event->type())
            ui->retranslateUi(this);
        QWidget::changeEvent(event);
    }

    void resizeEvent(QResizeEvent * /*event*/)
    {
        autoResize();
    }

private:
    QMap<QWidget*, AutoResizeOriginalData> m_componentMap;
    QMap<QLayout*, AutoLayoutOriginalData> m_layoutMap;
    double m_horRatio;
    double m_verRatio;
    int m_minimumWidth;
    int m_minimumHeight;
    int m_maximumWidth;
    int m_maximumHeight;

    void autoResize()
    {
        for (QMap<QWidget*, AutoResizeOriginalData>::iterator p
             = m_componentMap.begin(); p != m_componentMap.end(); p++) {
            QWidget *widget = p.key();
            AutoResizeOriginalData resizeData = p.value();
            widget->setGeometry(
                        resizeData.dataRect.x() * m_horRatio + 0.5f,
                        resizeData.dataRect.y() * m_verRatio + 0.5f,
                        resizeData.dataRect.width() * m_horRatio + 0.5f,
                        resizeData.dataRect.height() * m_verRatio + 0.5f);

            widget->setMinimumSize(
                        resizeData.minimumWidth * m_horRatio + 0.5f,
                        resizeData.minimumHeight * m_verRatio + 0.5f);
            widget->setMaximumSize(
                        resizeData.maximumWidth * m_horRatio + 0.5f
                        > 16777215?
                            16777215
                          : resizeData.maximumWidth * m_horRatio + 0.5f,
                        resizeData.maximumHeight * m_verRatio + 0.5f
                        > 16777215?
                            16777215
                          : resizeData.maximumHeight * m_verRatio + 0.5f);

            if (widget->inherits("QTableWidget")) {
#ifndef X86_64
                dynamic_cast<QTableWidget*>(widget)->verticalHeader()
                        ->setDefaultSectionSize(
                            Common::instance()->m_defaultSectionSize);
#endif

                widget->setFixedHeight(
                            widget->height()
                            / Common::instance()->m_defaultSectionSize
                            * Common::instance()->m_defaultSectionSize
                            + 1);
            }
        }

        for (QMap<QLayout*, AutoLayoutOriginalData>::iterator p
             = m_layoutMap.begin(); p != m_layoutMap.end(); p++) {
            QLayout *layout = p.key();
            AutoLayoutOriginalData layoutData = p.value();
            layout->setContentsMargins(
                        layoutData.leftMargin * m_horRatio + 0.5f,
                        layoutData.topMargin * m_verRatio + 0.5f,
                        layoutData.rightMargin * m_horRatio + 0.5f,
                        layoutData.bottomMargin * m_verRatio + 0.5f);
            switch (layoutData.layoutType) {
            case GridLayout: {
                QGridLayout *gridLayout = dynamic_cast<QGridLayout*>(layout);
                gridLayout->setHorizontalSpacing(
                            layoutData.horSpacing * m_horRatio + 0.4f);
                gridLayout->setVerticalSpacing(
                            layoutData.verSpacing * m_verRatio + 0.4f);
                break;
            }
            case HBoxLayout:
                layout->setSpacing(
                            layoutData.horSpacing * m_horRatio + 0.4f);
                break;
            case VBoxLayout:
                layout->setSpacing(
                            layoutData.verSpacing * m_verRatio + 0.4f);
                break;
            default:
                break;
            }
        }
    }
};
