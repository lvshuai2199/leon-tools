#pragma once

#include <QApplication>
#include <QDesktopWidget>
#include <QMap>

#define BASE_APP_WIDTH 1024
#define BASE_APP_HEIGHT 768

#define BASE_SCROLL_BAR_SIZE 20
#define BASE_DEFAULT_SECTION_SIZE 30

#define SCREEN_WIDTH QApplication::desktop()->screenGeometry().width()
#define SCREEN_HEIGHT QApplication::desktop()->screenGeometry().height()

#define AVAILABLE_GEOMETRY_X QApplication::desktop()->availableGeometry().x()
#define AVAILABLE_GEOMETRY_Y QApplication::desktop()->availableGeometry().y()

#define AVAILABLE_GEOMETRY_WIDTH \
    QApplication::desktop()->availableGeometry().width()
#define AVAILABLE_GEOMETRY_HEIGHT \
    QApplication::desktop()->availableGeometry().height()

#define DATABASE_FILE_PATH "./Database"

#define COMBOBOX_MAX_VISIBLE_ITEMS 10

enum KeyboardType {
    KeyboardType_NoType,
    KeyboardType_DigitalKeyboard,
    KeyboardType_LogicalExpressionKeyboard,
    KeyboardType_FullKeyboard
};

class Common {
public:
    Common();

    static Common *instance();

    QString getUuid();

    int getRatioWidth(const int &width);
    int getRatioHeight(const int &height);
    int getMinRatioSize(const int &size);
    int getRatioFontWidth(const QString &content, int pixelSize = 16);
    QSize getRatioSize(const int &width, const int &height);
    void setRatioStyleSheet(QWidget *widget);

    QString m_pluginPath;

    bool m_isLoadingLanguage;

    double m_horRatio;
    double m_verRatio;
    double m_minRatio;
    int m_scrollBarWidth;
    int m_defaultSectionSize;
    int m_availableGeometryX;
    int m_availableGeometryY;
    int m_actualAppWidth;
    int m_actualAppHeight;
};
