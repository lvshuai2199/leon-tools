#include "common.h"
#include <QUuid>
#include "math.h"
#include "settings.h"

static Common *s_instance = 0;

Common *Common::instance()
{
    if (NULL == s_instance)
        s_instance = new Common;

    return s_instance;
}

Common::Common()
{
    m_pluginPath.clear();

    m_isLoadingLanguage = false;

    m_actualAppWidth = Settings()
            .value("Displays/Resolution")
            .toString().split("*", QString::SkipEmptyParts).at(0).toInt();
    m_actualAppHeight = Settings()
            .value("Displays/Resolution")
            .toString().split("*", QString::SkipEmptyParts).at(1).toInt();

    if (m_actualAppWidth < BASE_APP_WIDTH)
        m_actualAppWidth = BASE_APP_WIDTH;
    else if (m_actualAppWidth > AVAILABLE_GEOMETRY_WIDTH)
        m_actualAppWidth = SCREEN_WIDTH;

    if (m_actualAppHeight < BASE_APP_HEIGHT)
        m_actualAppHeight = BASE_APP_HEIGHT;
    else if (m_actualAppHeight > AVAILABLE_GEOMETRY_HEIGHT)
        m_actualAppHeight = SCREEN_HEIGHT;

    if (m_actualAppWidth <= AVAILABLE_GEOMETRY_WIDTH)
        m_availableGeometryX = AVAILABLE_GEOMETRY_X;
    else
        m_availableGeometryX = 0;

    if (m_actualAppHeight <= AVAILABLE_GEOMETRY_HEIGHT)
        m_availableGeometryY = AVAILABLE_GEOMETRY_Y;
    else
        m_availableGeometryY = 0;

    m_horRatio = m_actualAppWidth / 1.0 / BASE_APP_WIDTH;
    m_verRatio = m_actualAppHeight / 1.0 / BASE_APP_HEIGHT;
    m_minRatio = m_horRatio < m_verRatio? m_horRatio : m_verRatio;
    m_scrollBarWidth = getMinRatioSize(BASE_SCROLL_BAR_SIZE);
    m_defaultSectionSize = getRatioHeight(BASE_DEFAULT_SECTION_SIZE);
}

QString Common::getUuid()
{
    return QUuid::createUuid().toString()
            .remove("{").remove("}").remove("-");
}

int Common::getRatioWidth(const int &width)
{
    return width * m_horRatio + 0.5f;
}

int Common::getRatioHeight(const int &height)
{
    return height * m_verRatio + 0.5f;
}

int Common::getMinRatioSize(const int &size)
{
    return size * m_minRatio + 0.5f;
}

int Common::getRatioFontWidth(const QString &content, int pixelSize)
{
    QFont font;
    font.setPixelSize(pixelSize * Common::instance()->m_minRatio + 0.5f);
    return QFontMetrics(font).width(content) + 8;
}

QSize Common::getRatioSize(const int &width, const int &height)
{
    return QSize(width * m_horRatio + 0.5f, height * m_verRatio + 0.5f);
}

void Common::setRatioStyleSheet(QWidget *widget)
{
    QString pattern("([0-9]*)(px)");
    QRegExp re(pattern);
    QString styleSheet = widget->styleSheet();
    int startIndex = re.indexIn(styleSheet);

    while (startIndex >= 0) {
        int px = re.cap(1).toInt() * Common::instance()->m_minRatio
                + 0.5f;
        styleSheet.replace(re.pos(1), re.matchedLength(),
                           QString("%1px").arg(px));
        startIndex = re.indexIn(
                    styleSheet, startIndex + re.matchedLength());
    }

    widget->setStyleSheet(styleSheet);
}
