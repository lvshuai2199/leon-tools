#include "md5.h"
#include <cstring>
#include <sstream>
#include <iomanip>
#include <cstdint>

namespace crypto {

    // MD5常量 - 旋转位数
    static const uint32_t S11 = 7;
    static const uint32_t S12 = 12;
    static const uint32_t S13 = 17;
    static const uint32_t S14 = 22;
    static const uint32_t S21 = 5;
    static const uint32_t S22 = 9;
    static const uint32_t S23 = 14;
    static const uint32_t S24 = 20;
    static const uint32_t S31 = 4;
    static const uint32_t S32 = 11;
    static const uint32_t S33 = 16;
    static const uint32_t S34 = 23;
    static const uint32_t S41 = 6;
    static const uint32_t S42 = 10;
    static const uint32_t S43 = 15;
    static const uint32_t S44 = 21;

    // MD5常数表
    static const uint32_t K[64] = {
        0xD76AA478, 0xE8C7B756, 0x242070DB, 0xC1BDCEEE,
        0xF57C0FAF, 0x4787C62A, 0xA8304613, 0xFD469501,
        0x698098D8, 0x8B44F7AF, 0xFFFF5BB1, 0x895CD7BE,
        0x6B901122, 0xFD987193, 0xA679438E, 0x49B40821,
        0xF61E2562, 0xC040B340, 0x265E5A51, 0xE9B6C7AA,
        0xD62F105D, 0x02441453, 0xD8A1E681, 0xE7D3FBC8,
        0x21E1CDE6, 0xC33707D6, 0xF4D50D87, 0x455A14ED,
        0xA9E3E905, 0xFCEFA3F8, 0x676F02D9, 0x8D2A4C8A,
        0xFFFA3942, 0x8771F681, 0x6D9D6122, 0xFDE5380C,
        0xA4BEEA44, 0x4BDECFA9, 0xF6BB4B60, 0xBEBFBC70,
        0x289B7EC6, 0xEAA127FA, 0xD4EF3085, 0x04881D05,
        0xD9D4D039, 0xE6DB99E5, 0x1FA27CF8, 0xC4AC5665,
        0xF4292244, 0x432AFF97, 0xAB9423A7, 0xFC93A039,
        0x655B59C3, 0x8F0CCC92, 0xFFEFF47D, 0x85845DD1,
        0x6FA87E4F, 0xFE2CE6E0, 0xA3014314, 0x4E0811A1,
        0xF7537E82, 0xBD3AF235, 0x2AD7D2BB, 0xEB86D391
    };

    MD5::MD5() {
        init();
    }

    void MD5::init() {
        count = 0;

        // MD5初始化常量
        state[0] = 0x67452301;
        state[1] = 0xEFCDAB89;
        state[2] = 0x98BADCFE;
        state[3] = 0x10325476;
    }

    std::string MD5::encrypt(const std::string& input) {
        init();
        update(reinterpret_cast<const uint8_t*>(input.c_str()), input.length());
        return finalize();
    }

    std::string MD5::encrypt(const uint8_t* data, size_t length) {
        init();
        update(data, length);
        return finalize();
    }

    void MD5::update(const uint8_t* input, size_t length) {
        // 计算当前缓冲区中的字节数
        size_t index = (count / 8) % 64;

        // 更新已处理的位数
        count += (length * 8);

        // 计算还需要多少字节才能填满一个64字节块
        size_t partLen = 64 - index;
        size_t i = 0;

        // 如果输入数据足够填满当前块
        if (length >= partLen) {
            // 将输入数据复制到缓冲区，填满当前块
            std::memcpy(&buffer[index], input, partLen);
            // 处理这个完整的块
            transform(buffer);

            // 处理剩余的完整块
            for (i = partLen; i + 63 < length; i += 64) {
                transform(&input[i]);
            }

            index = 0;
        }

        // 将剩余的数据复制到缓冲区
        std::memcpy(&buffer[index], &input[i], length - i);
    }

    std::string MD5::finalize() {
        // 创建消息长度的位表示（小端序）
        uint8_t bits[8];
        uint64_t bitCount = count;

        for (int i = 0; i < 8; i++) {
            bits[i] = static_cast<uint8_t>((bitCount >> (i * 8)) & 0xFF);
        }

        // 计算需要填充的字节数
        size_t index = (count / 8) % 64;
        size_t padLen = (index < 56) ? (56 - index) : (120 - index);

        // 创建填充数据
        uint8_t padding[64];
        padding[0] = 0x80;
        for (size_t i = 1; i < padLen; i++) {
            padding[i] = 0;
        }

        // 添加填充数据和消息长度
        update(padding, padLen);
        update(bits, 8);

        // 生成最终结果
        uint8_t digest[16];
        for (int i = 0; i < 4; i++) {
            digest[i * 4] = static_cast<uint8_t>(state[i] & 0xFF);
            digest[i * 4 + 1] = static_cast<uint8_t>((state[i] >> 8) & 0xFF);
            digest[i * 4 + 2] = static_cast<uint8_t>((state[i] >> 16) & 0xFF);
            digest[i * 4 + 3] = static_cast<uint8_t>((state[i] >> 24) & 0xFF);
        }

        return bytesToHexString(digest, 16);
    }

    void MD5::transform(const uint8_t block[64]) {
        uint32_t a = state[0], b = state[1], c = state[2], d = state[3];
        uint32_t x[16];

        // 将输入块转换为32位字数组（小端序）
        for (int i = 0; i < 16; i++) {
            x[i] = static_cast<uint32_t>(block[i * 4]) |
                   (static_cast<uint32_t>(block[i * 4 + 1]) << 8) |
                   (static_cast<uint32_t>(block[i * 4 + 2]) << 16) |
                   (static_cast<uint32_t>(block[i * 4 + 3]) << 24);
        }

        // 第一轮 (F)
        a = b + rotateLeft(a + F(b, c, d) + x[0] + K[0], S11);
        d = a + rotateLeft(d + F(a, b, c) + x[1] + K[1], S12);
        c = d + rotateLeft(c + F(d, a, b) + x[2] + K[2], S13);
        b = c + rotateLeft(b + F(c, d, a) + x[3] + K[3], S14);
        a = b + rotateLeft(a + F(b, c, d) + x[4] + K[4], S11);
        d = a + rotateLeft(d + F(a, b, c) + x[5] + K[5], S12);
        c = d + rotateLeft(c + F(d, a, b) + x[6] + K[6], S13);
        b = c + rotateLeft(b + F(c, d, a) + x[7] + K[7], S14);
        a = b + rotateLeft(a + F(b, c, d) + x[8] + K[8], S11);
        d = a + rotateLeft(d + F(a, b, c) + x[9] + K[9], S12);
        c = d + rotateLeft(c + F(d, a, b) + x[10] + K[10], S13);
        b = c + rotateLeft(b + F(c, d, a) + x[11] + K[11], S14);
        a = b + rotateLeft(a + F(b, c, d) + x[12] + K[12], S11);
        d = a + rotateLeft(d + F(a, b, c) + x[13] + K[13], S12);
        c = d + rotateLeft(c + F(d, a, b) + x[14] + K[14], S13);
        b = c + rotateLeft(b + F(c, d, a) + x[15] + K[15], S14);

        // 第二轮 (G)
        a = b + rotateLeft(a + G(b, c, d) + x[1] + K[16], S21);
        d = a + rotateLeft(d + G(a, b, c) + x[6] + K[17], S22);
        c = d + rotateLeft(c + G(d, a, b) + x[11] + K[18], S23);
        b = c + rotateLeft(b + G(c, d, a) + x[0] + K[19], S24);
        a = b + rotateLeft(a + G(b, c, d) + x[5] + K[20], S21);
        d = a + rotateLeft(d + G(a, b, c) + x[10] + K[21], S22);
        c = d + rotateLeft(c + G(d, a, b) + x[15] + K[22], S23);
        b = c + rotateLeft(b + G(c, d, a) + x[4] + K[23], S24);
        a = b + rotateLeft(a + G(b, c, d) + x[9] + K[24], S21);
        d = a + rotateLeft(d + G(a, b, c) + x[14] + K[25], S22);
        c = d + rotateLeft(c + G(d, a, b) + x[3] + K[26], S23);
        b = c + rotateLeft(b + G(c, d, a) + x[8] + K[27], S24);
        a = b + rotateLeft(a + G(b, c, d) + x[13] + K[28], S21);
        d = a + rotateLeft(d + G(a, b, c) + x[2] + K[29], S22);
        c = d + rotateLeft(c + G(d, a, b) + x[7] + K[30], S23);
        b = c + rotateLeft(b + G(c, d, a) + x[12] + K[31], S24);

        // 第三轮 (H)
        a = b + rotateLeft(a + H(b, c, d) + x[5] + K[32], S31);
        d = a + rotateLeft(d + H(a, b, c) + x[8] + K[33], S32);
        c = d + rotateLeft(c + H(d, a, b) + x[11] + K[34], S33);
        b = c + rotateLeft(b + H(c, d, a) + x[14] + K[35], S34);
        a = b + rotateLeft(a + H(b, c, d) + x[1] + K[36], S31);
        d = a + rotateLeft(d + H(a, b, c) + x[4] + K[37], S32);
        c = d + rotateLeft(c + H(d, a, b) + x[7] + K[38], S33);
        b = c + rotateLeft(b + H(c, d, a) + x[10] + K[39], S34);
        a = b + rotateLeft(a + H(b, c, d) + x[13] + K[40], S31);
        d = a + rotateLeft(d + H(a, b, c) + x[0] + K[41], S32);
        c = d + rotateLeft(c + H(d, a, b) + x[3] + K[42], S33);
        b = c + rotateLeft(b + H(c, d, a) + x[6] + K[43], S34);
        a = b + rotateLeft(a + H(b, c, d) + x[9] + K[44], S31);
        d = a + rotateLeft(d + H(a, b, c) + x[12] + K[45], S32);
        c = d + rotateLeft(c + H(d, a, b) + x[15] + K[46], S33);
        b = c + rotateLeft(b + H(c, d, a) + x[2] + K[47], S34);

        // 第四轮 (I)
        a = b + rotateLeft(a + I(b, c, d) + x[0] + K[48], S41);
        d = a + rotateLeft(d + I(a, b, c) + x[7] + K[49], S42);
        c = d + rotateLeft(c + I(d, a, b) + x[14] + K[50], S43);
        b = c + rotateLeft(b + I(c, d, a) + x[5] + K[51], S44);
        a = b + rotateLeft(a + I(b, c, d) + x[12] + K[52], S41);
        d = a + rotateLeft(d + I(a, b, c) + x[3] + K[53], S42);
        c = d + rotateLeft(c + I(d, a, b) + x[10] + K[54], S43);
        b = c + rotateLeft(b + I(c, d, a) + x[1] + K[55], S44);
        a = b + rotateLeft(a + I(b, c, d) + x[8] + K[56], S41);
        d = a + rotateLeft(d + I(a, b, c) + x[15] + K[57], S42);
        c = d + rotateLeft(c + I(d, a, b) + x[6] + K[58], S43);
        b = c + rotateLeft(b + I(c, d, a) + x[13] + K[59], S44);
        a = b + rotateLeft(a + I(b, c, d) + x[4] + K[60], S41);
        d = a + rotateLeft(d + I(a, b, c) + x[11] + K[61], S42);
        c = d + rotateLeft(c + I(d, a, b) + x[2] + K[62], S43);
        b = c + rotateLeft(b + I(c, d, a) + x[9] + K[63], S44);

        state[0] += a;
        state[1] += b;
        state[2] += c;
        state[3] += d;
    }

    uint32_t MD5::F(uint32_t x, uint32_t y, uint32_t z) {
        return (x & y) | (~x & z);
    }

    uint32_t MD5::G(uint32_t x, uint32_t y, uint32_t z) {
        return (x & z) | (y & ~z);
    }

    uint32_t MD5::H(uint32_t x, uint32_t y, uint32_t z) {
        return x ^ y ^ z;
    }

    uint32_t MD5::I(uint32_t x, uint32_t y, uint32_t z) {
        return y ^ (x | ~z);
    }

    uint32_t MD5::rotateLeft(uint32_t x, uint32_t n) {
        return (x << n) | (x >> (32 - n));
    }

    std::string MD5::bytesToHexString(const uint8_t* bytes, size_t length) {
        std::stringstream ss;
        ss << std::hex << std::setfill('0');
        for (size_t i = 0; i < length; i++) {
            ss << std::setw(2) << static_cast<unsigned>(bytes[i]);
        }
        return ss.str();
    }

}
