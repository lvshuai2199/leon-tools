#ifndef MD5_H
#define MD5_H

#include <string>

namespace crypto {
    class MD5 {
    public:
        MD5();

        // 计算字符串的MD5值
        std::string encrypt(const std::string& input);

        // 计算二进制数据的MD5值
        std::string encrypt(const uint8_t* data, size_t length);

    private:
        // MD5状态
        uint32_t state[4];
        uint64_t count;  // 已处理的位数
        uint8_t buffer[64];

        // 初始化MD5上下文
        void init();

        // 更新MD5上下文
        void update(const uint8_t* input, size_t length);

        // 完成MD5计算并返回结果
        std::string finalize();

        // MD5核心变换函数
        void transform(const uint8_t block[64]);

        // 辅助函数
        static uint32_t F(uint32_t x, uint32_t y, uint32_t z);
        static uint32_t G(uint32_t x, uint32_t y, uint32_t z);
        static uint32_t H(uint32_t x, uint32_t y, uint32_t z);
        static uint32_t I(uint32_t x, uint32_t y, uint32_t z);
        static uint32_t rotateLeft(uint32_t x, uint32_t n);

        // 将结果转换为十六进制字符串
        std::string bytesToHexString(const uint8_t* bytes, size_t length);
    };
}

#endif // MD5_H
