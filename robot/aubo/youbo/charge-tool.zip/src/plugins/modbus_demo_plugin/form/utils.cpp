#include "utils.h"
#include <QStringList>
#include <cstring>
#include <cstdint>
#include <sstream>
#include <iomanip>
#include <cstdlib>

#include <QSet>

#include <string>

//sha256增加
#include <QCryptographicHash>
#include <QMessageAuthenticationCode>

#include "md5.h"

utils::utils()
{
}

// ==================== 凯撒密码 ====================

QString utils::caesarEncrypt(const QString& text, int shift) {
    QString result;
    for (QChar c : text) {
        if (c.isLetter()) {
            QChar base = c.isLower() ? 'a' : 'A';
            result += QChar(((c.toLatin1() - base.toLatin1() + shift) % 26 + 26) % 26 + base.toLatin1());
        } else {
            result += c;
        }
    }
    return result;
}

QString utils::caesarDecrypt(const QString& text, int shift) {
    return caesarEncrypt(text, 26 - (shift % 26));
}

bool utils::isCaesarCipher(const QString& original, const QString& encrypted, int shift) {
    return caesarEncrypt(original, shift) == encrypted;
}

// ==================== 数据处理工具 ====================

int utils::findStringIndex(const QStringList& list, const QString& target) {
    for (int i = 0; i < list.size(); ++i) {
        if (list[i] == target) {
            return i;
        }
    }
    return -1;
}

QStringList utils::getUniqueColumnData(const QList<QStringList>& sheetList, int columnIndex) {
    QSet<QString> uniqueDataSet;
    for (const QStringList& row : sheetList) {
        if (columnIndex >= 0 && columnIndex < row.size()) {
            uniqueDataSet.insert(row[columnIndex]);
        }
    }
    return QStringList(uniqueDataSet.toList());
}

bool utils::haveCommonItems(const QStringList& list1, const QStringList& list2) {
    QSet<QString> set1 = QSet<QString>::fromList(list1);
    QSet<QString> set2 = QSet<QString>::fromList(list2);
    QSet<QString> intersection = set1.intersect(set2);
    return !intersection.isEmpty();
}

bool utils::startsWithPrefix(const QString& str, const QString& prefix) {
    return str.startsWith(prefix);
}

QString utils::generateRandomString(int length) {
    const QString characters = "abcdefghijklmnopqrstuvwxyz";
    QString randomString;
    for (int i = 0; i < length; ++i) {
        int index = std::rand() % characters.length();
        randomString += characters[index];
    }
    return randomString;
}

// ==================== MD5 常量 ====================

static const uint32_t S11 = 7;
static const uint32_t S12 = 12;
static const uint32_t S13 = 17;
static const uint32_t S14 = 22;
static const uint32_t S21 = 5;
static const uint32_t S22 = 9;
static const uint32_t S23 = 14;
static const uint32_t S24 = 20;
static const uint32_t S31 = 4;
static const uint32_t S32 = 11;
static const uint32_t S33 = 16;
static const uint32_t S34 = 23;
static const uint32_t S41 = 6;
static const uint32_t S42 = 10;
static const uint32_t S43 = 15;
static const uint32_t S44 = 21;

static const uint32_t K[64] = {
    0xD76AA478, 0xE8C7B756, 0x242070DB, 0xC1BDCEEE,
    0xF57C0FAF, 0x4787C62A, 0xA8304613, 0xFD469501,
    0x698098D8, 0x8B44F7AF, 0xFFFF5BB1, 0x895CD7BE,
    0x6B901122, 0xFD987193, 0xA679438E, 0x49B40821,
    0xF61E2562, 0xC040B340, 0x265E5A51, 0xE9B6C7AA,
    0xD62F105D, 0x02441453, 0xD8A1E681, 0xE7D3FBC8,
    0x21E1CDE6, 0xC33707D6, 0xF4D50D87, 0x455A14ED,
    0xA9E3E905, 0xFCEFA3F8, 0x676F02D9, 0x8D2A4C8A,
    0xFFFA3942, 0x8771F681, 0x6D9D6122, 0xFDE5380C,
    0xA4BEEA44, 0x4BDECFA9, 0xF6BB4B60, 0xBEBFBC70,
    0x289B7EC6, 0xEAA127FA, 0xD4EF3085, 0x04881D05,
    0xD9D4D039, 0xE6DB99E5, 0x1FA27CF8, 0xC4AC5665,
    0xF4292244, 0x432AFF97, 0xAB9423A7, 0xFC93A039,
    0x655B59C3, 0x8F0CCC92, 0xFFEFF47D, 0x85845DD1,
    0x6FA87E4F, 0xFE2CE6E0, 0xA3014314, 0x4E0811A1,
    0xF7537E82, 0xBD3AF235, 0x2AD7D2BB, 0xEB86D391
};

// ==================== MD5 辅助函数 ====================

uint32_t utils::F(uint32_t x, uint32_t y, uint32_t z) {
    return (x & y) | (~x & z);
}

uint32_t utils::G(uint32_t x, uint32_t y, uint32_t z) {
    return (x & z) | (y & ~z);
}

uint32_t utils::H(uint32_t x, uint32_t y, uint32_t z) {
    return x ^ y ^ z;
}

uint32_t utils::I(uint32_t x, uint32_t y, uint32_t z) {
    return y ^ (x | ~z);
}

uint32_t utils::rotateLeft(uint32_t x, uint32_t n) {
    return (x << n) | (x >> (32 - n));
}

std::string utils::bytesToHexString(const uint8_t* bytes, size_t length) {
    std::stringstream ss;
    ss << std::hex << std::setfill('0');
    for (size_t i = 0; i < length; i++) {
        ss << std::setw(2) << static_cast<unsigned>(bytes[i]);
    }
    return ss.str();
}

// ==================== MD5 核心函数 ====================

void utils::MD5init() {
    count = 0;
    state[0] = 0x67452301;
    state[1] = 0xEFCDAB89;
    state[2] = 0x98BADCFE;
    state[3] = 0x10325476;
}

// ✅ 使用宏定义来正确处理 MD5 操作
#define FF(a, b, c, d, x, s, ac) { \
    (a) += F((b), (c), (d)) + (x) + (ac); \
    (a) = rotateLeft((a), (s)); \
    (a) += (b); \
}

#define GG(a, b, c, d, x, s, ac) { \
    (a) += G((b), (c), (d)) + (x) + (ac); \
    (a) = rotateLeft((a), (s)); \
    (a) += (b); \
}

#define HH(a, b, c, d, x, s, ac) { \
    (a) += H((b), (c), (d)) + (x) + (ac); \
    (a) = rotateLeft((a), (s)); \
    (a) += (b); \
}

#define II(a, b, c, d, x, s, ac) { \
    (a) += I((b), (c), (d)) + (x) + (ac); \
    (a) = rotateLeft((a), (s)); \
    (a) += (b); \
}

void utils::transform(const uint8_t block[64]) {
    uint32_t a = state[0], b = state[1], c = state[2], d = state[3];
    uint32_t x[16];

    // 将输入块转换为32位字数组（小端序）
    for (int i = 0; i < 16; i++) {
        x[i] = static_cast<uint32_t>(block[i * 4]) |
               (static_cast<uint32_t>(block[i * 4 + 1]) << 8) |
               (static_cast<uint32_t>(block[i * 4 + 2]) << 16) |
               (static_cast<uint32_t>(block[i * 4 + 3]) << 24);
    }

    // ===== 第一轮 (F) =====
    FF(a, b, c, d, x[0], S11, K[0]);
    FF(d, a, b, c, x[1], S12, K[1]);
    FF(c, d, a, b, x[2], S13, K[2]);
    FF(b, c, d, a, x[3], S14, K[3]);
    FF(a, b, c, d, x[4], S11, K[4]);
    FF(d, a, b, c, x[5], S12, K[5]);
    FF(c, d, a, b, x[6], S13, K[6]);
    FF(b, c, d, a, x[7], S14, K[7]);
    FF(a, b, c, d, x[8], S11, K[8]);
    FF(d, a, b, c, x[9], S12, K[9]);
    FF(c, d, a, b, x[10], S13, K[10]);
    FF(b, c, d, a, x[11], S14, K[11]);
    FF(a, b, c, d, x[12], S11, K[12]);
    FF(d, a, b, c, x[13], S12, K[13]);
    FF(c, d, a, b, x[14], S13, K[14]);
    FF(b, c, d, a, x[15], S14, K[15]);

    // ===== 第二轮 (G) =====
    GG(a, b, c, d, x[1], S21, K[16]);
    GG(d, a, b, c, x[6], S22, K[17]);
    GG(c, d, a, b, x[11], S23, K[18]);
    GG(b, c, d, a, x[0], S24, K[19]);
    GG(a, b, c, d, x[5], S21, K[20]);
    GG(d, a, b, c, x[10], S22, K[21]);
    GG(c, d, a, b, x[15], S23, K[22]);
    GG(b, c, d, a, x[4], S24, K[23]);
    GG(a, b, c, d, x[9], S21, K[24]);
    GG(d, a, b, c, x[14], S22, K[25]);
    GG(c, d, a, b, x[3], S23, K[26]);
    GG(b, c, d, a, x[8], S24, K[27]);
    GG(a, b, c, d, x[13], S21, K[28]);
    GG(d, a, b, c, x[2], S22, K[29]);
    GG(c, d, a, b, x[7], S23, K[30]);
    GG(b, c, d, a, x[12], S24, K[31]);

    // ===== 第三轮 (H) =====
    HH(a, b, c, d, x[5], S31, K[32]);
    HH(d, a, b, c, x[8], S32, K[33]);
    HH(c, d, a, b, x[11], S33, K[34]);
    HH(b, c, d, a, x[14], S34, K[35]);
    HH(a, b, c, d, x[1], S31, K[36]);
    HH(d, a, b, c, x[4], S32, K[37]);
    HH(c, d, a, b, x[7], S33, K[38]);
    HH(b, c, d, a, x[10], S34, K[39]);
    HH(a, b, c, d, x[13], S31, K[40]);
    HH(d, a, b, c, x[0], S32, K[41]);
    HH(c, d, a, b, x[3], S33, K[42]);
    HH(b, c, d, a, x[6], S34, K[43]);
    HH(a, b, c, d, x[9], S31, K[44]);
    HH(d, a, b, c, x[12], S32, K[45]);
    HH(c, d, a, b, x[15], S33, K[46]);
    HH(b, c, d, a, x[2], S34, K[47]);

    // ===== 第四轮 (I) =====
    II(a, b, c, d, x[0], S41, K[48]);
    II(d, a, b, c, x[7], S42, K[49]);
    II(c, d, a, b, x[14], S43, K[50]);
    II(b, c, d, a, x[5], S44, K[51]);
    II(a, b, c, d, x[12], S41, K[52]);
    II(d, a, b, c, x[3], S42, K[53]);
    II(c, d, a, b, x[10], S43, K[54]);
    II(b, c, d, a, x[1], S44, K[55]);
    II(a, b, c, d, x[8], S41, K[56]);
    II(d, a, b, c, x[15], S42, K[57]);
    II(c, d, a, b, x[6], S43, K[58]);
    II(b, c, d, a, x[13], S44, K[59]);
    II(a, b, c, d, x[4], S41, K[60]);
    II(d, a, b, c, x[11], S42, K[61]);
    II(c, d, a, b, x[2], S43, K[62]);
    II(b, c, d, a, x[9], S44, K[63]);

    // 更新状态
    state[0] += a;
    state[1] += b;
    state[2] += c;
    state[3] += d;
}

std::string utils::encrypt(const std::string& input) {
    MD5init();

    const uint8_t* data = reinterpret_cast<const uint8_t*>(input.c_str());
    size_t length = input.length();

    size_t index = 0;
    size_t dataLen = length;

    // 分块处理数据
    while (dataLen >= 64) {
        transform(&data[index]);
        index += 64;
        dataLen -= 64;
    }

    // 处理剩余数据
    uint8_t buffer[64] = {0};
    std::memcpy(buffer, &data[index], dataLen);

    // 填充数据
    size_t padLen = (dataLen < 56) ? (56 - dataLen) : (120 - dataLen);
    buffer[dataLen] = 0x80;
    std::memset(&buffer[dataLen + 1], 0, padLen - 1);

    // 添加消息长度
    uint64_t bitCount = length * 8;
    for (int i = 0; i < 8; i++) {
        buffer[56 + i] = static_cast<uint8_t>((bitCount >> (i * 8)) & 0xFF);
    }

    // 处理最后的块
    if (dataLen < 56) {
        transform(buffer);
    } else {
        transform(buffer);
        std::memset(buffer, 0, 64);
        for (int i = 0; i < 8; i++) {
            buffer[56 + i] = static_cast<uint8_t>((bitCount >> (i * 8)) & 0xFF);
        }
        transform(buffer);
    }

    // 生成结果
    uint8_t digest[16];
    for (int i = 0; i < 4; i++) {
        digest[i * 4] = static_cast<uint8_t>(state[i] & 0xFF);
        digest[i * 4 + 1] = static_cast<uint8_t>((state[i] >> 8) & 0xFF);
        digest[i * 4 + 2] = static_cast<uint8_t>((state[i] >> 16) & 0xFF);
        digest[i * 4 + 3] = static_cast<uint8_t>((state[i] >> 24) & 0xFF);
    }

    return bytesToHexString(digest, 16);
}

bool utils::isMd5Cipher(const QString &original, const QString &encrypted)
{
    if (encrypted.isEmpty()) {
        return false;
    }

    std::string lockWords = original.toStdString() + "youbo_leon";
    std::string passwords = encrypt(lockWords);

    int minLen = encrypted.length();

    for (int i = 0; i < minLen; ++i) {
        if (passwords[i] != encrypted[i]) {
            return false;
        }
    }

    return true;
}


bool utils::isSHA256Cipher(const QString &original, const QString &encrypted)
{
    if (encrypted.isEmpty()) {
        return false;
    }

    // 使用sha5
    QString secretKey = "youbo_leon";
    QString originWords = original;
    QString expectedHash = QString::fromStdString(
        hmacSha256(originWords.toStdString(), secretKey.toStdString())
    );

    std::string passwords = expectedHash.toStdString();

    int minLen = encrypted.length();

    for (int i = 0; i < minLen; ++i) {
        if (passwords[i] != encrypted[i]) {
            return false;
        }
    }

    return true;
}



std::string utils::hmacSha256(const std::string& message, const std::string& key) {
    QByteArray keyArray = QByteArray::fromStdString(key);
    QByteArray messageArray = QByteArray::fromStdString(message);

    QMessageAuthenticationCode code(QCryptographicHash::Sha256, keyArray);
    code.addData(messageArray);

    return code.result().toHex().toStdString();
}
