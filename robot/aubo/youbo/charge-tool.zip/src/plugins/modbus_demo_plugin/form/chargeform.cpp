#include "chargeform.h"
#include "ui_chargeform.h"

// Qt 核心
#include <QTimer>
#include <QDateTime>

// Qt GUI/Widgets
//#include <QFocusEvent>
//#include <QMessageBox>
#include <QFileDialog>
#include <QInputDialog>
#include <QClipboard>
#include <QStyledItemDelegate>
#include <QPainter>
#include <QStyleOptionViewItem>

// Qt 文件操作
#include <QFile>
#include <QTextStream>

// 标准库
#include <set>
#include <unistd.h>

// 项目头文件
#include "utils.h"
#include "custominputdialog.h"

// 定义 QTimer 对象
QTimer timer;


chargeform::chargeform(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chargeform)
{
    ui->setupUi(this);

    // 初始化日志模型
    m_logModel = new QStringListModel(this);
    ui->setting_info_listview->setModel(m_logModel);

    // 界面东西处理
    pageLogoShow();

    keyBoardInit();
    alphanumericKeyBoardInit();

    // 根据配置翻译界面按钮
    on_setting_languageCombox_currentIndexChanged(configCon.configFileLoad(8).toInt());

    // 提前处理线程连接,防止二次绑定
    startDataRetrievalThread();

    systemPassCheck(false);
    ui->modSendEdit->setWhatsThis(
                QString::number(KeyboardType_DigitalKeyboard));
}

chargeform::~chargeform()
{
    delete ui;
}

void chargeform::systemPassCheck(bool useInput){

    /**
     * @brief passCheckType
     * 设置密码校验方式
     * 0. 设置为凯撒密码加密
     * 1. 设置为MD5密码加密
     * 2. 使用sha256加密
     */
    int passCheckType = 2;
    // 整体逻辑：先判断密码是否正确，如果不正确，退出，正确后检查文件更新时间，更新时间不符合要求，校验失败
    utils *myutil = new utils(); // 创建 utils 类型的指针
//    std::unique_ptr<utils> myutil(new utils());

    QStringList passKeys = configCon.getPassKeys();

    while (passKeys.isEmpty()) {
        configCon.updatePassKeys();
        passKeys = configCon.getPassKeys();
    }
    // 获取原密文字符
    QString originWords;
    // 设置具体使用哪边的密码
    QString realPass;
    if(useInput){
        originWords = ui->curLockWords->text();
        realPass = ui->passwordInput->text();
    }else {
        originWords = passKeys.at(0);
        realPass = passKeys.at(1);
    }

    //将明文分割为密码及日期校验方式
    QString firstPart; // 定义前6位
    QString remainingPart; // 定义剩余部分

    int length = realPass.length();

    if (length <= 6) {
        // 密码长度小于或等于8位
        firstPart = realPass;
        remainingPart = ""; // 剩余部分为空
    } else {
        // 密码长度大于6位
        firstPart = realPass.left(6); // 前6位
        remainingPart = realPass.mid(6); // 剩余部分
    }

    // 输出结果
    qDebug() << "前6位:" << firstPart;
    qDebug() << "剩余部分:" << remainingPart;

    //判定剩余的变量是否属于枚举类型定义
    int index;

    if(passCheckType == 0){
        // QStringList stringList = {"一个月", "两个月", "四个月", "六个月", "永久"};
        QStringList stringList = {"youbo1M", "youbo2M", "youbo4M", "youbo6M", "youboPERM"};
        index = myutil->findStringIndex(stringList, remainingPart);
    }else{
        index = remainingPart.length();
    }

    //检索时长
    int eff_duration;
    switch(index){
        case 1:
            eff_duration = TWO_MONTHS;
            break;
        case 2:
            eff_duration = FOUR_MONTHS;
            break;
        case 3:
            eff_duration = SIX_MONTHS;
            break;
        case 4:
            eff_duration = THIRTEEN_MONTHS;
            break;
        case 7:
            eff_duration = PERMANENT;
            break;
        default:
            eff_duration = ONE_MONTH;
    }

    // 此处flag用来记录对应的密码校验情况
    int flag = 0;
    // 使用箭头操作符 -> 调用 isCaesarCipher 函数
    if(myutil->isSHA256Cipher(originWords,realPass)){
        std::cout << "sha256密码校验成功,开始判断密码生效日期。" << std::endl;
        flag = 1;
    }else {
        std::cout << "密码文本校验失败。" << std::endl;
        QMessageBox::warning(nullptr,"Warning","密码校验失败！");
    }
    // 只有在flag为1的情况下才校验时间,若密码都没通过,则校验失败,只有在不是输入的情况下才需要校验时间,否则不需要
    if(flag && useInput == false){
        // 刷新标志,进行日期的判断
        flag = 0;
        //开始校验时间
        QDateTime currentDateTime = QDateTime::currentDateTime();
        QDateTime storedDateTime = QDateTime::fromString(passKeys.at(2), "yyyy-MM-dd"); // 根据实际格式解析时间

        // 计算时间差（以天为单位）
        int daysDifference = storedDateTime.daysTo(currentDateTime);

        // 判断是否超过30天
        if (daysDifference > eff_duration) {
            std::cout << "时间差超过30天，判定失败。" << std::endl;
            QMessageBox::warning(nullptr,"Warning","密码已过期，请重新输入！");
        }else {
            flag = 1;
        }
    }

    // 临时增加,密码默认校验成功
    // int flag = 1; //flag为0时,创建线程自动重置所有io信号,发送信号给plc对应地址位锁定plc信号
//    QMessageBox::warning(nullptr,"Warning","密码校验直接成功");
    //连接到线程函数
//    startDataRetrievalThread();
    if(flag == 0){
        if(!useInput)this->on_lockWRe_btn_clicked();
        ui->curLockWords->show();
        ui->passwordInput->show();
        ui->unlockBtn->show();
        ui->mainpageWidgets->setCurrentIndex(1);
        //如果超过时间，更新凯撒密码表格
        configCon.updatePassKeys();
        // 密码校验失败,开启防护模式,自动重置modbus信号
        emit signal_threadCon_lock(true);
    }else {
        // 若密码为用户输入,则从输入当天更新数据
        if(useInput){
            configCon.updatePassKeys(realPass, originWords);
//            configCon.updatePassKeys("realPass", "originWords");
        }
        //系统整体初始化
        ui->mainpageWidgets->setCurrentIndex(0);
//        db_Con.dbExportInit();
        getDbCon().dbExportInit();
        getLogger().log("数据库初始化");
        chargeInit();
        emit signal_threadCon_lock(false);
    }
}


void chargeform::pageLogoShow() {
    // 创建 QLabel 并设置样式和文本
    QLabel *floatingLabel = new QLabel("", ui->frame);

    // 设置 QLabel 的大小
    floatingLabel->setFixedSize(116, 52);  // 设置为你希望显示的大小

    // 获取文件根地址
    QString filePath = configCon.configFileLoad(6);
    // 加载图片
    QPixmap pixmap( filePath + "LOGO.png");

    // 检查图片是否成功加载
    if (!pixmap.isNull()) {
        // 设置 QLabel 的图片
        floatingLabel->setPixmap(pixmap.scaled(floatingLabel->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
    } else {
        qDebug() << "Failed to load image.";
    }


//    // 计算右上角位置（右边距10像素，上边距10像素）
//    int margin = 10;  // 边距
//    int x = ui->mainpageWidgets->width() - floatingLabel->width() - margin;
//    int y = margin;

//    // 移动到右上角
//    floatingLabel->move(x, y);

//    // 显示 QLabel
//    floatingLabel->show();
    // 检查 mainpageWidgets 是否已有布局
    QLayout *existingLayout = ui->mainpageWidgets->layout();
    QHBoxLayout *topLayout = nullptr;

    if (existingLayout) {
        // 如果已有布局，创建一个水平布局放在顶部
        topLayout = new QHBoxLayout();
        topLayout->addStretch();  // 左侧弹簧，将 logo 推到右边
        topLayout->addWidget(floatingLabel);
        topLayout->setContentsMargins(0, 10, 10, 0);  // 设置边距（左、上、右、下）

        // 将水平布局插入到现有布局的顶部
        if (QVBoxLayout *vLayout = qobject_cast<QVBoxLayout*>(existingLayout)) {
            vLayout->insertLayout(0, topLayout);
        } else if (QGridLayout *gLayout = qobject_cast<QGridLayout*>(existingLayout)) {
            gLayout->addLayout(topLayout, 0, 0, 1, -1, Qt::AlignTop | Qt::AlignRight);
        }
    } else {
        // 如果没有布局，创建新的布局
        QVBoxLayout *mainLayout = new QVBoxLayout(ui->mainpageWidgets);

        // 创建顶部水平布局
        topLayout = new QHBoxLayout();
        topLayout->addStretch();  // 左侧弹簧
        topLayout->addWidget(floatingLabel);
        topLayout->setContentsMargins(0, 10, 10, 0);

        mainLayout->addLayout(topLayout);
        mainLayout->addStretch();  // 底部弹簧

        ui->mainpageWidgets->setLayout(mainLayout);
    }
}


void chargeform::chargeInit()
{
    // ========== 1. 表格委托设置 ==========
    CircleDelegate *delegate = new CircleDelegate(ui->signals_tw);
    ui->signals_tw->setItemDelegateForColumn(4, delegate);

    // ========== 2. 数据库和线程初始化 ==========
    db_manTh = new db_manage();
    commDB = new QThread();
    db_manTh->moveToThread(commDB);
    commDB->start();

    // ========== 3. 表格基础设置 ==========
    ui->signals_tw->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->variables_tw->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->signals_tw->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->variables_tw->setSelectionBehavior(QAbstractItemView::SelectRows);

    // ========== 4. 按钮隐藏 ==========
    ui->signal_search_btn->hide();
    ui->var_signalsearch_btn->hide();
    ui->signal_save_btn->hide();
    ui->signal_import_btn->hide();

    // ========== 5. 信号槽连接 ==========
    // 数据库信号
    connect(db_manTh, SIGNAL(dataLoaded()), this, SLOT(onDataLoaded()), Qt::QueuedConnection);
    connect(this, SIGNAL(signal_test(QString)), db_manTh, SLOT(slot_test(QString)), Qt::QueuedConnection);

    // 表格选择信号
    connect(ui->signals_tw, &QTableWidget::itemSelectionChanged, this, &chargeform::onItemSelected);
    connect(ui->variables_tw, &QTableWidget::itemSelectionChanged, this, &chargeform::onVariableItemSelected);

    // 组合框信号
    connect(ui->help_fileCombox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            this, &chargeform::fileViewPathEx);

    connect(ui->signal_combox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            this, &chargeform::on_signal_search_btn_clicked);

    connect(ui->var_combox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            this, &chargeform::on_var_signalsearch_btn_clicked);

    connect(ui->curProBox, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            this, &chargeform::on_var_ex2cur_btn_clicked);

    // ========== 6. 页面初始化 ==========
    curProductName = configCon.configFileLoad(5);
    qDebug() << "当前加载的产品为：" << this->curProductName;
    fillSignalCombox();
    fillProductCombox();

    ex_page2modify_status();
    ui->pageWidgets->setCurrentIndex(0);

    // ========== 7. 分页设置 ==========
    pageInfo.currentPage = 1;
    pageInfo.itemsPerPage = 14;
    pageInfoShow();

    // ========== 8. UI 尺寸设置 ==========
    ui->selectVarValuePose->setFixedWidth(200);

    // ========== 9. 文件路径初始化 ==========
    fileRootPath = configCon.configFileLoad(6);
    fillFileViewCombox();

    // ========== 10. 定时器设置（文本滚动） ==========
    connect(&timer, &QTimer::timeout, [this]() {
        QString text = ui->selectVarAnnotate->text();
        if (text.isEmpty()) return;

        QString scrolledText = text.mid(scrollIndex) + text.left(scrollIndex);
        ui->selectVarAnnotate->setText(scrolledText);
        scrollIndex = (scrollIndex + 1) % text.length();

        qDebug() << "滚动数据：" << scrolledText;
        qDebug() << "scrollIndex:" << scrollIndex << "text.length():" << text.length();
    });
    // timer.start(1000); // 需要时启动
}

void chargeform::fileViewTextShow()
{
    // 文件路径
    QString filePath = fileViewTextPath;

    // 创建 QFile 对象并打开文件
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        qDebug() << "Could not open file: " << file.errorString();
        ui->fileViewTextEdit->setPlainText("文件打开失败！！！\n请查看文件是否存在～～～\n文件地址：" + filePath);
        return;
    }

    // 使用 QTextStream 读取文件内容
    QTextStream in(&file);
    QString fileShowStr = "";
    while (!in.atEnd())
    {
        QString line = in.readLine();
        // 处理每一行的内容，这里简单打印出来
        qDebug() << line;
        fileShowStr += line + "\n";
    }

    // 关闭文件
    file.close();
    ui->fileViewTextEdit->setPlainText(fileShowStr);

}

void chargeform::fileViewPathEx()
{
    this->fileViewTextPath = fileRootPath + ui->help_fileCombox->currentText();
    fileViewTextShow();
}

void chargeform::pageInfoSet(int currentPage)
{
    try{
        // 循环页页数处理
        if (currentPage < 1) {
            pageInfo.currentPage = pageInfo.totalPages;
        }else if (currentPage > pageInfo.totalPages) {
            pageInfo.currentPage = 1;
        }else{
            pageInfo.currentPage = currentPage;
        }

        if(ui->pageWidgets->currentIndex() == SIGNALSPAGE){
            // 搜索数据处理
            if(ui->signal_combox->currentText() == "无"){
                pageInfo.searchText = "";
            }else {
                pageInfo.searchText = ui->signal_combox->currentText();
            }
            pageInfo.itemsPerPage = 14;

        }else{
            // 搜索数据处理
            if(ui->var_combox->currentText() == "无"){
                pageInfo.searchText = "";
            }else {
                pageInfo.searchText = ui->var_combox->currentText();
            }
            pageInfo.itemsPerPage = 13;
        }

        if(ui->pageWidgets->currentIndex() == SIGNALSPAGE){
//            pageInfo.totalItems = db_Con.getTotalItemCount(pageInfo.searchText);
            pageInfo.totalItems = getDbCon().getTotalItemCount(pageInfo.searchText);
            pageInfo.totalPages = (pageInfo.totalItems + pageInfo.itemsPerPage - 1) / pageInfo.itemsPerPage;
            ui->currentPageNumLbel->setText(QString::number(pageInfo.currentPage));
            ui->totalPageNumLbel->setText("共"+ QString::number(pageInfo.totalPages)+"页");
        }else{
            if(curProductName != "" || curProductName != nullptr){
//                pageInfo.totalItems = db_Con.getVarTotalItemCount(pageInfo.searchText, curProductName);
                pageInfo.totalItems = getDbCon().getVarTotalItemCount(pageInfo.searchText, curProductName);
            }else{
                pageInfo.totalItems = 0;
            }
            pageInfo.totalPages = (pageInfo.totalItems + pageInfo.itemsPerPage - 1) / pageInfo.itemsPerPage;
            ui->varPageCur->setText(QString::number(pageInfo.currentPage));
            ui->varPageTotal->setText("共"+ QString::number(pageInfo.totalPages)+"页");
        }

    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("页面数据出现异常；Exception caught: ") + e.what());
        qDebug() << "页面数据出现异常；Exception caught: " << e.what();
    }
}


/**
 * @brief chargeform::startDataRetrievalThread
 * 多线程进行数据的实时更新
 */
void chargeform::startDataRetrievalThread()
{
    DataRetrievalThread *thread = new DataRetrievalThread();

    //修改对应的界面ui
    connect(thread, &DataRetrievalThread::dataSendToMaster, this, &chargeform::updateSignalsTable);

    thread->start();
    connect(this, &chargeform::signal_threadCon, thread , &DataRetrievalThread::exchangeThreadStatus, Qt::QueuedConnection);
    connect(this, &chargeform::signal_threadCon_lock, thread , &DataRetrievalThread::exchangeThreadStatus_lock, Qt::QueuedConnection);
    connect(this, &chargeform::signal_thread_start, thread , &DataRetrievalThread::set_thread_start, Qt::QueuedConnection);
    connect(this, &chargeform::signal_setlockModAddr, thread , &DataRetrievalThread::set_lock_mod_addr, Qt::QueuedConnection);

    //接收对应的数据传入参数
    connect(this, &chargeform::signal_deliever, thread , &DataRetrievalThread::signalGet, Qt::QueuedConnection);

    emit signal_thread_start();
    // 初始化线程中的锁定地址
    emit signal_setlockModAddr(configCon.configFileLoad(7).toInt());

}

void chargeform::on_signal_import_btn_clicked()
{
    QString selectPathStr = openFile();
    qDebug() << "选择的文件为:" << selectPathStr;

    // 在子线程中加载 Excel 文件
    emit db_manTh->ExcelLoad(selectPathStr);
}

//表格的处理
//插入新行
void chargeform::Add2datasheet(QList<QStringList> dataList){

    // 清空表格
    ui->signals_tw->setRowCount(0);
    // 设置表格的行列数
    int numRows = dataList.size();
    int numCols = numRows > 0 ? dataList[0].size() : 0;
    ui->signals_tw->setRowCount(numRows);
    ui->signals_tw->setColumnCount(numCols);

    // 填充表格数据
    for (int row = 0; row < numRows; ++row) {
        const QStringList& rowData = dataList[row];
        for (int col = 0; col < numCols; ++col) {
            const QString& cellData = rowData[col];
            QTableWidgetItem *item = new QTableWidgetItem(cellData);
            ui->signals_tw->setItem(row, col, item);
        }
    }
}

//表格的处理
//插入新行
void chargeform::Add2Vardatasheet(QList<QStringList> dataList){

    // 清空表格
    ui->variables_tw->setRowCount(0);
    // 设置表格的行列数
    int numRows = dataList.size();
    if(numRows > 0){
        int numCols = numRows > 0 ? dataList[0].size() : 0;
        ui->variables_tw->setRowCount(numRows);
        ui->variables_tw->setColumnCount(numCols);

        // 填充表格数据
        for (int row = 0; row < numRows; ++row) {
            const QStringList& rowData = dataList[row];
            for (int col = 0; col < numCols; ++col) {
                const QString& cellData = rowData[col];
                QTableWidgetItem *item = new QTableWidgetItem(cellData);
                ui->variables_tw->setItem(row, col, item);
            }
        }
    }
}

QList<QStringList> chargeform::fileLoad2QList()
{
    QString filePath_str = openFile();
    qDebug() << "选择的文件地址为:" << filePath_str ;

    QList<QStringList> dataArray;
    if(filePath_str == ""){
        QMessageBox::warning(nullptr,"INFO",QString("已取消文件导入！"));
        return dataArray;
    }
    // 打开CSV文件，指定UTF-8编码
    QFile file(filePath_str);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "Could not open file";
        QMessageBox::warning(nullptr,"warning",QString("无法打开文件：%1").arg(filePath_str));
        return dataArray;
    }

    QTextStream in(&file);
    // 指定使用UTF-8编码
    in.setCodec("UTF-8");

    // 先将索引调整到第二行
    in.readLine();
    //判断是否含有不符合规定字符
    bool hasUnExceptData = false;
    // 读取文件内容
    QStringList rowData;
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(","); // 以逗号分隔字段

        // 输出每一行数据
        qDebug() << "读取到的行数据：" << fields;

        // 将每7个字段作为一行存入dataArray
        rowData.append(fields);
        if (rowData.size() >= 6) {
            if(rowData[2] == "Bool"){
                if(rowData[1].startsWith("V_B_")){
                    rowData[1] = rowData[1];
                }else {
                    rowData[1] = "V_B_" + rowData[1];
                }

            }else if(rowData[2] == "Int"){
                if(rowData[1].startsWith("V_I_")){
                    rowData[1] = rowData[1];
                }else {
                    rowData[1] = "V_I_" + rowData[1];
                }
            }else if(rowData[2] == "Double"){
                if(rowData[1].startsWith("V_D_")){
                    rowData[1] = rowData[1];
                }else {
                    rowData[1] = "V_D_" + rowData[1];
                }
            }else if(rowData[2] == "Pose"){
                if(rowData[1].startsWith("V_P_")){
                    rowData[1] = rowData[1];
                }else {
                    rowData[1] = "V_P_" + rowData[1];
                }
            }else {
                hasUnExceptData = true;
            }
            dataArray.append(rowData);
            rowData.clear();
        }
    }

    if(hasUnExceptData){
        QMessageBox::warning(nullptr, "Confirm Loaded",
                                      QString("导入数据中包含非设定变量类型，请检查后再进行存储！！！").arg(curProductName));
    }

    // 如果文件内容的字段数不是7的倍数，最后一行可能会少于7个字段，这里需要额外处理
    if (!rowData.isEmpty()) {
        dataArray.append(rowData);
    }

    file.close();

    return dataArray;
}

void chargeform::compareSignalsData()
{
    qDebug() << "页面table数据更新";
}

void chargeform::keyBoardInit()
{
    // 创建一个新的 QWidget 用作数字键盘
    numericKeyboard = new QWidget(this);

    numericKeyboard->setGeometry(220, 350, 250, 200); // 增加宽度以容纳点按钮

    numericKeyboard->setStyleSheet("background-color: lightblue;");
    numericKeyboard->setFocusPolicy(Qt::StrongFocus);

    // 设置布局管理器，比如QGridLayout
    QGridLayout *layout = new QGridLayout(numericKeyboard);

    // 添加数字按钮
    for (int i = 1; i < 10; ++i) {  // 从1开始
        QPushButton *button = new QPushButton(QString::number(i), numericKeyboard);
        layout->addWidget(button, (i - 1) / 3, (i - 1) % 3);
        connect(button, &QPushButton::clicked, [=]() {
            handleButtonClick(button->text());
        });
    }

    // 添加 0 按钮
    QPushButton *zeroButton = new QPushButton("0", numericKeyboard);
    layout->addWidget(zeroButton, 3, 1);
    connect(zeroButton, &QPushButton::clicked, [=]() {
        handleButtonClick(zeroButton->text());
    });

    // 添加 点 按钮
    QPushButton *pointButton = new QPushButton(".", numericKeyboard);
    layout->addWidget(pointButton, 3, 2);
    connect(pointButton, &QPushButton::clicked, [=]() {
        handleButtonClick(pointButton->text());
    });

    // 添加 删除 按钮
    QPushButton *deleteButton = new QPushButton("删除", numericKeyboard);
    layout->addWidget(deleteButton, 4, 0);
    connect(deleteButton, &QPushButton::clicked, [=]() {
        handleDeleteButton();
    });

    QPushButton *clearButton = new QPushButton("清空", numericKeyboard);
    layout->addWidget(clearButton, 4, 1);
    connect(clearButton, &QPushButton::clicked, [=]() {
//        handleClearButton();
        if (ui->pageWidgets->currentIndex() == SIGNALSPAGE) {
            ui->modSendEdit->setText("");
        } else if (ui->pageWidgets->currentIndex() == VARIABLESPAGE) {
            ui->selectVarValueNumber->setText("");
        }
    });

    // 添加 关闭 按钮
    QPushButton *closeButton = new QPushButton("关闭", numericKeyboard);
    layout->addWidget(closeButton, 4, 2);
    connect(closeButton, &QPushButton::clicked, [=]() {
        numericKeyboard->hide(); // 关闭数字键盘部件
    });

    numericKeyboard->hide();
}

// 处理按钮点击事件
void chargeform::handleButtonClick(const QString &text)
{
    if (ui->pageWidgets->currentIndex() == SIGNALSPAGE) {
        ui->modSendEdit->setText(ui->modSendEdit->text() + text);
    } else if (ui->pageWidgets->currentIndex() == VARIABLESPAGE) {
        ui->selectVarValueNumber->setText(ui->selectVarValueNumber->text() + text);
    }
}

// 处理删除按钮点击事件
void chargeform::handleDeleteButton()
{
    QString currentText;
    if (ui->pageWidgets->currentIndex() == SIGNALSPAGE) {
        currentText = ui->modSendEdit->text();
    } else if (ui->pageWidgets->currentIndex() == VARIABLESPAGE) {
        currentText = ui->selectVarValueNumber->text();
    }
    if (!currentText.isEmpty()) {
        if (ui->pageWidgets->currentIndex() == SIGNALSPAGE) {
            ui->modSendEdit->setText(currentText.left(currentText.length() - 1));
        } else if (ui->pageWidgets->currentIndex() == VARIABLESPAGE) {
            ui->selectVarValueNumber->setText(currentText.left(currentText.length() - 1));
        }
    }
}

void chargeform::alphanumericKeyBoardInit()
{
    // 创建字母数字键盘 - 缩小尺寸
    alphanumericKeyboard = new QWidget(this);
    alphanumericKeyboard->setGeometry(150, 300, 380, 260);  // 缩小整体尺寸
    alphanumericKeyboard->setStyleSheet("background-color: #f0f0f0; border-radius: 8px;");
    alphanumericKeyboard->setFocusPolicy(Qt::StrongFocus);

    QGridLayout *layout = new QGridLayout(alphanumericKeyboard);
    layout->setSpacing(3);  // 减小间距
    layout->setContentsMargins(8, 8, 8, 8);  // 减小边距

    isUpperCase = false;

    // 第一行：数字键 1-0
    QStringList numberRow = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    for (int i = 0; i < numberRow.size(); ++i) {
        QPushButton *button = new QPushButton(numberRow[i], alphanumericKeyboard);
        button->setFixedSize(35, 35);  // 缩小按钮
        button->setStyleSheet("QPushButton { background-color: white; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; }"
                              "QPushButton:pressed { background-color: #d0d0d0; }");
        layout->addWidget(button, 0, i);
        connect(button, &QPushButton::clicked, [=]() {
            handleKeyboardButtonClick(button->text());
        });
    }

    // 第二行：字母 Q-P
    QStringList row1 = {"Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P"};
    for (int i = 0; i < row1.size(); ++i) {
        QPushButton *button = new QPushButton(row1[i].toLower(), alphanumericKeyboard);
        button->setFixedSize(35, 35);
        button->setObjectName("letterKey_" + QString::number(i));
        button->setStyleSheet("QPushButton { background-color: white; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; }"
                              "QPushButton:pressed { background-color: #d0d0d0; }");
        layout->addWidget(button, 1, i);
        connect(button, &QPushButton::clicked, [=]() {
            handleKeyboardButtonClick(button->text());
        });
    }

    // 第三行：字母 A-L
    QStringList row2 = {"A", "S", "D", "F", "G", "H", "J", "K", "L"};
    for (int i = 0; i < row2.size(); ++i) {
        QPushButton *button = new QPushButton(row2[i].toLower(), alphanumericKeyboard);
        button->setFixedSize(35, 35);
        button->setObjectName("letterKey_" + QString::number(10 + i));
        button->setStyleSheet("QPushButton { background-color: white; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; }"
                              "QPushButton:pressed { background-color: #d0d0d0; }");
        layout->addWidget(button, 2, i);
        connect(button, &QPushButton::clicked, [=]() {
            handleKeyboardButtonClick(button->text());
        });
    }

    // 第四行：Shift + 字母 Z-M
    QPushButton *shiftButton = new QPushButton("⇧", alphanumericKeyboard);
    shiftButton->setFixedSize(50, 35);  // Shift稍大一点
    shiftButton->setStyleSheet("QPushButton { background-color: #e0e0e0; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; font-weight: bold; }"
                               "QPushButton:pressed { background-color: #c0c0c0; }");
    layout->addWidget(shiftButton, 3, 0, 1, 1);
    connect(shiftButton, &QPushButton::clicked, [=]() {
        isUpperCase = !isUpperCase;
        QList<QPushButton*> letterButtons = alphanumericKeyboard->findChildren<QPushButton*>(QRegExp("letterKey_.*"));
        for (QPushButton *btn : letterButtons) {
            if (isUpperCase) {
                btn->setText(btn->text().toUpper());
                shiftButton->setStyleSheet("QPushButton { background-color: #4CAF50; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; font-weight: bold; color: white; }"
                                          "QPushButton:pressed { background-color: #45a049; }");
            } else {
                btn->setText(btn->text().toLower());
                shiftButton->setStyleSheet("QPushButton { background-color: #e0e0e0; border: 1px solid #ccc; border-radius: 4px; font-size: 16px; font-weight: bold; }"
                                          "QPushButton:pressed { background-color: #c0c0c0; }");
            }
        }
    });

    QStringList row3 = {"Z", "X", "C", "V", "B", "N", "M"};
    for (int i = 0; i < row3.size(); ++i) {
        QPushButton *button = new QPushButton(row3[i].toLower(), alphanumericKeyboard);
        button->setFixedSize(35, 35);
        button->setObjectName("letterKey_" + QString::number(19 + i));
        button->setStyleSheet("QPushButton { background-color: white; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; }"
                              "QPushButton:pressed { background-color: #d0d0d0; }");
        layout->addWidget(button, 3, i + 2);
        connect(button, &QPushButton::clicked, [=]() {
            handleKeyboardButtonClick(button->text());
        });
    }

    // 删除按钮（放在第四行右侧）
    QPushButton *deleteButton = new QPushButton("删除", alphanumericKeyboard);
    deleteButton->setFixedSize(50, 35);
    deleteButton->setStyleSheet("QPushButton { background-color: #ff9800; border: 1px solid #ccc; border-radius: 4px; font-size: 12px; color: white; }"
                               "QPushButton:pressed { background-color: #e68900; }");
    layout->addWidget(deleteButton, 3, 9, 1, 1);
    connect(deleteButton, &QPushButton::clicked, [=]() {
        handleKeyboardDeleteButton();
    });

    // 第五行：特殊字符和功能键
    QPushButton *underscoreButton = new QPushButton("_", alphanumericKeyboard);
    underscoreButton->setFixedSize(35, 35);
    underscoreButton->setStyleSheet("QPushButton { background-color: white; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; }"
                                   "QPushButton:pressed { background-color: #d0d0d0; }");
    layout->addWidget(underscoreButton, 4, 0);
    connect(underscoreButton, &QPushButton::clicked, [=]() {
        handleKeyboardButtonClick("_");
    });

    QPushButton *minusButton = new QPushButton("-", alphanumericKeyboard);
    minusButton->setFixedSize(35, 35);
    minusButton->setStyleSheet("QPushButton { background-color: white; border: 1px solid #ccc; border-radius: 4px; font-size: 13px; }"
                              "QPushButton:pressed { background-color: #d0d0d0; }");
    layout->addWidget(minusButton, 4, 1);
    connect(minusButton, &QPushButton::clicked, [=]() {
        handleKeyboardButtonClick("-");
    });

    // 空格
    QPushButton *spaceButton = new QPushButton("空格", alphanumericKeyboard);
    spaceButton->setFixedSize(150, 35);  // 缩小空格键
    spaceButton->setStyleSheet("QPushButton { background-color: white; border: 1px solid #ccc; border-radius: 4px; font-size: 12px; }"
                              "QPushButton:pressed { background-color: #d0d0d0; }");
    layout->addWidget(spaceButton, 4, 2, 1, 4);
    connect(spaceButton, &QPushButton::clicked, [=]() {
        handleKeyboardButtonClick(" ");
    });

    // 清空按钮
    QPushButton *clearButton = new QPushButton("清空", alphanumericKeyboard);
    clearButton->setFixedSize(55, 35);
    clearButton->setStyleSheet("QPushButton { background-color: #f44336; border: 1px solid #ccc; border-radius: 4px; font-size: 12px; color: white; }"
                              "QPushButton:pressed { background-color: #da190b; }");
    layout->addWidget(clearButton, 4, 6, 1, 2);
    connect(clearButton, &QPushButton::clicked, [=]() {
        handleKeyboardClearButton();
    });

    // 关闭按钮
    QPushButton *closeButton = new QPushButton("关闭", alphanumericKeyboard);
    closeButton->setFixedSize(55, 35);
    closeButton->setStyleSheet("QPushButton { background-color: #607d8b; border: 1px solid #ccc; border-radius: 4px; font-size: 12px; color: white; }"
                              "QPushButton:pressed { background-color: #4b626d; }");
    layout->addWidget(closeButton, 4, 8, 1, 2);
    connect(closeButton, &QPushButton::clicked, [=]() {
        alphanumericKeyboard->hide();
    });

    alphanumericKeyboard->hide();
}

void chargeform::handleKeyboardButtonClick(const QString &text)
{
    // 在 passwordInput 中插入字符
    ui->passwordInput->insert(text);
}

void chargeform::handleKeyboardDeleteButton()
{
    // 删除最后一个字符
    QString currentText = ui->passwordInput->text();
    if (!currentText.isEmpty()) {
        currentText.chop(1);
        ui->passwordInput->setText(currentText);
    }
}

void chargeform::handleKeyboardClearButton()
{
    // 清空输入框
    ui->passwordInput->clear();
}

void chargeform::showKeyBoard()
{
    numericKeyboard->show();
}



int chargeform::setModData(int sendData)
{
    int var;
    if (sendData == 1){
        var = 1;
    }else if(sendData == 0){
        var = 0;
    }else {
        var = ui->modSendEdit->text().toInt();
    }
    // 在需要的地方获取当前选中项的值
    int addr = ui->signal_addr_label->text().toInt();

    int modWriRes;
    QString modType = ui->signal_type_label->text();
    if(modType.contains("COIL")){
        modWriRes = modCon.on_pbn_set_digital(addr,var);
    }else {
        modWriRes = modCon.on_pbn_set_register(addr,var);
    }

    QString showText = nullptr;
    if(modWriRes == aubo_robot_namespace::InterfaceCallSuccCode){
        qDebug() << "modbus写入成功";
        // 将返回值写入QTableWidget的对应行的第五列
        showText = QString::number(var);

    }else{
        qDebug() << "modbus写入失败";
        // 将返回值写入QTableWidget的对应行的第五列
        showText = "写入失败";
        modCon.mod_reconnect();
        return modWriRes;
    }
    // 获取当前选中的行
//    item = new QTableWidgetItem(showText);
//    int selectedRow = ui->signals_tw->currentRow();
//    ui->signals_tw->setItem(selectedRow, 4, item); // 第五列索引为4
    ui->modSignalStatus->setText(showText);

    ui->modSendEdit->setText("");
    return 0;
}


chargeform::PageInfo chargeform::getPageInfo(int currentPage, int itemsPerPage, QString serchText)
{
    try{
        qDebug()<< "进入getPageInfo函数，currentPage：" << currentPage << "itemsPerPage:" << itemsPerPage << "serchText:" << serchText;

        //分页错误产生原因，导致栈溢出
        int startIndex = (currentPage - 1) * itemsPerPage;
        if (startIndex + itemsPerPage > pageInfo.totalItems) {
            itemsPerPage = pageInfo.totalItems - startIndex;
        }

        int curPageIndex = ui->pageWidgets->currentIndex();
        itemsPerPage = 10;
        // 在 getPageInfo 内部添加调试
        qDebug() << "Checking db_Con state...";
//        if (!db_Con.isValid()) { // 假设你有判断有效性的方法
//            getLogger().log("错误：数据库对象 db_Con 已失效或未初始化！");
//            // 尝试重新获取连接或报错
//        }


        // 修正你代码中的字符串判空 (QString 不要跟 nullptr 比较)
        if (!curProductName.isEmpty()) { // QString 建议用 isEmpty()
//            pageInfo.items = db_Con.queryProductDatabase(startIndex, itemsPerPage, serchText, curProductName);
            pageInfo.items = getDbCon().queryProductDatabase(startIndex, itemsPerPage, serchText, curProductName);
        }

        // 只有在信号页面才会发送对应的机构信息供给检索
        if(curPageIndex == SIGNALSPAGE){
            // 1. 使用 QString 的 .arg() 依次替换占位符
            QString sendPageInfo = QString("发送分页数据信息：1.起始位置：%1，2. 检索数量%2，关键词：%3")
                                .arg(startIndex)
                                .arg(itemsPerPage)
                                .arg(serchText); // 这里假设 data 是你上一条提问中的 std::vector

            // 2. 传递给日志函数（如果 log 接受 std::string，记得加 .toStdString()）
            getLogger().log(sendPageInfo);
//            pageInfo.items = db_Con.queryDatabase(startIndex, itemsPerPage, serchText);
            pageInfo.items = getDbCon().queryDatabase(startIndex, itemsPerPage, serchText);
            //在这里会获取到页面的所有信息，在这里建立页面的构建数组，将对应的页面信息填入到对应的变量中
            current_pageSignales = pageInfo.items;
            // 位置966
            getLogger().log("位置966，接收数据数量：" + QString::number(pageInfo.items.size()));
            // 注册自定义类型
            qRegisterMetaType<std::vector<std::vector<std::string>>>("std::vector<std::vector<std::string>>");

            emit signal_deliever(current_pageSignales);
        }else if(curPageIndex == VARIABLESPAGE){
            if(curProductName != "" || curProductName != nullptr){
//                pageInfo.items = db_Con.queryProductDatabase(startIndex, itemsPerPage, serchText, curProductName);
                pageInfo.items = getDbCon().queryProductDatabase(startIndex, itemsPerPage, serchText, curProductName);
            }
        }

        return pageInfo;

    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("Exception caught: ") + e.what());
        qDebug() << "Exception caught: " << e.what();
        return pageInfo;
    }
}

void chargeform::fillSignalCombox()
{
    QStringList uniqueItems;
//    db_Con.getfFilterFlag(uniqueItems);
    getDbCon().getfFilterFlag(uniqueItems);

    // 去重
    uniqueItems.removeDuplicates();

    // 填充 QComboBox
    ui->signal_combox->clear();  // 清空下拉框内容
    ui->signal_combox->addItem("无");
    for (const QString &item : uniqueItems) {
        ui->signal_combox->addItem(item);
    }

}

void chargeform::fillProductCombox()
{
    ignoreIndexChanged = true;
    QStringList uniqueItems;
//    db_Con.getfFilterFlag(uniqueItems,curProductName);
    getDbCon().getfFilterFlag(uniqueItems,curProductName);

    // 去重
    uniqueItems.removeDuplicates();

    // 填充 QComboBox
    ui->var_combox->clear();  // 清空下拉框内容
    ui->var_combox->addItem("无");
    for (const QString &item : uniqueItems) {
        ui->var_combox->addItem(item);
    }

    uniqueItems.clear();
//    db_Con.getProductItems(uniqueItems);
    getDbCon().getProductItems(uniqueItems);

    // 去重
    uniqueItems.removeDuplicates();

    // 填充 QComboBox
    ui->curProBox->clear();  // 清空下拉框内容
//    for (const QString &item : uniqueItems) {
//        ui->curProBox->addItem(item);
//    }
    // 使用 addItems 一次性添加所有项到 QComboBox
    ui->curProBox->addItems(uniqueItems);
    //显示当前产品名称
    ui->curProBox->setCurrentText(curProductName);
    ignoreIndexChanged = false;
}


void chargeform::fillFileViewCombox()
{
    //文件填充,使用获取文件夹下所有文件的方式替代写入文件名称
    QDir dir(fileRootPath);

    // 设置过滤条件：只获取 .txt 文件
    QStringList filters;
    filters << "*.txt";
    dir.setNameFilters(filters);

    // 获取所有 txt 文件
    QStringList files = dir.entryList(QDir::Files);

    // 用逗号连接所有文件名
    QString result = files.join(",");
    // 使用自动获取所有txt文件代替从配置读取
//    QString getComboxData = configCon.configFileLoad(2);
//    QStringList uniqueItems = getComboxData.split(",");

    QStringList uniqueItems = files;
    // 去重
    uniqueItems.removeDuplicates();

    if(uniqueItems.size() != 0){
        // 填充 QComboBox
        ui->help_fileCombox->clear();  // 清空下拉框内容
        for (const QString &item : uniqueItems) {
            ui->help_fileCombox->addItem(item);
        }
        fileViewTextPath = uniqueItems[0];
    }

}

//文件选择的弹窗
// 创建一个槽函数，用于打开选择文件对话框
QString chargeform::openFile()
{
    QString filePath = QFileDialog::getOpenFileName(this, tr("选择文件"), QDir::homePath(), tr("所有文件 (*.*)"));

    if (!filePath.isEmpty()) {
        // 用户选择了文件，可以在这里进行相应操作，比如读取文件内容等
        qDebug() << "Selected file path: " << filePath;
    } else {
        // 用户取消了选择文件操作
        qDebug() << "未选择任何文件";
    }

    return filePath;
}

void chargeform::onDataLoaded()
{
    try{
        // 在主线程中更新 UI
        qDebug() << "传回数据接收";

        // 使用PageInfo获取分页信息
        pageInfo = getPageInfo(pageInfo.currentPage, pageInfo.itemsPerPage, pageInfo.searchText);

        // 输出分页信息
        std::cout << "Current page: " << pageInfo.currentPage << std::endl;
        std::cout << "Total pages: " << pageInfo.totalPages << std::endl;
        std::cout << "Items per page: " << pageInfo.itemsPerPage << std::endl;
        std::cout << "Total items: " << pageInfo.totalItems << std::endl;
        std::cout << "Items on current page:" << std::endl;

        // 1. 使用 QString 的 .arg() 依次替换占位符
        QString logMsg = QString("获取到的分页数据为：1.当前页：%1，2. 总页数：%2，每页数据数量：%3，总数据量：%4，当前页数量：%5")
                            .arg(pageInfo.currentPage)
                            .arg(pageInfo.totalPages)
                            .arg(pageInfo.itemsPerPage)
                            .arg(pageInfo.totalItems)
                            .arg(pageInfo.items.size()); // 这里假设 data 是你上一条提问中的 std::vector

        // 2. 传递给日志函数（如果 log 接受 std::string，记得加 .toStdString()）
        getLogger().log(logMsg);

    //    for (const auto& item : pageInfo.items) {
    //        std::cout << item << std::endl;
    //    }

        std::vector<std::vector<std::string>> &data = pageInfo.items;
        //数据解析并填入
        // 清空表格中的现有内容
        ui->signals_tw->setRowCount(0);

        // 设置表格的行数
        ui->signals_tw->setRowCount(data.size());

        // 确保表格的列数与数据匹配
        if (!data.empty()) {
            ui->signals_tw->setColumnCount(data[0].size());
        }

        // 插入数据到表格中
        for (int row = 0; row < data.size(); ++row) {
            for (int column = 0; column < data[row].size(); ++column) {
                if(column != 4){
                    QTableWidgetItem *item = new QTableWidgetItem(QString::fromStdString(data[row][column]));
                    ui->signals_tw->setItem(row, column, item);
                }

            }
        }


        // 隐藏第一列数据
        ui->signals_tw->hideColumn(0);

        //隐藏第五列数据
        ui->signals_tw->hideColumn(5);

        // 设置最后一列自动填充
        ui->signals_tw->horizontalHeader()->setStretchLastSection(true);

        // 调整其他列的宽度，使得右侧没有空白边
        ui->signals_tw->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    } catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("页面加载异常；Exception caught: ") + e.what());
        qDebug() << "页面加载异常；Exception caught: " << e.what();
    }
}

void chargeform::onVariableDataLoaded()
{
    try{
        ui->variables_tw->setRowCount(0);

        // 使用PageInfo获取分页信息
        pageInfo = getPageInfo(pageInfo.currentPage, pageInfo.itemsPerPage, pageInfo.searchText);

        // 输出分页信息
        std::cout << "Current page: " << pageInfo.currentPage << std::endl;
        std::cout << "Total pages: " << pageInfo.totalPages << std::endl;
        std::cout << "Items per page: " << pageInfo.itemsPerPage << std::endl;
        std::cout << "Total items: " << pageInfo.totalItems << std::endl;
        std::cout << "Items on current page:" << std::endl;


        std::vector<std::vector<std::string>> &data = pageInfo.items;
        //数据解析并填入
        // 清空表格中的现有内容
//        ui->variables_tw->clearContents();
//        ui->variables_tw->setRowCount(0);

        // 设置表格的行数
        ui->variables_tw->setRowCount(data.size());

        // 确保表格的列数与数据匹配
        if (!data.empty()) {
            ui->variables_tw->setColumnCount(data[0].size());
        }

        // 插入数据到表格中
        for (int row = 0; row < data.size(); ++row) {
            for (int column = 0; column < data[row].size(); ++column) {
                QTableWidgetItem *item = new QTableWidgetItem(QString::fromStdString(data[row][column]));
                ui->variables_tw->setItem(row, column, item);
            }
        }

//        // 隐藏第一列数据
//        ui->variables_tw->hideColumn(0);
//        ui->variables_tw->hideColumn(2);
//        ui->variables_tw->hideColumn(4);
//        ui->variables_tw->hideColumn(5);
//        ui->variables_tw->hideColumn(6);
//        ui->variables_tw->hideColumn(8);

        // 设置最后一列自动填充
        ui->variables_tw->horizontalHeader()->setStretchLastSection(true);

        // 调整其他列的宽度，使得右侧没有空白边
        ui->variables_tw->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    } catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("页面加载异常；Exception caught: ") + e.what());
        qDebug() << "页面加载异常；Exception caught: " << e.what();
    }

}


QList<QStringList> chargeform::datasheetOut2List(int pageType)
{
    // 创建一个列表用于存储导出的数据
    QList<QStringList> exportedData;

    QTableWidget *tempUI;
    if (pageType == SIGNALSPAGE){
        tempUI = ui->signals_tw;
    }else if(pageType == VARIABLESPAGE){
        tempUI = ui->variables_tw;
    }else {
        return exportedData;
    }
    // 获取表格行数和列数
    int rowCount = tempUI->rowCount();
    int columnCount = tempUI->columnCount();

    // 遍历表格数据并导出为列表
    for (int row = 0; row < rowCount; ++row) {
        QStringList rowData;
        for (int col = 0; col < columnCount; ++col) {
            QTableWidgetItem *item = tempUI->item(row, col);
            if (item) {
                rowData.append(item->text());
            } else {
                rowData.append(""); // 如果单元格为空，则添加空字符串
            }
        }
        exportedData.append(rowData);
    }

    // 如果是变量页面，需要对数据进行判断是否有重复项，变量类型中是否存在非预期变量类型
    if(pageType == VARIABLESPAGE){
        for (const auto &row : exportedData) {
                if (row.isEmpty()) {
                    qWarning() << "Empty row encountered."; // 可选的警告信息，可以根据实际情况处理
                    continue; // 跳过空行
                }

                const QString secondValue = row.at(1); // 获取变量名称
                const QString thirdValue = row.at(2); // 获取变量名称

                //判断是否含有不符合规定字符
                bool hasUnExceptData = false;
                bool hasUnExceptVarType = false;
                if(thirdValue == "Bool"){
                    // 检查 secondValue 是否以指定的前缀开头
                    if (!secondValue.startsWith("V_B_")) {
                        hasUnExceptData = true;
                    }
                }else if(thirdValue == "Int"){
                    if (!secondValue.startsWith("V_I_")) {
                        hasUnExceptData = true;
                    }
                }else if(thirdValue == "Double"){
                    if (!secondValue.startsWith("V_D_")) {
                        hasUnExceptData = true;
                    }
                }else if(thirdValue == "Pose"){
                    if (!secondValue.startsWith("V_P_")) {
                        hasUnExceptData = true;
                    }
                }else {
                    hasUnExceptVarType = true;
                }

                if(hasUnExceptData || hasUnExceptVarType){
                    if(hasUnExceptData){
                        QMessageBox::warning(nullptr, "Confirm Save",
                                                      QString("存在变量名称与变量类型不匹配问题，请检查变量信息！！！\n 问题数据：%1 - %2").arg(secondValue).arg(thirdValue),
                                                      QMessageBox::Yes);
                    }else {
                        QMessageBox::warning(nullptr, "Confirm Save",
                                                      QString("存在不符合要求的变量类型！！！问题数据：%1 ").arg(thirdValue),
                                                      QMessageBox::Yes);
                    }
                    exportedData.clear();
                    return exportedData;
                }
            }
    }

    // 打印导出的列表数据
    for (const auto &row : exportedData) {
        qDebug() << row;
        qDebug() << row.at(2);
    }

    return exportedData;

}

void chargeform::on_signal_save_btn_clicked()
{
    QList<QStringList> sheetList = datasheetOut2List(SIGNALSPAGE);
//    db_Con.updateDBFromData(sheetList);
    getDbCon().updateDBFromData(sheetList);

    fillSignalCombox();
    pageInfo.currentPage = 1;
    pageInfoShow();

    ui->signals_tw->hideColumn(5);
    ui->signal_save_btn->hide();

    // 设置表格为不可编辑
    ui->signals_tw->setEditTriggers(QAbstractItemView::NoEditTriggers);

    ui->signal_import_btn->hide();
    emit signal_threadCon(0);
}

void chargeform::on_signal_sort_btn_clicked()
{
    //隐藏第五列数据
//    ui->signals_tw->hideColumn(5);

    // 显示第五列数据
    ui->signals_tw->setColumnHidden(5, false);

    ui->signal_save_btn->show();

    ui->signal_import_btn->show();

    // 设置整个表格为可编辑
    ui->signals_tw->setEditTriggers(QAbstractItemView::DoubleClicked);

    emit signal_threadCon(1);

}


//实现槽函数
void chargeform::onItemSelected() {
//    numericKeyboard->setGeometry(120, 350, 250, 200); // 增加宽度以容纳点按钮
    // 处理选中行后的功能
    // 例如，获取选中行的数据并执行相应操作
    QList<QTableWidgetItem *> selectedItems = ui->signals_tw->selectedItems();
    if (!selectedItems.isEmpty()) {
        int row = selectedItems.first()->row();
        QStringList rowData;
        for (int column = 0; column < ui->signals_tw->columnCount(); ++column) {
            QTableWidgetItem *item = ui->signals_tw->item(row, column);
            if (item) {
                QString data = item->text();
                rowData << data;
            } else {
                rowData << ""; // If the cell is empty, add an empty string to the list
            }
        }
        // 现在 rowData 中包含了选中行的所有数据
        // 将第一列、第二列和第五列数据填入对应的 Label 中
        numericKeyboard->hide();
        if (rowData.size() >= 6) {
            ui->signal_name_label->setText(rowData.at(1)); // 第一列数据填入 label_1
            ui->signal_type_label->setText(rowData.at(2));
            ui->signal_addr_label->setText(rowData.at(3)); // 第二列数据填入 label_2

            // 如果是输出类型信号,显示当前的功能信息,切换功能根据需求
            if(rowData.at(2).contains("IO") || rowData.at(2).contains("TOOL") || rowData.at(2).contains("COIL")){
                // 设置IO状态显示
                if(rowData.at(4) == ioIsOn){
                    signal_status_labelShow(ioIsOn);

                }else if(rowData.at(4) == ioIsOff){
                    signal_status_labelShow(ioIsOff);
                }else {
                    signal_status_labelShow("err");
                }
                ui->signal_status_st->setCurrentIndex(0);
                if(rowData.at(6) == "OUT"){
                    ui->signalOperateSW->setCurrentIndex(0);
                }else{
                    ui->signalOperateSW->setCurrentIndex(2);
                }
            }else{
                ui->signal_status_st->setCurrentIndex(1);
                ui->signalOperateSW->setCurrentIndex(1);
                ui->modSignalStatus->setText(rowData.at(4));
                if(rowData.at(6) == "OUT"){
                    ui->signalOperateSW->setCurrentIndex(1);
//                    numericKeyboard->show();
                    showNumericKeyboardAbove();
                }else{
                    ui->signalOperateSW->setCurrentIndex(2);
                }
            }

        }
    }
}

void chargeform::onVariableItemSelected()
{
//    numericKeyboard->setGeometry(120, 330, 250, 200); // 增加宽度以容纳点按钮
    ui->getCurJoint->setStyleSheet("");
    // 处理选中行后的功能
    // 例如，获取选中行的数据并执行相应操作
    QList<QTableWidgetItem *> selectedItems = ui->variables_tw->selectedItems();
    if (!selectedItems.isEmpty()) {
        int row = selectedItems.first()->row();
        QStringList rowData;
        for (int column = 0; column < ui->variables_tw->columnCount(); ++column) {
            QTableWidgetItem *item = ui->variables_tw->item(row, column);
            if (item) {
                QString data = item->text();
                rowData << data;
            } else {
                rowData << ""; // If the cell is empty, add an empty string to the list
            }
        }
        // 现在 rowData 中包含了选中行的所有数据
        // 将第一列、第二列和第五列数据填入对应的 Label 中
        numericKeyboard->hide();
        if (rowData.size() >= 6) {
            ui->selectVarName->setText(rowData.at(1));
            ui->selectVarType->setText(rowData.at(2));
            ui->selectVarIsHod->setCurrentText(rowData.at(4));
            ui->selectVarAnnotate->setText(rowData.at(9)+ "        ");

            bool isVarTypeIn = true;
            QString varType = rowData.at(2);
            if(varType == "Bool"){
                ui->varModifyWidget->setCurrentIndex(0);
                ui->selectVarValueBool->setCurrentText(rowData.at(3));

            }else if(varType == "Int"){
                ui->varModifyWidget->setCurrentIndex(1);
                ui->selectVarValueNumber->setText(rowData.at(3));
                showNumericKeyboardAbove();

            }else if(varType == "Double"){
                ui->varModifyWidget->setCurrentIndex(1);
                ui->selectVarValueNumber->setText(rowData.at(3));
                showNumericKeyboardAbove();

            }else if(varType == "Pose"){
                ui->varModifyWidget->setCurrentIndex(2);
                ui->selectVarValuePose->setText(rowData.at(3));

            }else {
                ui->selectVarName->setText("");
                ui->selectVarType->setText("");
                ui->selectVarIsHod->setCurrentText("");
                ui->selectVarAnnotate->setText("请先选择变量！！！        ");
                ui->varModifyWidget->setCurrentIndex(4);
                ui->selectVarValueBool->setCurrentText("");
                isVarTypeIn = false;
                QMessageBox::question(nullptr, "Confirm EXPORT",
                                              QString("存在未知变量类型").arg(curProductName),
                                              QMessageBox::Yes);
            }
            if(isVarTypeIn){
                scrollIndex = 0;
                timer.start(1000);
            }else {
                timer.stop();
            }
        }
    }
}

void chargeform::on_signal_ex_btn_clicked()
{
    // 声明 QTableWidgetItem 指针
    QTableWidgetItem *item = nullptr;


    QString signalTypeText = ui->signal_type_label->text();
    if(signalTypeText.contains("MOD")){
        int modRet = 0;
        if(ui->signal_status_label->text() == "OFF"){
            modRet = setModData(1);
            if(modRet == 0){
                signal_status_labelShow(ioIsOn);
                //分配新的 QTableWidgetItem
                item = new QTableWidgetItem(ioIsOn);
            }else{
                QMessageBox::warning(nullptr, "exchange result",
                                              TR.tr("failure"),
                                              QMessageBox::Yes);
            }

        }else{
            modRet = setModData(0);
            if(modRet == 0){
                signal_status_labelShow(ioIsOff);
                //分配新的 QTableWidgetItem
                item = new QTableWidgetItem(ioIsOff);
            }else{
                QMessageBox::warning(nullptr, "exchange result",
                                              TR.tr("failure"),
                                              QMessageBox::Yes);
            }

        }
    }else{

        /** Interface call: login ***/
        robotLogin();

        if(signalTypeText.contains("TOOL")){
            std::string name = ui->signal_addr_label->text().toStdString();
            aubo_robot_namespace::IO_STATUS toolIoValue = aubo_robot_namespace::IO_STATUS_INVALID;
            if(ui->signal_status_label->text() == "OFF"){
                toolIoValue = aubo_robot_namespace::IO_STATUS_VALID;
                int ret = robotService.robotServiceSetToolDOStatus(name, toolIoValue);
                if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
                    signal_status_labelShow(ioIsOn);
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(ioIsOn);
                } else {
                    signal_status_labelShow("error");
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(TR.tr("failure"));
                    QMessageBox::warning(nullptr, "exchange result",
                                                  TR.tr("failure"),
                                                  QMessageBox::Yes);
                    addLogMessage(QString("✗ robot SetToolDOStatus failure -- ").arg(ret));
                    robotLoginState = 0;
                }
            } else {

                /*******测试*******/
                std::string name = ui->signal_addr_label->text().toStdString();
    //            aubo_robot_namespace::IO_STATUS toolIoValue = aubo_robot_namespace::IO_STATUS_VALID;

                int ret = robotService.robotServiceSetToolDOStatus(name, toolIoValue);

                if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
                    signal_status_labelShow(ioIsOff);
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(ioIsOff);
                } else {
                    signal_status_labelShow("error");
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(TR.tr("failure"));
                    QMessageBox::warning(nullptr, "exchange result",
                                                  TR.tr("failure"),
                                                  QMessageBox::Yes);
                    addLogMessage(QString("✗ robot SetToolDOStatus failure -- ").arg(ret));
                    robotLoginState = 0;
                }
            }

        }else {
            aubo_robot_namespace::RobotIoType ioType = aubo_robot_namespace::RobotBoardUserDO;
            QString ioAddr = ui->signal_addr_label->text();
            if(ui->signal_status_label->text() == "OFF"){

                int ret = robotService.robotServiceSetBoardIOStatus(ioType, ioAddr.toStdString(), 1);
                if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
                    signal_status_labelShow(ioIsOn);
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(ioIsOff);
                } else {
                    signal_status_labelShow("error");
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(TR.tr("failure"));
                    QMessageBox::warning(nullptr, "exchange result",
                                                  TR.tr("failure"),
                                                  QMessageBox::Yes);
                    addLogMessage(QString("✗ robot SetBoardIOStatus failure -- ").arg(ret));
                    robotLoginState = 0;
                }
            } else {

                int ret = robotService.robotServiceSetBoardIOStatus(ioType, ioAddr.toStdString(), 0);
                if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
                    signal_status_labelShow(ioIsOff);
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(ioIsOff);
                } else {
                    signal_status_labelShow("error");
                    // 分配新的 QTableWidgetItem
                    item = new QTableWidgetItem(TR.tr("failure"));
                    QMessageBox::warning(nullptr, "exchange result",
                                                  TR.tr("failure"),
                                                  QMessageBox::Yes);
                    addLogMessage(QString("✗ robot SetBoardIOStatus failure -- ").arg(ret));
                    robotLoginState = 0;
                }
            }
        }

    }

    // 获取当前选中的行
    int selectedRow = ui->signals_tw->currentRow();
    ui->signals_tw->setItem(selectedRow, 4, item); // 第五列索引为4
}

void chargeform::signal_status_labelShow(QString ioStatus)
{
    if(ioStatus == ioIsOn){
        ui->signal_status_label->setText(ioIsOn);
        ui->signal_status_label->setStyleSheet("background-color: yellow; border: 2px solid black;");

    }else if(ioStatus == ioIsOff){
        ui->signal_status_label->setText(ioIsOff);
        ui->signal_status_label->setStyleSheet("background-color: gray; border: 2px solid black;");
    }else {
        ui->signal_status_label->setText("ERROR");
        ui->signal_status_label->setStyleSheet("background-color: red; border: 2px solid black;");
    }
}

void chargeform::on_signal_sendMod_btn_clicked()
{
    setModData();
}


void DataRetrievalThread::exchangeThreadStatus(bool isthreadoff)
{
    if(isthreadoff){
        m_stop = true;// 设置 m_stop 为 true，停止线程的执行
    }else {
        m_stop = false;// 设置 m_stop 为 true，开始线程的执行
    }
}

void DataRetrievalThread::exchangeThreadStatus_lock(bool islockoff)
{
    if(islockoff){
        m_lock = true;// 设置 m_stop 为 true，停止线程的执行
    }else {
        m_lock = false;// 设置 m_stop 为 true，开始线程的执行
    }

}

void DataRetrievalThread::set_lock_mod_addr(int lockmodaddr)
{
    m_lockmodaddr = lockmodaddr;
}

void DataRetrievalThread::set_thread_start()
{
    m_start = true;
}

void DataRetrievalThread::signalGet(std::vector<std::vector<std::string>> signalsGet)
{
    try{
        qDebug() << "获取信号对象参数------------------------------------<<<<";

//        if (hasGarbage(signalsGet)) {
        if (false) {
            std::cout << "容器中存在乱码。\n";
        } else if(signalsGet.size() < 100){
            m_stop = 1;

            if(!isSignalBlock){
                std::vector<std::vector<std::string>>().swap(threadsignalsGet);
                threadsignalsGet = signalsGet;
                qDebug() << "信号传递成功------------------------------------<<<<";
            }else {
                qDebug() << "信号传递失败------------------------------------<<<<";
            }

            m_stop = 0;
        }else {
            qDebug() << "信号对象参数长度超过100------------------------------------<<<<";
        }


    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("Exception caught: ") + e.what());
        qDebug() << "Exception caught: " << e.what();
    }

}


// 函数：检查二维数组是否包含乱码
bool DataRetrievalThread::hasGarbage(const std::vector<std::vector<std::string>>& signalsGet) {
    for (const auto& innerVector : signalsGet) {
        for (const auto& str : innerVector) {
            if (containsGarbage(str)) {
                return true; // 发现乱码
            }
        }
    }
    return false; // 未发现乱码
}

// 函数：检查字符串是否包含乱码
bool DataRetrievalThread::containsGarbage(const std::string& str) {
    for (char c : str) {
        // 检查是否是非法字符（不在 UTF-8 编码范围内的字符）
        if ((unsigned char)c < 0x20 && c != '\t' && c != '\n' && c != '\r') {
            return true; // 包含乱码
        }
    }
    return false; // 不包含乱码
}

/**
 * @brief DataRetrievalThread::signalPageInfoShow
 * 显示Signal页面上的所有东西（整体重置）
 */
void chargeform::pageInfoShow()
{
    //键盘隐藏
    numericKeyboard->hide();
    // 设置页面信息
    pageInfoSet(this->pageInfo.currentPage);
    if(ui->pageWidgets->currentIndex() == SIGNALSPAGE){
        emit signal_threadCon(0);
        ui->signalOperateSW->setCurrentIndex(2);
        onDataLoaded();
    }else if(ui->pageWidgets->currentIndex() == VARIABLESPAGE) {
        emit signal_threadCon(1);
        //初始化变量页面相关信息
        ui->selectVarName->setText("NULL");
        ui->selectVarType->setText("NULL");
        ui->selectVarIsHod->setCurrentText("NULL");
        ui->selectVarAnnotate->setText("请先选择变量！！！        ");
        ui->varModifyWidget->setCurrentIndex(3);
        ui->selectVarValueBool->setCurrentText("NULL");
        numericKeyboard->hide();
        onVariableDataLoaded();
        ui->curProBox->setCurrentText(curProductName);
    }else if(ui->pageWidgets->currentIndex() == HELPPAGE){
        emit signal_threadCon(1);
        fileViewPathEx();
    }else{
        emit signal_threadCon(1);
    }
}




void chargeform::on_signal_sendMod1_btn_clicked()
{
    setModData(1);
}

void chargeform::on_signal_sendMod0_btn_clicked()
{
    setModData(0);
}

void chargeform::on_signal_data_left_clicked()
{
    try{
        pageInfo.currentPage --;
        pageInfoShow();
    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("Exception caught: ") + e.what());
        qDebug() << "Exception caught: " << e.what();
    }

}

void chargeform::on_signal_data_right_clicked()
{
    try{
        pageInfo.currentPage ++;
        pageInfoShow();
    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("Exception caught: ") + e.what());
        qDebug() << "Exception caught: " << e.what();
    }

}

void chargeform::on_signal_search_btn_clicked()
{
    emit signal_threadCon(1);
    pageInfo.currentPage = 1;
    pageInfoShow();
    emit signal_threadCon(0);
}

void chargeform::updateSignalsTable(std::vector<std::vector<std::string> > updateSignalItems)
{
    qDebug() << "更新主页信号列表Table";

    std::vector<std::vector<std::string>> data = updateSignalItems;

    std::cout << "接收到信号并写入表格中，共计：" << data.size() << std::endl;
    getLogger().log("接收到信号并写入表格中，共计：" + QString::number(data.size()));
    // 插入数据到表格中
    for (int row = 0; row < data.size(); ++row) {
        for (int column = 0; column < data[row].size(); ++column) {
            if(column == 4){
                QTableWidgetItem *item = new QTableWidgetItem(QString::fromStdString(data[row][column]));
                ui->signals_tw->setItem(row, column, item);
            }

        }
    }
}

void chargeform::on_help_page_btn_clicked()
{
    ui->pageWidgets->setCurrentIndex(2);
    pageInfoShow();
}

void chargeform::on_signal_page_btn_clicked()
{
    ui->pageWidgets->setCurrentIndex(0);
    pageInfo.currentPage = 1;
    // 开启页面数据刷新
    pageInfoShow();
}

void chargeform::on_var_page_btn_clicked()
{
    ui->pageWidgets->setCurrentIndex(1);
    pageInfo.currentPage = 1;
    pageInfoShow();

}

void chargeform::on_var_ex2robot_btn_clicked()
{
    // 显示确认对话框
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(nullptr, "Confirm EXPORT",
                                  QString("是否确认导入～'%1'至机器人变量中?\nTips:请在导入完成后对机器人端重启！！！").arg(curProductName),
                                  QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {

        // 获取当前产品所有的变量信息
//        QList<QStringList> sheetList = db_Con.getAllProductDatabase(curProductName);
        QList<QStringList> sheetList = getDbCon().getAllProductDatabase(curProductName);

        if(sheetList.size()>0){
//            int res = db_Con.arrInsert2SysDB(sheetList);
            int res = getDbCon().arrInsert2SysDB(sheetList);
            if(res == 1){
                QMessageBox::question(nullptr, "success",
                                                  QString(TR.tr("varExportSucc")),
                                                  QMessageBox::Yes);
            }else{
                QMessageBox::question(nullptr, "failure",
                                                  QString(TR.tr("varExportDefault1")),
                                                  QMessageBox::Yes);
            }
        }else{
            QMessageBox::question(nullptr, "failure",
                                              QString(TR.tr("varExportDefault2")),
                                              QMessageBox::Yes);
        }
    }
}

void chargeform::on_var_save_btn_clicked()
{
    QList<QStringList> sheetList = datasheetOut2List(VARIABLESPAGE);
    if(sheetList.size() > 0){
//        int ret = db_Con.updateProcedureDBData(sheetList);
        int ret = getDbCon().updateProcedureDBData(sheetList);
        if(ret == 1){
            fillProductCombox();
            pageInfoShow();
            QMessageBox::warning(nullptr,"Warning",TR.tr("filesaveWarning"));
        }else {
            QMessageBox::warning(nullptr,"Warning",TR.tr("filesaveDefaultWarning"));
        }

    }
}

void chargeform::on_var_manage_btn_clicked()
{
    // 判断是显示还是隐藏对应的信息
    this->isVarPageModifyOn = this->isVarPageModifyOn ? false:true;
    ex_page2modify_status();
}

void chargeform::ex_page2modify_status(){
    if(this->isVarPageModifyOn){
        ui->var_delCurPro_btn->show();
        ui->var_import_btn->show();
        ui->var_manage_btn->setText(TR.tr("exit"));
        ui->var_manage_btn->setStyleSheet("background-color: #fff1cf; border: 2px solid black;");

        ui->var_export_btn->show();
        ui->var_delSelect_btn->show();
        ui->var_ex2cur_btn->hide();
//        ui->curProBox->setEditable(true);
        ui->varSaveProByInputBtn->hide();
        ui->var_createByCur_btn->show();

        ui->variables_tw->setColumnHidden(2,false);
        ui->variables_tw->setColumnHidden(4,false);
        ui->variables_tw->setColumnHidden(5,false);
        ui->variables_tw->setColumnHidden(6,false);
        ui->variables_tw->setColumnHidden(8,false);
        ui->var_save_btn->show();

    }else {
        ui->var_delCurPro_btn->hide();
        ui->var_import_btn->hide();
        ui->var_savePro_btn->hide();
        ui->var_manage_btn->setText(TR.tr("manage"));
        ui->var_manage_btn->setStyleSheet("background-color: #a0d8ef; border: 2px solid black;");

        ui->var_export_btn->hide();
        ui->var_delSelect_btn->hide();

        ui->var_ex2cur_btn->hide();
//        ui->curProBox->setEditable(false);
        ui->varSaveProByInputBtn->hide();
        ui->var_createByCur_btn->hide();

        //保存按钮隐藏
        ui->var_save_btn->hide();


        // 隐藏第一列数据
        ui->variables_tw->hideColumn(0);
        ui->variables_tw->hideColumn(2);
        ui->variables_tw->hideColumn(4);
        ui->variables_tw->hideColumn(5);
        ui->variables_tw->hideColumn(6);
        ui->variables_tw->hideColumn(8);
    }
}

void chargeform::on_var_import_btn_clicked()
{
//    ui->var_savePro_btn->show();
    QList<QStringList> showArr = fileLoad2QList();
    if(showArr.size() > 0){
        Add2Vardatasheet(showArr);
        on_var_savePro_btn_clicked();
    }
}

void chargeform::on_var_savePro_btn_clicked()
{

    QList<QStringList> sheetList = datasheetOut2List(VARIABLESPAGE);

    if(sheetList.size()>0){
        //获取页面中的所有产品名称并去除重复
        std::unique_ptr<utils> myutil(new utils());
        // 调用函数
        QStringList newuniqueItems = myutil->getUniqueColumnData(sheetList, 8);

        QStringList uniqueItems;
//        db_Con.getProductItems(uniqueItems);
        getDbCon().getProductItems(uniqueItems);
        // 去重
        uniqueItems.removeDuplicates();

        if(myutil->haveCommonItems(newuniqueItems, uniqueItems)){
            qDebug()<< "与数据库中数据冲突，无法进行产品存储";
            QMessageBox::warning(nullptr,"Warning",QString(TR.tr("varSaveProDefault1")));
            return;
        }

//        int ret = db_Con.arrInsert2ProcustDB(sheetList);
        int ret = getDbCon().arrInsert2ProcustDB(sheetList);
        if(ret == 1){
            on_var_manage_btn_clicked();

            fillProductCombox();
            // 清除相关信息
            ui->curProBox->setCurrentText(newuniqueItems[0]);
            curProductName = ui->curProBox->currentText();
            QMessageBox::information(nullptr, "Infomation", QString(TR.tr("varSaveProSucc") + "%1").arg(curProductName),
                                            QMessageBox::Yes);
            if (curProductName.isEmpty()) {
                QMessageBox::information(this, "信息", QString(TR.tr("varSaveProDefault2")), QMessageBox::Ok);
                return;
            }
            ui->var_combox->setCurrentText("无");
            ui->variables_tw->setRowCount(0);
            pageInfo.currentPage = 1;
            pageInfoShow();

            // 切换ini文件配置项，设置产品信息
            configCon.updateConfig(5,curProductName);
        }else {
            QMessageBox::warning(nullptr,"Warning","产品导入失败!!!");
        }

    }
}

/**
 * @brief chargeform::on_var_ex2cur_btn_clicked
 * 切换到当前产品
 */
void chargeform::on_var_ex2cur_btn_clicked()
{
    if (ignoreIndexChanged) return;
    QString newProName = ui->curProBox->currentText();
    if(newProName == ""){
        QMessageBox::information(nullptr, "Question", QString(TR.tr("varSaveProDefault2")),
                                        QMessageBox::Yes);
        return;
    }else if (newProName == curProductName) {
        return;
    }
//    // 显示确认对话框
//    QMessageBox::StandardButton reply;
//    reply = QMessageBox::question(nullptr, "Confirm Exchange",
//                                  QString("您正在切换产品至%1，请确认，当前页面数据是否保存！！！").arg(newProName),
//                                  QMessageBox::Yes | QMessageBox::No);
//    if (reply == QMessageBox::Yes) {
    if(true){
        curProductName = newProName;

        ui->var_combox->setCurrentText("无");

        pageInfo.currentPage = 1;
        pageInfoShow();
        fillProductCombox();

        // 切换ini文件配置项，设置产品信息
        configCon.updateConfig(5,curProductName);
    }else {
        ignoreIndexChanged = true;
        ui->curProBox->setCurrentText(curProductName);
        ignoreIndexChanged = false;

    }
}

void chargeform::on_var_signalsearch_btn_clicked()
{
    pageInfo.currentPage = 1;
    pageInfoShow();
}

void chargeform::on_varPagePro_clicked()
{
    try{
        pageInfo.currentPage --;
        pageInfoShow();
    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("Exception caught: ") + e.what());
        qDebug() << "Exception caught: " << e.what();
    }
}

void chargeform::on_varPageNext_clicked()
{
    try{
        pageInfo.currentPage ++;
        pageInfoShow();
    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
        QMessageBox::critical(nullptr, "Error", QString("Exception caught: ") + e.what());
        qDebug() << "Exception caught: " << e.what();
    }
}

void chargeform::on_var_delCurPro_btn_clicked()
{
    // 显示确认对话框
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(nullptr, "Confirm Deletion",
                                  QString("是否确认删除该产品的变量信息～'%1'?").arg(curProductName),
                                  QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::No) {
        qDebug() << "Deletion canceled.";
        return;
    }else {
        on_var_manage_btn_clicked();
        // 删除这个产品curProductName
//        db_Con.deleteDataByProductName(curProductName);
        getDbCon().deleteDataByProductName(curProductName);

        fillProductCombox();
        // 清除相关信息
        ui->curProBox->setCurrentIndex(0);
        curProductName = ui->curProBox->currentText();
        if (curProductName.isEmpty()) {
            QMessageBox::information(this, "信息", QString(TR.tr("varSaveProDefault2")), QMessageBox::Ok);
            return;
        }
        ui->var_combox->setCurrentText("无");
        ui->variables_tw->setRowCount(0);
        pageInfo.currentPage = 1;
        pageInfoShow();
        // 切换ini文件配置项，设置产品信息
        configCon.updateConfig(5,curProductName);
    }
}

void chargeform::on_setSelectVariableBtn_clicked()
{
    // 获取选中的行号
    QList<QTableWidgetItem *> selectedItems = ui->variables_tw->selectedItems();
    if (selectedItems.isEmpty()) {
        qDebug() << "No row selected.";
        QMessageBox::warning(nullptr,"warning","请先选择对应行");
        return;
    }

    // 假设表格的每一行有3列，你可以根据实际情况调整
    int row = selectedItems.first()->row(); // 假设选中的是第一个选中单元格，从中获取行号

    // 获取该行的数据
    QTableWidgetItem *item1 = ui->variables_tw->item(row, 1);
    QTableWidgetItem *item2 = ui->variables_tw->item(row, 2);
    QTableWidgetItem *item3 = ui->variables_tw->item(row, 3);
    QTableWidgetItem *item4 = ui->variables_tw->item(row, 4);

    if (!item1 || !item2 || !item3 || !item4) {
        qDebug() << "Invalid row or columns.";
        return;
    }

    item1->setText(ui->selectVarName->text());
    item2->setText(ui->selectVarType->text());
    if(ui->selectVarType->text() == "Bool"){
        item3->setText(ui->selectVarValueBool->currentText());
    }else if(ui->selectVarType->text() == "Pose"){
//        item3->setText(ui->selectVarValueNumber->text());
    }else {
        item3->setText(ui->selectVarValueNumber->text());
    }

    item4->setText(ui->selectVarIsHod->currentText());

    // 刷新表格显示，如果需要的话
    ui->variables_tw->viewport()->update(); // 可以刷新视图以显示更新后的数据

    //获取对应改行的数据，并直接进行存储
    // 确保行号在有效范围内
    // 获取该行的所有数据
    QStringList rowData;
    for (int col = 0; col < ui->variables_tw->columnCount(); ++col) {
        QTableWidgetItem *item = ui->variables_tw->item(row, col);
        if (item) {
            rowData << item->text(); // 收集单元格的文本
        } else {
            rowData << ""; // 如果没有项，添加空字符串
        }
    }

    // 输出行数据
    qDebug() << "Row" << row << "data:" << rowData;

    QList<QStringList> list;
    list.append(rowData);
    if(list.size() > 0){
//        int ret = db_Con.updateProcedureDBData(list);
        int ret = getDbCon().updateProcedureDBData(list);
        if(ret != 1){
            QMessageBox::warning(nullptr,"Warning","数据存储失败！");
        }

    }
}

void chargeform::on_getCurJoint_clicked()
{
    // 显示确认对话框
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(nullptr,"Reconfirm","是否记录当前点位？",QMessageBox::Yes|QMessageBox::No);
    if(reply == QMessageBox::Yes){
        // 获取选中行信息
        // 获取选中的行号
        QList<QTableWidgetItem *> selectedItems = ui->variables_tw->selectedItems();
        if (selectedItems.isEmpty()) {
            qDebug() << "No row selected.";
            QMessageBox::warning(nullptr,"warning","未选中行信息！");
            return;
        }
        // 假设表格的每一行有3列，你可以根据实际情况调整
        int row = selectedItems.first()->row(); // 假设选中的是第一个选中单元格，从中获取行号
        QTableWidgetItem *item3 = ui->variables_tw->item(row, 3);

        if (!item3) {
            qDebug() << "Invalid row or columns.";
            QMessageBox::warning(nullptr,"warning","单元格信息越界！");
            return;
        }
        /** Interface call: login ***/
        robotLogin();
        aubo_robot_namespace::wayPoint_S currentWaypoint;
        int ret = robotService.robotServiceGetCurrentWaypointInfo(currentWaypoint);

        if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cout << "--------------------正解--------------------" << std::endl;
            std::cout << "正解得到的路点位置："
            << " x = " << currentWaypoint.cartPos.position.x
            << " y = " << currentWaypoint.cartPos.position.y
            << " z = " << currentWaypoint.cartPos.position.z
            << std::endl;
            std::cout << "正解得到的目标路点的姿态（四元数）："
            << " w = " << currentWaypoint.orientation.w
            << " x = " << currentWaypoint.orientation.x
            << " y = " << currentWaypoint.orientation.y
            << " z = " << currentWaypoint.orientation.z
            << std::endl;
            //四元数转欧拉角
            aubo_robot_namespace::Rpy rpy;
            robotService.quaternionToRPY(currentWaypoint.orientation, rpy);
            std::cout << "正解得到的目标路点的姿态（欧拉角）:"
            << " RX = " << rpy.rx*180/M_PI
            << " RY = " << rpy.ry*180/M_PI
            << " RZ = " << rpy.rz*180/M_PI
            << std::endl;
            qDebug() << "currentWayPointInfo:";

            char separator = ';';
            QString poseStr = QString::number(currentWaypoint.cartPos.position.x) + separator +
                    QString::number(currentWaypoint.cartPos.position.y) + separator +
                    QString::number(currentWaypoint.cartPos.position.z) + separator +
                    QString::number(currentWaypoint.orientation.w) + separator +
                    QString::number(currentWaypoint.orientation.x) + separator +
                    QString::number(currentWaypoint.orientation.y) + separator +
                    QString::number(currentWaypoint.orientation.z) + separator +
                    QString::number(currentWaypoint.jointpos[0]) + separator +
                    QString::number(currentWaypoint.jointpos[1]) + separator +
                    QString::number(currentWaypoint.jointpos[2]) + separator +
                    QString::number(currentWaypoint.jointpos[3]) + separator +
                    QString::number(currentWaypoint.jointpos[4]) + separator +
                    QString::number(currentWaypoint.jointpos[5]);

            // 对点位数据对应单元格进行处理
            item3->setText(poseStr);
            ui->selectVarValuePose->setText(poseStr);
            ui->getCurJoint->setStyleSheet("background-color: #98d98e;");


            // 刷新表格显示，如果需要的话
            ui->variables_tw->viewport()->update(); // 可以刷新视图以显示更新后的数据

            //获取对应改行的数据，并直接进行存储
            // 确保行号在有效范围内
            // 获取该行的所有数据
            QStringList rowData;
            for (int col = 0; col < ui->variables_tw->columnCount(); ++col) {
                QTableWidgetItem *item = ui->variables_tw->item(row, col);
                if (item) {
                    rowData << item->text(); // 收集单元格的文本
                } else {
                    rowData << ""; // 如果没有项，添加空字符串
                }
            }

            // 输出行数据
            qDebug() << "Row" << row << "data:" << rowData;

            QList<QStringList> list;
            list.append(rowData);
            if(list.size() > 0){
//                int ret = db_Con.updateProcedureDBData(list);
                int ret = getDbCon().updateProcedureDBData(list);
                if(ret != 1){
                    QMessageBox::warning(nullptr,"Warning","数据存储失败！");
                }else {
                     QMessageBox::information(nullptr,"Reconfirm","点位记录完成");
                }

            }

        }else{
            addLogMessage(QString("✗ robot getCurwaypoint failure -- ").arg(ret));
            robotLoginState = 0;
        }
    }else {
        QMessageBox::information(nullptr,"Reconfirm","已取消");
    }
}

void chargeform::on_jointMoveBtn_pressed()
{
    QString currentPoseData = ui->selectVarValuePose->text().trimmed(); // 获取并去除首尾空格

    if (currentPoseData.isEmpty()) {
        // 如果输入为空，可以提醒用户输入有效数据
        QMessageBox::warning(this, "Warning", "Please enter joint values.");
        return;
    }

    // 按逗号分割字符串
    char separator = ';';
    QStringList dataList = currentPoseData.split(separator);

    if (dataList.size() < 6) {
        // 如果数据少于六个，可以提醒用户输入有效数据
        QMessageBox::warning(this, "Warning", "Please enter at least six joint values.");
        return;
    }

    // 计算起始索引，确保不超出范围
    int startIndex = qMax(0, dataList.size() - 6);

    // 初始化存储 double 类型数据的数组
    double joint_qua[6];

    // 将字符串转换为 double 类型并存入数组
    for (int i = 0; i < 6; ++i) {
        if (startIndex + i < dataList.size()) {
            joint_qua[i] = dataList[startIndex + i].trimmed().toDouble();
        } else {
            // 处理索引超出范围的情况，如果不需要则可以忽略
            joint_qua[i] = 0.0; // 或者其他默认值
        }
    }

    robotLogin();

    int ret = robotService.robotServiceJointMove(joint_qua, false);

    if (ret == aubo_robot_namespace::InterfaceCallSuccCode) {
//        QMessageBox::information(this, "Success", "Joint movement successful.");
        // 关节移动成功，可以在这里做进一步处理，例如更新界面状态等
    } else {
        QString jointQuaStr = "";
        for (int i = 0; i < 6; ++i) {
            jointQuaStr += QString("Joint %1: %2\n").arg(i+1).arg(joint_qua[i]);
        }
        jointQuaStr += QString("报错参数：%1").arg(ret);

        // 显示数组内容
        QMessageBox::information(this, "Failed to move joints!\nJoint Values", jointQuaStr);
        addLogMessage(QString("✗ robot moveJoint failure -- ").arg(ret));
        robotLoginState = 0;
    }
}


void chargeform::on_jointMoveBtn_released()
{
    robotLogin();
    int ret = robotService.robotMoveFastStop();
    if (ret == aubo_robot_namespace::InterfaceCallSuccCode) {
//        QMessageBox::information(this, "Success", "Joint movement successful.");
        // 关节移动成功，可以在这里做进一步处理，例如更新界面状态等
    } else {
        QMessageBox::critical(this, "Error", "Failed to Stop jointMove.");
        // 处理关节移动失败的情况
        addLogMessage(QString("✗ robot stop failure -- ").arg(ret));
        robotLoginState = 0;
    }
}

void chargeform::on_lineMoveBtn_pressed()
{
    QString currentPoseData = ui->selectVarValuePose->text().trimmed(); // 获取并去除首尾空格

    if (currentPoseData.isEmpty()) {
        // 如果输入为空，可以提醒用户输入有效数据
        QMessageBox::warning(this, "Warning", "Please enter joint values.");
        return;
    }

    // 按逗号分割字符串
    char separator = ';';
    QStringList dataList = currentPoseData.split(separator);

    if (dataList.size() < 6) {
        // 如果数据少于六个，可以提醒用户输入有效数据
        QMessageBox::warning(this, "Warning", "Please enter at least six joint values.");
        return;
    }

    // 计算起始索引，确保不超出范围
    int startIndex = qMax(0, dataList.size() - 6);

    // 初始化存储 double 类型数据的数组
    double joint_qua[6];

    // 将字符串转换为 double 类型并存入数组
    for (int i = 0; i < 6; ++i) {
        if (startIndex + i < dataList.size()) {
            joint_qua[i] = dataList[startIndex + i].trimmed().toDouble();
        } else {
            // 处理索引超出范围的情况，如果不需要则可以忽略
            joint_qua[i] = 0.0; // 或者其他默认值
        }
    }
    robotLogin();
    int ret = robotService.robotServiceLineMove(joint_qua, false);

    if (ret == aubo_robot_namespace::InterfaceCallSuccCode) {
//        QMessageBox::information(this, "Success", "Joint movement successful.");
        // 关节移动成功，可以在这里做进一步处理，例如更新界面状态等
    } else {
        QMessageBox::critical(nullptr, "Error", "Failed to move joints.");
        // 处理关节移动失败的情况
        addLogMessage(QString("✗ robot moveline failure -- ").arg(ret));
        robotLoginState = 0;
    }
}

void chargeform::on_lineMoveBtn_released()
{
    robotLogin();
    int ret = robotService.robotMoveFastStop();
    if (ret == aubo_robot_namespace::InterfaceCallSuccCode) {
//        QMessageBox::information(this, "Success", "Joint movement successful.");
        // 关节移动成功，可以在这里做进一步处理，例如更新界面状态等
    } else {
        QMessageBox::critical(this, "Error", "Failed to Stop lineMove.");
        // 处理关节移动失败的情况
        addLogMessage(QString("✗ robot stop failure -- ").arg(ret));
        robotLoginState = 0;
    }
}

void chargeform::on_varSaveProByInputBtn_clicked()
{
    QString newProName = ui->curProBox->currentText();
    if(newProName == ""){
        QMessageBox::warning(nullptr,"WARNING","输入的变量名称不能为空！");
        return;
    }
    // 获取当前产品所有的变量信息
//    QList<QStringList> sheetList = db_Con.getAllProductDatabase(curProductName);
    QList<QStringList> sheetList = getDbCon().getAllProductDatabase(curProductName);

    if(sheetList.size()>0){
        // 遍历每个 QStringList
        for (QStringList &list : sheetList) {
            // 假设要替换第一个字段
            if (list.size() > 0) {
                // 替换第一个字段为新的值，例如替换为 "new_value"
                list.replace(8, newProName);
            }
        }
//        db_Con.arrInsert2ProcustDB(sheetList);
        getDbCon().arrInsert2ProcustDB(sheetList);


        curProductName = newProName;
        ui->var_combox->setCurrentText("无");
        pageInfo.currentPage = 1;
        pageInfoShow();
        fillProductCombox();

        // 切换ini文件配置项，设置产品信息
        configCon.updateConfig(5,curProductName);
    }

}

void chargeform::on_var_delSelect_btn_clicked()
{
    // 例如，获取选中行的数据并执行相应操作
    QList<QTableWidgetItem *> selectedItems = ui->variables_tw->selectedItems();
    if (!selectedItems.isEmpty()) {
        int row = selectedItems.first()->row();
        QStringList rowData;
        for (int column = 0; column < ui->variables_tw->columnCount(); ++column) {
            QTableWidgetItem *item = ui->variables_tw->item(row, column);
            if (item) {
                QString data = item->text();
                rowData << data;
            } else {
                rowData << ""; // If the cell is empty, add an empty string to the list
            }
        }
        //
        // 显示确认对话框
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(nullptr, "Confirm Deletion",
                                      QString("是否确认删除该变量信息～'%1'?").arg(rowData.at(1)),
                                      QMessageBox::Yes | QMessageBox::No);
        if (reply == QMessageBox::No) {
            qDebug() << "Deletion canceled.";
            return;
        }else {
//            on_var_manage_btn_clicked();
            // 删除这个产品curProductName
//            if(db_Con.deleteDataByID(rowData.at(0).toInt()) == 0){
            if(getDbCon().deleteDataByID(rowData.at(0).toInt()) == 0){
                QMessageBox::information(nullptr, "Confirm Deletion",
                                                      QString("数据删除失败'%1'?").arg(rowData.at(1)));
                return;

            }
            pageInfoShow();
        }

    }else {
        QMessageBox::warning(nullptr,"WARNING","当前无选中数据");
    }
}


void chargeform::on_var_export_btn_clicked()
{
    QString exportProName = ui->curProBox->currentText();
    if (exportProName.isEmpty()) {
        QMessageBox::warning(nullptr, "WARNING", "请选择正确的导出产品名称！");
        return;
    }

//    QList<QStringList> data = db_Con.getAllProductDatabase(exportProName);
    QList<QStringList> data = getDbCon().getAllProductDatabase(exportProName);

    QString filename = fileRootPath + "output.csv";
    QFile file(filename);

    if (file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QTextStream stream(&file);

        // 添加标题行
        QStringList headers = {"id", "变量名称", "变量类型", "变量数据", "是否保持", "排序", "标志", "别名", "产品名称", "注释"};  // 根据实际列数和名称修改
        for (int i = 0; i < headers.size(); ++i) {
            stream << headers.at(i);
            if (i != headers.size() - 1)
                stream << ",";
        }
        stream << "\n";

        // 写入数据到CSV文件
        for (const QStringList &row : data) {
            for (int i = 0; i < row.size(); ++i) {
                stream << row.at(i);
                if (i != row.size() - 1)
                    stream << ",";  // 添加CSV的分隔符
            }
            stream << "\n";  // 换行符
        }

        file.close();
        qDebug() << "CSV file saved:" << filename;
        QMessageBox::information(nullptr, "Info", QString("CSV文件已导出，存储位置：%1").arg(filename));
    } else {
        qDebug() << "Failed to open file:" << filename;
        QMessageBox::information(nullptr, "warning", QString("文件导出失败，目标文件名称：%1").arg(filename));
    }
}


void chargeform::on_help_copySelect_btn_clicked()
{
    // 获取当前的 QPlainTextEdit 对象，假设为 textEdit
    QPlainTextEdit *textEdit = ui->fileViewTextEdit; // 这里假设你的 QPlainTextEdit 对象叫做 fileViewTextEdit

    // 获取当前的文本光标
    QTextCursor cursor = textEdit->textCursor();

    // 检查是否有文本被选中
    if (!cursor.hasSelection()) {
        qDebug() << "No text selected.";
        return;
    }

    // 获取选中的文本
    QString selectedText = cursor.selectedText();

    // 获取剪贴板对象
    QClipboard *clipboard = QApplication::clipboard();

    // 将选中的文本复制到剪贴板
    clipboard->setText(selectedText);

    qDebug() << "Selected text copied to clipboard:" << selectedText;
}

void chargeform::on_unlockBtn_clicked()
{
    alphanumericKeyboard->hide();
    systemPassCheck(true);
}

void chargeform::on_var_createByCur_btn_clicked()
{
    qDebug() << "显示修改名称键盘";

   CustomInputDialog dialog(this->curProductName, this);

   if (dialog.exec() == QDialog::Accepted) {
       QString text = dialog.text();
       if (!text.isEmpty()) {
           ui->curProBox->setCurrentText(text);
           QMessageBox::information(this, "已创建新的产品", "You entered:" + text);
           //调用函数进行产品创建
           on_varSaveProByInputBtn_clicked();
       }
   }else {
       qDebug() << "并未对名称进行修改";
   }
}

void chargeform::on_setting_page_btn_clicked()
{
    ui->pageWidgets->setCurrentIndex(3);
    pageInfoShow();
}

void chargeform::on_setting_logout_btn_clicked()
{
    // 跳转到注册页面,如果无法输入对应的密码,无法进行返回跳转,二次确认,是否清除原有密码
    // 显示确认对话框
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(nullptr, "Register",
                                  QString(TR.tr("logoutWarning")),
                                  QMessageBox::Yes | QMessageBox::No);
    if (reply == QMessageBox::Yes) {

        ui->mainpageWidgets->setCurrentIndex(1);
        emit signal_threadCon(1);
        //清除当前所存储的插件密码
        configCon.updatePassKeys();
        this->on_lockWRe_btn_clicked();
        ui->passwordInput->setText("");
        emit signal_threadCon_lock(true);
    }
}


void chargeform::on_lockWRe_btn_clicked()
{
    std::unique_ptr<utils> tempUtil(new utils());
    ui->curLockWords->setText(tempUtil->generateRandomString(6));
}

void chargeform::on_setting_languageCombox_currentIndexChanged(int index)
{
    ui->setting_languageCombox->setCurrentIndex(index);
    std::cout << "当前的语言:" << index << std::endl;
    // 设置语言
    LanguageManager::instance().setLanguage(index);  // 中文

//    auto& TR = LanguageManager::instance();

    int buttonW = 100;
    int buttonH = 30;
    // 设置按钮的尺寸
    ui->signal_page_btn->setFixedSize(buttonW, buttonH);
    ui->var_page_btn->setFixedSize(buttonW, buttonH);
    ui->help_page_btn->setFixedSize(buttonW, buttonH);
    ui->setting_page_btn->setFixedSize(buttonW, buttonH);

    ui->setSelectVariableBtn->setFixedSize(buttonW, buttonH);

    ui->signal_sendMod_btn->setFixedSize(buttonW, buttonH);

    ui->lockWRe_btn->setFixedSize(buttonW, buttonH);

    ui->unlockBtn->setFixedSize(buttonW, buttonH);
    ui->lockKeyboardOpen_btn->setFixedSize(buttonW, buttonH);


    // 设置几个文字样式
    ui->register_show_label->setStyleSheet("font-size: 24px; color: red;");
    // 一行代码设置字体大小和颜色
    ui->curLockWords->setStyleSheet("font-size: 36px; color: darkblue;");



       // ========== 顶部导航按钮 ==========
       ui->signal_page_btn->setText(TR.tr("signals"));
       ui->var_page_btn->setText(TR.tr("productChange"));
       ui->help_page_btn->setText(TR.tr("help"));
       ui->setting_page_btn->setText(TR.tr("setting"));

       // ========== 信号页面 ==========
       // 操作按钮
       ui->signal_import_btn->setText(TR.tr("import"));
       ui->signal_sort_btn->setText(TR.tr("manage"));
       ui->signal_save_btn->setText(TR.tr("save"));
       ui->signal_search_btn->setText(TR.tr("search"));
       ui->signal_ex_btn->setText(TR.tr("switch"));
       ui->signal_sendMod_btn->setText(TR.tr("send"));

       // 信息标签
       ui->signal_name_text_label->setText(TR.tr("signalName"));
       ui->signal_type_text_label->setText(TR.tr("signalType"));
       ui->signal_addr_text_label->setText(TR.tr("signalAddr"));
       ui->signal_status_label->setText(TR.tr("currentStatus"));

       // 表格列标题
       ui->signals_tw->setHorizontalHeaderLabels({
           TR.tr("sn"),
           TR.tr("name"),
           TR.tr("type"),
           TR.tr("address"),
           TR.tr("status"),
           TR.tr("sort"),
           TR.tr("type"),
           TR.tr("sign")
       });

       // ========== 产品变量页面 ==========
       // 顶部按钮
       ui->label_14->setText(TR.tr("curProduct"));
       ui->var_ex2cur_btn->setText(TR.tr("switch"));
       ui->var_createByCur_btn->setText(TR.tr("createByCurrent"));
       ui->varSaveProByInputBtn->setText(TR.tr("createByName"));
       ui->var_savePro_btn->setText(TR.tr("save"));
       ui->var_ex2robot_btn->setText(TR.tr("ex2Robot"));

       // 操作按钮
       ui->var_manage_btn->setText(TR.tr("manage"));
       ui->var_import_btn->setText(TR.tr("import"));
       ui->var_save_btn->setText(TR.tr("save"));
       ui->var_export_btn->setText(TR.tr("export"));
       ui->var_delCurPro_btn->setText(TR.tr("delProduct"));
       ui->var_delSelect_btn->setText(TR.tr("delVar"));
       ui->var_signalsearch_btn->setText(TR.tr("searchBy"));

       // 变量信息标签
       ui->label_10->setText(TR.tr("varName"));
       ui->label_12->setText(TR.tr("value"));
       ui->label_15->setText(TR.tr("varType"));
       ui->label_18->setText(TR.tr("hold"));
       ui->setSelectVariableBtn->setText(TR.tr("set"));

       // 点位操作按钮
       ui->getCurJoint->setText(TR.tr("pointRecord"));
       ui->jointMoveBtn->setText(TR.tr("jointMove"));
       ui->lineMoveBtn->setText(TR.tr("lineMove"));

       // 提示标签
       ui->label_11->setText(TR.tr("selectVarTip"));

       // 变量表格列标题
       ui->variables_tw->setHorizontalHeaderLabels({
           TR.tr("id"),
           TR.tr("varNameCol"),
           TR.tr("varTypeCol"),
           TR.tr("values"),
           TR.tr("holdCol"),
           TR.tr("sortCol"),
           TR.tr("signCol"),
           TR.tr("alias"),
           TR.tr("productCol"),
           TR.tr("remark")
       });

       // ========== 帮助页面 ==========
       ui->help_copySelect_btn->setText(TR.tr("copy"));
       ui->fileViewTextEdit->setPlainText(TR.tr("hello"));

       // ========== 设置页面 ==========
       ui->label_17->setText(TR.tr("language"));
       ui->setting_save_btn->setText(TR.tr("save"));
       ui->setting_logout_btn->setText(TR.tr("logout"));
       ui->label_22->setText(TR.tr("logInfo"));
       ui->label_16->setText(TR.tr("robotThreadState"));
       ui->label_13->setText(TR.tr("remainingValidity"));
       ui->setting_robotInit_btn->setText(TR.tr("robotInit"));
       ui->setting_curVersion_tipLabel->setText(TR.tr("curVersionTips"));
       // ui->setting_curVersion_label->setText(TR.tr("curVersion"));


       // ========== 注册页面 ==========
       ui->register_show_label->setText(TR.tr("currentState"));
       ui->lockWRe_btn->setText(TR.tr("refresh"));
       ui->unlockBtn->setText(TR.tr("decode"));
       ui->lockKeyboardOpen_btn->setText(TR.tr("openKeyboard"));

       // ========== 通用标签 ==========
       // NULL 标签
       if (ui->signal_name_label->text() == "NULL") {
           ui->signal_name_label->setText(TR.tr("null"));
       }
       if (ui->signal_type_label->text() == "NULL") {
           ui->signal_type_label->setText(TR.tr("null"));
       }
       if (ui->signal_addr_label->text() == "NULL") {
           ui->signal_addr_label->setText(TR.tr("null"));
       }
       if (ui->currentPageNumLbel->text() == "NULL") {
           ui->currentPageNumLbel->setText(TR.tr("null"));
       }
       if (ui->totalPageNumLbel->text() == "NULL") {
           ui->totalPageNumLbel->setText(TR.tr("null"));
       }
       if (ui->varPageCur->text() == "NULL") {
           ui->varPageCur->setText(TR.tr("null"));
       }
       if (ui->varPageTotal->text() == "NULL") {
           ui->varPageTotal->setText(TR.tr("null"));
       }
       if (ui->selectVarName->text() == "NULL") {
           ui->selectVarName->setText(TR.tr("null"));
       }
       if (ui->selectVarValuePose->text() == "NUll") {
           ui->selectVarValuePose->setText(TR.tr("null"));
       }

       // Bool 下拉框
       ui->selectVarValueBool->setItemText(0, TR.tr("true"));
       ui->selectVarValueBool->setItemText(1, TR.tr("false"));

       qDebug() << "[ChargeForm] updateUI completed";
}

void chargeform::on_setting_save_btn_clicked()
{
    // 存储当前的语言
    configCon.updateConfig(8,QString::number(ui->setting_languageCombox->currentIndex()));

    QMessageBox::question(nullptr, "success",
                                              QString("数据保存完成!"),
                                              QMessageBox::Yes);
}

// 在你的类中添加成员函数
void chargeform::showNumericKeyboardAbove() {

    QLineEdit* targetEdit;
    if(ui->pageWidgets->currentIndex() == 0){
        targetEdit = ui->modSendEdit;
    }else{
        targetEdit = ui->selectVarValueNumber;
    }

    // 获取输入框在父窗口中的位置
    QPoint editPos = targetEdit->mapTo(this, QPoint(0, 0));

    // 计算键盘位置（输入框上方）
    int keyboardWidth = 250;
    int keyboardHeight = 200;

    int x = editPos.x();
    int y = editPos.y() - keyboardHeight - 5;  // 上方5像素间距

    // 边界检查 - 确保不超出父窗口
    // 左边界
    if (x < 10) {
        x = 10;
    }
    // 右边界
    if (x + keyboardWidth > this->width() - 10) {
        x = this->width() - keyboardWidth - 10;
    }
    // 上边界（如果上方空间不够，显示在下方）
    if (y < 10) {
        y = editPos.y() + targetEdit->height() + 5;  // 改为下方显示
    }
    // 下边界
    if (y + keyboardHeight > this->height() - 10) {
        y = this->height() - keyboardHeight - 10;
    }

    // 设置位置并显示
    numericKeyboard->move(x, y);
    numericKeyboard->raise();  // 提升到最上层
    numericKeyboard->show();

    // 调试输出
    qDebug() << "输入框位置:" << editPos;
    qDebug() << "键盘位置:" << QPoint(x, y);
}

void chargeform::on_lockKeyboardOpen_btn_clicked()
{
    alphanumericKeyboard->show();
    alphanumericKeyboard->raise();  // 置顶显示
}

int chargeform::robotLogin(){
    if(robotLoginState == 1)return 1;
    // 登录重试代码
    int maxRetries = 3;
    int retryDelay = 3000;

    addLogMessage("Starting robot connection...");

    for(int i = 0; i < maxRetries; i++) {
        addLogMessage(QString("Attempt %1/%2: Connecting to %3:%4...")
                      .arg(i + 1).arg(maxRetries)
                      .arg(SERVER_HOST).arg(SERVER_PORT));

        int ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");

        if(ret == aubo_robot_namespace::InterfaceCallSuccCode) {
            addLogMessage("✓ Robot connection successful!");
            robotLoginState = 1;
            return 1;
        }

        addLogMessage(QString("✗ Connection failed - Error code: %1").arg(ret));

        if(i < maxRetries - 1) {
            addLogMessage("⏳ Retrying in 3 seconds...");

            QEventLoop loop;
            QTimer::singleShot(retryDelay, &loop, &QEventLoop::quit);
            loop.exec();
        }
    }

    addLogMessage(QString("❌ Connection failed after %1 attempts").arg(maxRetries));
    QMessageBox::warning(nullptr, "Error", TR.tr("robotLoginFailure"));
    return 0;
}

void chargeform::addLogMessage(const QString &message)
{
    QStringList logs = m_logModel->stringList();
    QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss");
    logs.append(QString("[%1] %2").arg(timestamp).arg(message));
    m_logModel->setStringList(logs);

    // 滚动到底部
    ui->setting_info_listview->scrollToBottom();
    QApplication::processEvents();  // 刷新UI
}

void chargeform::on_setting_robotInit_btn_clicked()
{
    robotLogin();
}
