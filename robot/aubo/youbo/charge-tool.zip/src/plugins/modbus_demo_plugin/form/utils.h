#ifndef UTILS_H
#define UTILS_H

#include <QString>

class utils
{
public:
    utils();
    QString caesarEncrypt(const QString& text, int shift);
    QString caesarDecrypt(const QString& text, int shift);
    bool isCaesarCipher(const QString& original, const QString& encrypted, int shift);
    int findStringIndex(const QStringList &list, const QString &target);
    QStringList getUniqueColumnData(const QList<QStringList> &sheetList, int columnIndex);
    bool haveCommonItems(const QStringList &list1, const QStringList &list2);
    bool startsWithPrefix(const QString &str, const QString &prefix);

    /**
     * @brief isMd5Cipher
     * @param original 原密文
     * @param encrypted 加密后的字符
     * @return
     * 判断加密后的字符从头开始,在对应位是否相同,两者长度并不一定一致
     */
    bool isMd5Cipher(const QString& original, const QString& encrypted);

    QString generateRandomString(int length);

    // 计算字符串的MD5值
    std::string encrypt(const std::string& input);

    // 计算二进制数据的MD5值
    std::string encrypt(const uint8_t* data, size_t length);
    bool isSHA256Cipher(const QString &original, const QString &encrypted);
private:
    // MD5状态
    uint32_t state[4];
    uint64_t count;  // 已处理的位数
    uint8_t buffer[64];

    // 初始化MD5上下文
    void MD5init();

    // 更新MD5上下文
    void update(const uint8_t* input, size_t length);

    // 完成MD5计算并返回结果
    std::string finalize();

    // MD5核心变换函数
    void transform(const uint8_t block[64]);

    // 辅助函数
    static uint32_t F(uint32_t x, uint32_t y, uint32_t z);
    static uint32_t G(uint32_t x, uint32_t y, uint32_t z);
    static uint32_t H(uint32_t x, uint32_t y, uint32_t z);
    static uint32_t I(uint32_t x, uint32_t y, uint32_t z);
    static uint32_t rotateLeft(uint32_t x, uint32_t n);

    // 将结果转换为十六进制字符串
    std::string bytesToHexString(const uint8_t* bytes, size_t length);

    // 使用hma256
    std::string hmacSha256(const std::string &message, const std::string &key);
};

#endif // UTILS_H
