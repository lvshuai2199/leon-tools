#ifndef LOGGER_H
#define LOGGER_H

#include <QFile>
#include <QMutex>
#include <QString>

const QString LOG_FILE_PATH = "/root/Documents/log/logFile.log";

class Logger {
private:
    QFile file;
    QMutex mutex;

public:
    Logger();
    ~Logger();

    void log(const QString& message);
};

// 全局单例访问函数
Logger& getLogger();

#endif // LOGGER_H
