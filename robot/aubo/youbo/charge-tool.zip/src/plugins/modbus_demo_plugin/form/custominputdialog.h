#ifndef CUSTOMINPUTDIALOG_H
#define CUSTOMINPUTDIALOG_H

#include <QDialog>
#include <QLineEdit>

class CustomInputDialog : public QDialog {
    Q_OBJECT

public:
    explicit CustomInputDialog(const QString &initialText, QWidget *parent = nullptr);
    QString text() const;

    void handleDeleteButtonClick();
private slots:
    void handleButtonClick();

private:
    QLineEdit *lineEdit;
    QWidget *createButtonPanel();
};

#endif // CUSTOMINPUTDIALOG_H
