#include "db_manage.h"

#include <QCoreApplication>
#include <QFile>
#include <QStringList>
#include <QDebug>

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>

#include <QSqlRecord>


db_manage::db_manage(QObject *parent)
    : QObject(parent)
{
//    initDbFilePath();
//    connectToDatabase();
}

void db_manage::dbExportInit(){
    initDbFilePath();
    connectToDatabase();
}

void db_manage::ExcelLoad(QString filePath_str)
{
//    waitBlockRemove();
    qDebug() << "选择的文件地址为:" << filePath_str ;

    // 打开CSV文件，指定UTF-8编码
    QFile file(filePath_str);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qWarning() << "Could not open file";
        return;
    }

    QTextStream in(&file);
    // 指定使用UTF-8编码
    in.setCodec("UTF-8");

    QList<QStringList> dataArray;

    // 读取文件内容
    QStringList rowData;
    while (!in.atEnd()) {
        QString line = in.readLine();
        QStringList fields = line.split(","); // 以逗号分隔字段

        // 输出每一行数据
        qDebug() << "读取到的行数据：" << fields;

        // 将每7个字段作为一行存入dataArray
        rowData.append(fields);
        if (rowData.size() >= 6) {
            dataArray.append(rowData);
            rowData.clear();
        }
    }

    // 如果文件内容的字段数不是7的倍数，最后一行可能会少于7个字段，这里需要额外处理
    if (!rowData.isEmpty()) {
        dataArray.append(rowData);
    }

    file.close();
    if(arrInsert2DB(dataArray) == dbFail)return;

    qDebug() << "发射dataLoaded信号";
    emit dataLoaded();
}

void db_manage::slot_test(QString filePath_str)
{
    qDebug() << "发射dataLoaded信号";
    emit dataLoaded();
}

int db_manage::arrInsert2DB(QList<QStringList> dbArr)
{
    // 连接到 SQLite 数据库
    if(!dbUseStart())return dbFail;
    QSqlDatabase db = QSqlDatabase::database();
    // 开始事务
    QSqlQuery transactionQuery;
    if (!transactionQuery.exec("BEGIN TRANSACTION")) {
        qWarning() << "Failed to begin transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return dbFail;
    }

    // 删除旧数据
    QSqlQuery clearQuery;
    if (!clearQuery.exec("DELETE FROM signal_db")) {
        qWarning() << "Failed to delete old data from signal_db:" << clearQuery.lastError().text();
        transactionQuery.exec("ROLLBACK");
        db.close();
        dbUseEnd();
        return dbFail;
    }

    // 插入新数据
    QSqlQuery query;
    for (int i = 1; i < dbArr.size(); i++) {
        const QStringList &rowData = dbArr[i];

        query.prepare("INSERT INTO signal_db (signal_name, signal_type, signal_address, alians, sort_order, signal_category, filter_flag) "
                      "VALUES (:signal_name, :signal_type, :signal_address, :alians, :sort_order, :signal_category, :filter_flag)");

        query.bindValue(":signal_name", rowData[1]);
        query.bindValue(":signal_type", rowData[2]);
        query.bindValue(":signal_address", rowData[3]);
        query.bindValue(":alians", rowData[4]);
        query.bindValue(":sort_order", rowData[5].toInt());
        query.bindValue(":signal_category", rowData[6]);
        query.bindValue(":filter_flag", rowData[7]);


        if (!query.exec()) {
            qWarning() << "Failed to insert data:" << query.lastError().text();
            QSqlQuery transactionQuery;
            transactionQuery.exec("ROLLBACK");
            db.close();
            dbUseEnd();
            return dbFail;
        }

    }

    // 提交事务
    if (!transactionQuery.exec("COMMIT")) {
        qWarning() << "Failed to commit transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return dbFail;
    }

    // 关闭数据库连接
    db.close();
    dbUseEnd();
    return dbSucc;
}

void db_manage::waitBlockRemove()
{
    while(is_block){
        qDebug() << "等待数据库解锁--------------------------------<<<<<<<";
    }
    is_block = true;
    qDebug() << "数据库上锁已上锁--------------------------------<<<<<<<";
}


bool db_manage::connectToDatabase()
{
    getLogger().log("========== 开始连接数据库 ==========");

    QSqlDatabase db1 = QSqlDatabase::database(); // 获取默认数据库连接

    if (db1.isValid()) {
        QString connInfo = QString("当前数据库连接名: %1").arg(db1.connectionName());
        qDebug() << connInfo;
        getLogger().log(connInfo.toStdString().c_str());

        QString dbPath = QString("当前数据库路径: %1").arg(db1.databaseName());
        qDebug() << dbPath;
        getLogger().log(dbPath.toStdString().c_str());

        QString openStatus = QString("数据库是否打开: %1").arg(db1.isOpen() ? "是" : "否");
        getLogger().log(openStatus.toStdString().c_str());
    } else {
        qDebug() << "No valid database connection available.";
        getLogger().log("警告: 没有可用的有效数据库连接");
    }

    // 连接到 SQLite 数据库
    getLogger().log("尝试获取 QSQLITE 数据库驱动");
    static QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");

    if (!db.isOpen()) {
        getLogger().log("数据库未打开，准备建立连接");

        db.setDatabaseName(DbFileName);
        QString dbFileLog = QString("设置数据库文件: %1").arg(DbFileName);
        qDebug() << "currentDBPath: " << DbFileName;
        getLogger().log(dbFileLog.toStdString().c_str());

        if (!db.open()) {
            QString errorMsg = QString("数据库连接失败: %1, 错误: %2")
                              .arg(DbFileName)
                              .arg(db.lastError().text());
            qDebug() << errorMsg;
            getLogger().log(errorMsg.toStdString().c_str());
            getLogger().log("========== 数据库连接结束 (失败) ==========");
            return false;
        } else {
            QString successMsg = QString("数据库连接成功: %1").arg(DbFileName);
            qDebug() << "Database reconnected!";
            getLogger().log(successMsg.toStdString().c_str());
        }

        qDebug() << "Connected to database:" << DbFileName;
        getLogger().log("数据库已就绪，可执行操作");
    } else {
        qDebug() << "Already connected to database.";
        QString alreadyOpen = QString("数据库已处于打开状态: %1").arg(db.databaseName());
        getLogger().log(alreadyOpen.toStdString().c_str());
    }

    getLogger().log("========== 数据库连接结束 (成功) ==========");
    return true;
}



bool db_manage::dbUseStart()
{
//    if(!connectToDatabase())return false;
    waitBlockRemove();
    return true;
}

bool db_manage::dbUseEnd()
{
    is_block = false;
    qDebug()<< "数据库锁移除--------------------------------<<<<<<<";
}

void db_manage::initDbFilePath()
{
    this->DbFileName = configCon.configFileLoad(3);
    this->DbSysFileName = configCon.configFileLoad(4);
}



int db_manage::arrInsert2SysDB(QList<QStringList> dbArr)
{
    // 连接到 SQLite 数据库
    QSqlDatabase dbSys = QSqlDatabase::addDatabase("QSQLITE", "my_connection");
    dbSys.setDatabaseName(DbSysFileName);

    if (!dbSys.open()) {
        qDebug() << "Failed to open database:" << dbSys.lastError().text();
        return 0;
    }

    qDebug() << "Connected to database:" << DbSysFileName;

    // 开始事务
    QSqlQuery transactionQuery(dbSys);
    if (!transactionQuery.exec("BEGIN TRANSACTION")) {
        qWarning() << "Failed to begin transaction:" << transactionQuery.lastError().text();
        dbSys.close();
        return 0;
    }

    // 执行事务中的操作
    // 删除旧数据
    QSqlQuery clearQuery(dbSys);
    if (!clearQuery.exec("DELETE FROM variable")) {
        qWarning() << "Failed to delete old data from variable:" << clearQuery.lastError().text();
        transactionQuery.exec("ROLLBACK");
        dbSys.close();
        dbUseEnd();
        return 0;
    }

    // 插入新数据
    QSqlQuery query(dbSys);
    for (int i = 0; i < dbArr.size(); i++) {
        const QStringList &rowData = dbArr[i];

        query.prepare("INSERT INTO variable (name, type, value, is_global_hold) "
                      "VALUES (:name, :type, :value, :is_global_hold)");

        query.bindValue(":name", rowData[1]);
        query.bindValue(":type", rowData[2]);
        if(rowData[2] == "Pose"){
            QString modifiedData = rowData[3];
            QString poseData = modifiedData.replace(';', ',');
            query.bindValue(":value", poseData);
        }else {
            query.bindValue(":value", rowData[3]);
        }
        query.bindValue(":is_global_hold", rowData[4]);

        if (!query.exec()) {
            qWarning() << "Failed to insert data:" << query.lastError().text();
            QSqlQuery transactionQuery(dbSys);
            transactionQuery.exec("ROLLBACK");
            dbSys.close();
            dbUseEnd();
            return 0;
        }

    }


    // 提交事务
    if (!transactionQuery.exec("COMMIT")) {
        qWarning() << "Failed to commit transaction:" << transactionQuery.lastError().text();
        dbSys.rollback(); // 回滚事务
        dbSys.close();
        return 0;
    }

    // 关闭数据库连接
    dbSys.close();
    dbUseEnd();

    return 1;
}

void db_manage::updateDBFromData(const QList<QStringList> &data)
{
//    waitBlockRemove();
    // 连接到 SQLite 数据库
    if(!dbUseStart())return;
    QSqlDatabase db = QSqlDatabase::database();

    // 开始事务
    QSqlQuery transactionQuery(db);
    if (!transactionQuery.exec("BEGIN TRANSACTION")) {
        qWarning() << "Failed to begin transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return;
    }

    // 更新数据库
    QSqlQuery query(db);
    for (const QStringList &rowData : data) {
        int id = rowData[0].toInt();  // 假设 id 是第一列数据
        QString signalName = rowData[1];
        QString signalType = rowData[2];
        QString signalAddress = rowData[3];
        QString alians = rowData[4];
        int sortOrder = rowData[5].toInt();
        QString signalCategory = rowData[6];  // 假设 signal_category 是第七列数据
        QString filterFlag = rowData[7];

        QString updateQuery = "UPDATE signal_db SET signal_name = :signalName, signal_type = :signalType, "
                              "signal_address = :signalAddress, alians = :alians, sort_order = :sortOrder, "
                              "signal_category = :signalCategory, filter_flag = :filterFlag WHERE id = :id";

        query.prepare(updateQuery);
        query.bindValue(":signalName", signalName);
        query.bindValue(":signalType", signalType);
        query.bindValue(":signalAddress", signalAddress);
        query.bindValue(":alians", alians);
        query.bindValue(":sortOrder", sortOrder);
        query.bindValue(":signalCategory", signalCategory);
        query.bindValue(":filterFlag", filterFlag);
        query.bindValue(":id", id);

        if (!query.exec()) {
            qWarning() << "Failed to update data for ID" << id << ":" << query.lastError().text();
            transactionQuery.exec("ROLLBACK");
            db.close();
            dbUseEnd();
            return;
        }
    }

    // 提交事务
    if (!transactionQuery.exec("COMMIT")) {
        qWarning() << "Failed to commit transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return;
    }

    // 关闭数据库连接
    db.close();
    dbUseEnd();
}

int db_manage::updateProcedureDBData(const QList<QStringList> &data)
{
    // 连接到 SQLite 数据库
    if(!dbUseStart())return 0;
    QSqlDatabase db = QSqlDatabase::database();

    // 开始事务
    QSqlQuery transactionQuery(db);
    if (!transactionQuery.exec("BEGIN TRANSACTION")) {
        qWarning() << "Failed to begin transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return 0;
    }

    // 更新数据库
    QSqlQuery query(db);
    for (const QStringList &rowData : data) {
        int id = rowData[0].toInt();  // 假设 id 是第一列数据
        QString variableName = rowData[1];
        QString variableType = rowData[2];
        QString variableValue = rowData[3];
        QString isGlobalHold = rowData[4];
        int sortOrder = rowData[5].toInt();
        QString filterFlag = rowData[6];
        QString Alians = rowData[7];
        QString productName = rowData[8];
        QString annotate = rowData[9];

        QString updateQuery = "UPDATE procedure_db SET variable_name = :variableName,"
                              "variable_type = :variableType, variable_value = :variableValue,"
                              "is_global_hold = :isGlobalHold, sort_order = :sortOrder,"
                              "filter_flag = :filterFlag, alians = :Alians, product_name = :productName, annotate = :annotate WHERE id = :id";

        query.prepare(updateQuery);
        query.bindValue(":variableName", variableName);
        query.bindValue(":variableType", variableType);
        query.bindValue(":variableValue", variableValue);
        query.bindValue(":isGlobalHold", isGlobalHold);
        query.bindValue(":sortOrder", sortOrder);
        query.bindValue(":filterFlag", filterFlag);
        query.bindValue(":Alians", Alians);
        query.bindValue(":productName", productName);
        query.bindValue(":annotate", annotate);
        query.bindValue(":id", id);

        if (!query.exec()) {
            qWarning() << "Failed to update data for ID" << id << ":" << query.lastError().text();
            transactionQuery.exec("ROLLBACK");
            db.close();
            dbUseEnd();
            return 0;
        }
    }

    // 提交事务
    if (!transactionQuery.exec("COMMIT")) {
        qWarning() << "Failed to commit transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return 0;
    }

    // 关闭数据库连接
    db.close();
    dbUseEnd();
    return 1;
}

std::vector<std::vector<std::string>> db_manage::queryDatabase(int startIndex, int itemsPerPage, QString searchTerm)
{
    std::vector<std::vector<std::string>> data;

    try {
        // 记录输入参数
        QString paramLog = QString("查询数据库 - 参数: startIndex=%1, itemsPerPage=%2, searchTerm='%3'")
                          .arg(startIndex).arg(itemsPerPage).arg(searchTerm);
        qDebug() << paramLog;
        getLogger().log(paramLog.toStdString().c_str());

        // 重新连接数据库
        getLogger().log("准备断开并重新连接数据库");
        connectToDatabase();

        if (!dbUseStart()) {
            getLogger().log("数据库启动失败，返回空结果");
            return data;
        }

        getLogger().log("数据库连接成功");
        QSqlDatabase db = QSqlDatabase::database();
        QSqlQuery query;

        // 构建 SQL - 使用位置占位符
        QString queryString = "SELECT * FROM signal_db";
        if (!searchTerm.isEmpty()) {
            queryString += " WHERE filter_flag LIKE ?";
        }
        queryString += " ORDER BY sort_order LIMIT ? OFFSET ?";

        // 记录 SQL
        QString sqlLog = QString("执行 SQL: %1").arg(queryString);
        qDebug() << sqlLog;
        getLogger().log(sqlLog.toStdString().c_str());

        // 准备查询
        query.prepare(queryString);

        // 按顺序绑定参数
        int bindIndex = 0;
        if (!searchTerm.isEmpty()) {
            query.addBindValue("%" + searchTerm + "%");
            QString searchLog = QString("绑定参数[%1]: searchTerm='%%%2%%'").arg(bindIndex++).arg(searchTerm);
            getLogger().log(searchLog.toStdString().c_str());
        }
        query.addBindValue(itemsPerPage);
        QString limitLog = QString("绑定参数[%1]: limit=%2").arg(bindIndex++).arg(itemsPerPage);
        getLogger().log(limitLog.toStdString().c_str());

        query.addBindValue(startIndex);
        QString offsetLog = QString("绑定参数[%1]: offset=%2").arg(bindIndex++).arg(startIndex);
        getLogger().log(offsetLog.toStdString().c_str());

        // 执行查询
        getLogger().log("开始执行查询...");
        if (!query.exec()) {
            QString errorMsg = QString("查询执行失败: %1").arg(query.lastError().text());
            qWarning() << errorMsg;
            getLogger().log(errorMsg.toStdString().c_str());

            QString detailError = QString("SQL 错误 - 代码: %1, 类型: %2")
                                 .arg(query.lastError().number())
                                 .arg(query.lastError().type());
            getLogger().log(detailError.toStdString().c_str());

            db.close();
            dbUseEnd();
            getLogger().log("数据库已关闭");
            return data;
        }

        getLogger().log("查询执行成功，开始读取结果");

        // 读取结果
        int rowCount = 0;
        while (query.next()) {
            std::vector<std::string> row;
            QSqlRecord record = query.record();
            for (int column = 0; column < record.count(); ++column) {
                QVariant value = query.value(column);
                row.push_back(value.isNull() ? "" : value.toString().toStdString());
            }
            data.push_back(row);
            rowCount++;
        }

        QString resultLog = QString("查询完成，共读取 %1 行数据").arg(rowCount);
        qDebug() << resultLog;
        getLogger().log(resultLog.toStdString().c_str());

        db.close();
        dbUseEnd();
        getLogger().log("数据库连接已关闭");

    } catch (const std::exception& e) {
        QString errorMsg = QString("数据库操作异常: %1").arg(e.what());
        qWarning() << errorMsg;
        getLogger().log(errorMsg.toStdString().c_str());
    }

    return data;
}


std::vector<std::vector<std::string>> db_manage::queryProductDatabase(int startIndex, int itemsPerPage, QString searchTerm, QString productName)
{
    try{
//        waitBlockRemove();
        qDebug()<< "传入参数：startIndex：" << startIndex << "itemsPerPage:" << itemsPerPage << "serchText:" << searchTerm;
        std::vector<std::vector<std::string>> data;

        // 连接到 SQLite 数据库
        if(!dbUseStart()){
            return data;
        }
        QSqlDatabase db = QSqlDatabase::database();


        // 准备 SQL 查询
        QSqlQuery query;

        QString queryString = "SELECT * FROM procedure_db WHERE product_name  = :productName";
        if (!searchTerm.isEmpty()) {
            queryString += " AND filter_flag LIKE :searchTerm";
        }
        queryString += " ORDER BY sort_order LIMIT :limit OFFSET :offset";

        query.prepare(queryString);
        query.bindValue(":productName", productName);
        if (!searchTerm.isEmpty()) {
            query.bindValue(":searchTerm", "%" + searchTerm + "%");
        }
        query.bindValue(":limit", itemsPerPage);
        query.bindValue(":offset", startIndex);

        if (!query.exec()) {
            qWarning() << "Failed to execute query:" << query.lastError().text();
            db.close();
            dbUseEnd();
            return data;  // 返回空的 data
        }

        // 读取结果并存入 data 向量
        while (query.next()) {
            std::vector<std::string> row;
            QSqlRecord record = query.record();
            for (int column = 0; column < record.count(); ++column) {
                QVariant value = query.value(column);
                if (value.isNull()) {
                    row.push_back("");  // 或者可以在需要时根据具体情况处理 NULL 值
                } else {
                    row.push_back(value.toString().toStdString());
                }
            }
            data.push_back(row);
        }

        // 关闭数据库连接
        db.close();
        dbUseEnd();
        return data;  // 返回填充好的 data

    }catch (const std::invalid_argument& e) {
        // 处理转换失败的情况
//        QMessageBox::critical(nullptr, "Error", QString("数据库获取数据失败，Exception caught: ") + e.what());
        qDebug() << "数据库获取数据失败，Exception caught: " << e.what();
    }  
}

QList<QStringList> db_manage::getAllProductDatabase(QString productName)
{
    QList<QStringList> resultList;

    try {
        // 连接到 SQLite 数据库
        if (!dbUseStart()) {
            return resultList;
        }
        QSqlDatabase db = QSqlDatabase::database();

        // 准备 SQL 查询
        QSqlQuery query;

        QString queryString = "SELECT * FROM procedure_db WHERE product_name  = :productName";
        queryString += " ORDER BY sort_order";

        query.prepare(queryString);
        query.bindValue(":productName", productName);

        if (!query.exec()) {
            qWarning() << "Failed to execute query:" << query.lastError().text();
            db.close();
            dbUseEnd();
            return resultList;  // 返回空的 resultList
        }

        // 读取结果并存入 resultList
        while (query.next()) {
            QStringList rowList;
            QSqlRecord record = query.record();
            for (int column = 0; column < record.count(); ++column) {
                QVariant value = query.value(column);
                if (value.isNull()) {
                    rowList.append("");  // 处理 NULL 值
                } else {
                    rowList.append(value.toString());
                }
            }
            resultList.append(rowList);
        }

        // 关闭数据库连接
        db.close();
        dbUseEnd();

    } catch (const std::invalid_argument& e) {
        qDebug() << "数据库获取数据失败，Exception caught: " << e.what();
    }

    return resultList;
}


// 带 productName 参数的版本
void db_manage::getfFilterFlag(QStringList &items, const QString &productName)
{
    if (!dbUseStart()) return;
    QSqlDatabase db = QSqlDatabase::database();

    QString queryString= "SELECT filter_flag FROM procedure_db";
    if (!productName.isEmpty()) {
        queryString += " WHERE product_name = :productName";
    }
    QSqlQuery query(db);
    query.prepare(queryString);

    if (!productName.isEmpty()) {
        query.bindValue(":productName", productName);
    }
    if (!query.exec()) {
        qDebug() << "Error executing query:" << query.lastError().text();
        dbUseEnd();
        return;
    }

    while (query.next()) {
        QString fieldValue = query.value(0).toString();
        items.append(fieldValue);
    }

    dbUseEnd();
}

// 不带 productName 参数的版本
void db_manage::getfFilterFlag(QStringList &items)
{
    if (!dbUseStart()) return;
    QSqlDatabase db = QSqlDatabase::database();

    QString queryString= "SELECT filter_flag FROM signal_db";

    QSqlQuery query(db);
    query.prepare(queryString);
    if (!query.exec()) {
        qDebug() << "Error executing query:" << query.lastError().text();
        dbUseEnd();
        return;
    }

    while (query.next()) {
        QString fieldValue = query.value(0).toString();
        items.append(fieldValue);
    }

    dbUseEnd();
}

void db_manage::getProductItems(QStringList &items)
{
    // 连接到 SQLite 数据库
    if(!dbUseStart())return;
    QSqlDatabase db = QSqlDatabase::database();


    // 查询对应字段的所有内容
    QSqlQuery query("SELECT product_name FROM procedure_db", db);

    while (query.next()) {
        QString fieldValue = query.value(0).toString();
        items.append(fieldValue);
    }
    dbUseEnd();
}

int db_manage::arrInsert2ProcustDB(QList<QStringList> dbArr)
{
    // 连接到 SQLite 数据库
    if(!dbUseStart())return 0;
    QSqlDatabase db = QSqlDatabase::database();
    // 开始事务
    QSqlQuery transactionQuery;
    if (!transactionQuery.exec("BEGIN TRANSACTION")) {
        qWarning() << "Failed to begin transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return 0;
    }

    // 插入新数据
    QSqlQuery query;
    for (int i = 0; i < dbArr.size(); i++) {
        const QStringList &rowData = dbArr[i];

        QString variableName = rowData[1];
        QString variableType = rowData[2];
        QString variableValue = rowData[3];
        QString isGlobalHold = rowData[4];
        int sortOrder = rowData[5].toInt();
        QString filterFlag = rowData[6];
        QString Alians = rowData[7];
        QString productName = rowData[8];
        QString annotate = rowData[9];

        QString insertQuery = "INSERT INTO procedure_db(variable_name, variable_type, variable_value, is_global_hold, sort_order, filter_flag, alians, product_name, annotate) "
                                "VALUES (:variableName, :variableType, :variableValue, :isGlobalHold, :sortOrder, :filterFlag, :Alians, :productName, :annotate)";

        query.prepare(insertQuery);
        query.bindValue(":variableName", variableName);
        query.bindValue(":variableType", variableType);
        query.bindValue(":variableValue", variableValue);
        query.bindValue(":isGlobalHold", isGlobalHold);
        query.bindValue(":sortOrder", sortOrder);
        query.bindValue(":filterFlag", filterFlag);
        query.bindValue(":Alians", Alians);
        query.bindValue(":productName", productName);
        query.bindValue(":annotate", annotate);

        if (!query.exec()) {
            qWarning() << "Failed to insert data:" << query.lastError().text();
            QSqlQuery transactionQuery;
            transactionQuery.exec("ROLLBACK");
            db.close();
            dbUseEnd();
            return 0;
        }

    }

    // 提交事务
    if (!transactionQuery.exec("COMMIT")) {
        qWarning() << "Failed to commit transaction:" << transactionQuery.lastError().text();
        db.close();
        dbUseEnd();
        return 0;
    }

    // 关闭数据库连接
    db.close();
    dbUseEnd();
    return 1;

}

int db_manage::getTotalItemCount(QString searchText)
{
    int row = 0;

    // 连接到 SQLite 数据库
    if (!dbUseStart()) {
        return 0;
    }

    QSqlDatabase db = QSqlDatabase::database();
    QSqlQuery query(db);

    QString queryString = "SELECT COUNT(*) FROM signal_db";
    if (!searchText.isEmpty()) {
        queryString += " WHERE filter_flag = :searchText";
    }
    queryString += " ORDER BY sort_order";

    query.prepare(queryString);
    if (!searchText.isEmpty()) {
        query.bindValue(":searchText", searchText);
    }

    if (query.exec()) {
        if (query.next()) {
            row = query.value(0).toInt(); // 获取 COUNT(*) 的结果
        }
    } else {
        qDebug() << "Error executing query:" << query.lastError().text();
    }

    // 关闭数据库连接
    dbUseEnd();

    return row;
}

/**
 * 获取所有符合条件的参数的数量
 * @brief db_manage::getVarTotalItemCount
 * @param searchText
 * @return
 */
int db_manage::getVarTotalItemCount(QString searchText, QString productName)
{
    int row = 0;

    // 连接到 SQLite 数据库
    if (!dbUseStart()) {
        return 0;
    }

    QSqlDatabase db = QSqlDatabase::database();
    QSqlQuery query(db);

    QString queryString = "SELECT COUNT(*) FROM procedure_db WHERE product_name = :productName";
    if (!searchText.isEmpty()) {
        queryString += " AND filter_flag = :searchText";
    }

    query.prepare(queryString);
    query.bindValue(":productName", productName);

    if (!searchText.isEmpty()) {
        query.bindValue(":searchText", searchText);
    }

    if (query.exec() && query.next()) {
        row = query.value(0).toInt(); // 获取 COUNT(*) 的结果
    } else {
        qDebug() << "Error executing query:" << query.lastError().text();
    }

    // 关闭数据库连接
    dbUseEnd();

    return row;
}

void db_manage::deleteDataByProductName(const QString &productName)
{

    // 连接到 SQLite 数据库
    if (!dbUseStart()) {
        return;
    }

    QSqlDatabase db = QSqlDatabase::database();

    // 开始事务
    QSqlQuery transactionQuery(db);
    if (!transactionQuery.exec("BEGIN TRANSACTION")) {
        qWarning() << "Failed to begin transaction:" << transactionQuery.lastError().text();
        db.close();
        return;
    }

    // 删除对应 product_name 的数据项
    QSqlQuery deleteQuery;
    deleteQuery.prepare("DELETE FROM procedure_db WHERE product_name = :productName");
    deleteQuery.bindValue(":productName", productName);

    if (!deleteQuery.exec()) {
        qWarning() << "Failed to delete data with product_name" << productName << ":" << deleteQuery.lastError().text();
        transactionQuery.exec("ROLLBACK");
        db.close();
        return;
    }

    // 提交事务
    if (!transactionQuery.exec("COMMIT")) {
        qWarning() << "Failed to commit transaction:" << transactionQuery.lastError().text();
        db.rollback(); // 回滚事务
    }

    // 关闭数据库连接
    db.close();
    // 关闭数据库连接
    dbUseEnd();
}

int db_manage::deleteDataByID(const int &id)
{
    try{

        // 连接到 SQLite 数据库
        if (!dbUseStart()) {
            return 0;
        }

        QSqlDatabase db = QSqlDatabase::database();

        // 开始事务
        QSqlQuery transactionQuery(db);
        if (!transactionQuery.exec("BEGIN TRANSACTION")) {
            qWarning() << "Failed to begin transaction:" << transactionQuery.lastError().text();
            db.close();
            return 0;
        }

        // 删除对应 product_name 的数据项
        QSqlQuery deleteQuery;
        deleteQuery.prepare("DELETE FROM procedure_db WHERE id = :id");
        deleteQuery.bindValue(":id", id);

        if (!deleteQuery.exec()) {
            qWarning() << "Failed to delete data with product_name" << id << ":" << deleteQuery.lastError().text();
            transactionQuery.exec("ROLLBACK");
            db.close();
            return 0;
        }

        // 提交事务
        if (!transactionQuery.exec("COMMIT")) {
            qWarning() << "Failed to commit transaction:" << transactionQuery.lastError().text();
            db.rollback(); // 回滚事务
            return 0;
        }

        // 关闭数据库连接
        db.close();
        // 关闭数据库连接
        dbUseEnd();

    } catch (const std::invalid_argument& e) {
        qDebug() << "数据库获取数据失败，Exception caught: " << e.what();
        return 0;
    }

    return 1;


}



db_manage &getDbCon()
{
    static db_manage db_instance;
    return db_instance;
}
