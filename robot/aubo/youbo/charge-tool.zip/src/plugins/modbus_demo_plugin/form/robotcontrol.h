#ifndef ROBOTCONTROL_H
#define ROBOTCONTROL_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
#define SERVER_HOST "127.0.0.1"
//#define SERVER_HOST "192.168.31.66"
#define SERVER_PORT 8899

class robotControl
{
public:
    robotControl();

    // 定义结构体
   struct IoData {
       std::string ioType;
       std::string ioName;
       double ioState;
   };

   // 一个成员函数，用于获取 I/O 数据
   IoData getIoData() {
       IoData data;
       data.ioName = "Tool Sensor";
       data.ioState = 1.0; // 例如状态为“激活”
       return data;
   }
    /**
      使用的机械臂接口
      1. 关节运动
      2. 直线运动
      3. 松开按钮触发机械臂运动停止
      4. 设置信号(IO,工具IO)
      5. 获取信号(IO,工具IO)

      */

   void con_moveJoint(double joint_qua[aubo_robot_namespace::ARM_DOF] );

   void con_moveLine(double joint_qua[aubo_robot_namespace::ARM_DOF] );

   void con_moveFastStop();

   void con_ioChangeByName(std::string ioName);
   void con_toolIoChangeByName(std::string ioName);

   double con_getIoState(std::string ioName);
   double con_getToolIoState(std::string ioName);


private:

   void robotInit();

   void robotMoveFastStop();

   double robotGetIoState(std::string ioName);

   void robotSetIo(std::string ioName, bool ioState);

   double robotGetToolIoState(std::string ioName);
   void robotSetToolIo(std::string ioName, bool ioState);


    //定义全局控制器
    ServiceInterface robotService;

};

#endif // ROBOTCONTROL_H
