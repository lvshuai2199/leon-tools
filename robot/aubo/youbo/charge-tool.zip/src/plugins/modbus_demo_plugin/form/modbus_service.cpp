#include "modbus_service.h"

#include <QDebug>



modbus_service::modbus_service()
{
    modbusdev_ptr_ = std::make_shared<ModbusDev>();
    connectModbusSlave();
}



void modbus_service::connectModbusSlave()
{
    QString slave_ip = configCon.configFileLoad(1);

    qDebug() << "连接的slave_ip：" << slave_ip;
    QByteArray ba = slave_ip.toUtf8();
    const char *ip_cstr = ba.data();

    int ret = modbusdev_ptr_->modbusConnectTcp(ip_cstr, SLAVE_PORT, SLAVE_ADDR, SLAVE_TIMEOUT);
    if (ret >= 0) {
        qDebug() << "Modbus device connected successfully.";
        // Proceed with further operations upon successful connection
    } else {
        qDebug() << "Failed to connect to Modbus device. Error code: " << ret;
        // Handle failure case
    }
}

int modbus_service::on_pbn_set_register(int addr,int var)
{
//    connectModbusSlave();
    int ret = modbusdev_ptr_->modbusWriteRegister(addr, var);
    qDebug() << "ｍｏｄｂｕｓ寄存器写入返回值：" << ret ;
    return ret;
}

QString modbus_service::on_pbn_get_register(int addr)
{
    uint16_t buf[1] = {0};
    int ret = modbusdev_ptr_->modbusReadRegisters(addr, 1, buf);
    if(ret == 0){
        qDebug()<< "getModbusDataSuccess!";
    }else{
        qDebug()<< "getModbusDataSuccess!";
    }
    return QString::number(buf[0]);
}

void modbus_service::mod_reconnect()
{
    connectModbusSlave();
}

int modbus_service::on_pbn_set_digital(int addr,int var)
{
    int ret = modbusdev_ptr_->modbusWriteBit(addr,var);
    qDebug() << "ｍｏｄｂｕｓ寄存器写入返回值：" << ret ;
    return ret;
}

QString modbus_service::on_pbn_get_digital(int addr)
{
    uint8_t buf[1] = {0}; // 如果是单个线圈，可以使用 uint8_t 类型的缓冲区
    int ret = modbusdev_ptr_->modbusReadBits(addr, 1, buf);
    if (ret == 0) {
        qDebug() << "成功读取Modbus线圈：" << addr << "，状态为：" << (buf[0] ? "开" : "关");
    } else {
        qDebug() << "读取Modbus线圈失败：" << addr << "，错误码：" << ret;
    }
    return QString::number(buf[0]);
}
