#ifndef CONFIG_MANEGE_H
#define CONFIG_MANEGE_H

#include <QSettings>

#include <QDebug>

class config_manege
{
public:
    config_manege();

public:
    int configFileSave();

    QString configFileLoad(int getDataType);
};

#endif // CONFIG_MANEGE_H
