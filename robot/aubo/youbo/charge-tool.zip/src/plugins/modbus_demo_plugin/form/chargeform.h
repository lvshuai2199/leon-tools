#ifndef CHARGEFORM_H
#define CHARGEFORM_H

#include <QWidget>
#include <QThread>
#include <QStringListModel>

#include "db_manage.h"
#include "modbus_service.h"
#include "config_manage.h"
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
#include "languagemanager.h"

#define SERVER_HOST "127.0.0.1"
//#define SERVER_HOST "192.168.31.66"
#define SERVER_PORT 8899

#include <QDebug>

#include "abstractwidget.h"

namespace Ui {
class chargeform;
}

class chargeform : public QWidget
{
    Q_OBJECT

public:
    explicit chargeform(QWidget *parent = 0);
    ~chargeform();

    // 声明枚举类型，页面排序
    enum PAGE {
        SIGNALSPAGE,
        VARIABLESPAGE,
        HELPPAGE,
        SETTINGPAGE
    };
    Q_ENUM(PAGE)

    // 声明枚举类型，表示有效日期时常
    enum ValidityPeriod {
        ONE_MONTH = 30,     // 一个月
        TWO_MONTHS = 60,    // 两个月
        FOUR_MONTHS = 120,   // 四个月
        SIX_MONTHS = 180,    // 六个月
        THIRTEEN_MONTHS = 390, // 十三个月,交期
        PERMANENT = 999     // 永久
    };
    Q_ENUM(ValidityPeriod)


signals:
    /**
     * @brief signal_test
     * @param filePath
     * 传递地址参数进行信号列表的导入
     */
    void signal_test(QString filePath);

    /**
     * @brief signal_threadCon
     * @param threadCon
     * 切换线程检索状态
     */
    void signal_threadCon(bool threadCon);

    void signal_threadCon_lock(bool threadCon_lock);

    void signal_thread_start();
    void signal_setlockModAddr(int lockmodaddr);

    /**
     * @brief signal_deliever
     * @param signal_deli
     * 传递需要检索的数据，由后端线程进行处理
     */
    void signal_deliever(std::vector<std::vector<std::string>> signal_deli);


public slots:
    /**
     * @brief onDataLoaded
     * 表格显示的主体功能项
     */
    void onDataLoaded();

    /**
     * @brief onVariableDataLoaded
     * 变量页面的加载
     */
    void onVariableDataLoaded();

    /**
     * @brief onItemSelected
     * 当表单中某列被选中时进行的处理
     */
    void onItemSelected();

    /**
     * @brief onVariableItemSelected
     * 变量页面某栏数据被选中
     */
    void onVariableItemSelected();

    // 在chargeform类中添加一个槽函数用于处理数据已检索的信号
    void onDataRetrieved() {
        qDebug() << "线程";
        compareSignalsData(); // 调用之前的数据加载函数
    }

    /**
     * @brief startDataRetrievalThread
     * 连接对应插槽，启用线程
     */
    void startDataRetrievalThread();


private slots:
    /**
     * @brief on_signal_import_btn_clicked
     * 信号页面：加载
     */
    void on_signal_import_btn_clicked();

    /**
     * @brief on_signal_sort_btn_clicked
     * 开启表格可编辑模式，显示保存按钮
     */
    void on_signal_sort_btn_clicked();

    /**
     * @brief on_signal_save_btn_clicked
     * 保存按钮，在保存的同时，设置一些表格配置配置项
     * 设置表格第五列隐藏，设置表格不可编辑
     */
    void on_signal_save_btn_clicked();

    /**
     * @brief on_signal_ex_btn_clicked
     * 信号页面：IO状态切换
     */
    void on_signal_ex_btn_clicked();

    /**
     * @brief on_signal_sendMod_btn_clicked
     * 设置modbus的不同状态
     */
    void on_signal_sendMod_btn_clicked();
    void on_signal_sendMod1_btn_clicked();
    void on_signal_sendMod0_btn_clicked();

    /**
     * @brief on_signal_data_left_clicked
     * 分页功能
     */
    void on_signal_data_left_clicked();
    void on_signal_data_right_clicked();
    void on_signal_search_btn_clicked();


    /**
     * @brief on_fileViewPageBtn_clicked
     * 页面切换
     */
    void on_signal_page_btn_clicked();
    void on_help_page_btn_clicked();

    void on_var_ex2robot_btn_clicked();

    void on_var_savePro_btn_clicked();

    void on_var_manage_btn_clicked();

    void on_var_import_btn_clicked();

    void on_var_save_btn_clicked();

    void on_var_ex2cur_btn_clicked();

    void on_var_signalsearch_btn_clicked();

    void on_varPagePro_clicked();

    void on_varPageNext_clicked();

    void on_var_delCurPro_btn_clicked();

    void on_setSelectVariableBtn_clicked();

    void on_getCurJoint_clicked();

    void on_jointMoveBtn_pressed();

    void on_jointMoveBtn_released();

    void on_lineMoveBtn_pressed();

    void on_lineMoveBtn_released();
    
    void on_varSaveProByInputBtn_clicked();

    void on_var_delSelect_btn_clicked();

    void on_var_export_btn_clicked();

    void on_help_copySelect_btn_clicked();

    void on_unlockBtn_clicked();

    void on_var_createByCur_btn_clicked();

    void on_setting_page_btn_clicked();

    void on_setting_logout_btn_clicked();

    void on_lockWRe_btn_clicked();

    void on_setting_languageCombox_currentIndexChanged(int index);

    void on_var_page_btn_clicked();

    void on_setting_save_btn_clicked();

    void on_lockKeyboardOpen_btn_clicked();

    void on_setting_robotInit_btn_clicked();

private:

    Ui::chargeform *ui;

    // 统一使用智能指针管理
//    std::unique_ptr<robotControl> robotCon;
//    std::unique_ptr<db_manage> db_manTh;
//    std::unique_ptr<QThread> commDB;
//    std::unique_ptr<db_manage> db_Con;
//    std::unique_ptr<config_manage> configCon;
//    std::unique_ptr<modbus_service> modCon;
    // 机械臂控制单元
//    robotControl *robotCon;
    int robotLoginState = 0;
    // 做线程处理
    db_manage *db_manTh;
    QThread *commDB;

//    db_manage db_Con;
    config_manage configCon;
    modbus_service modCon;

    //定义全局控制器
    ServiceInterface robotService;

    //定义信号的值
    QString ioIsOn = "ON";
    QString ioIsOff = "OFF";

    //键盘的控件
    QWidget *numericKeyboard;
    void showNumericKeyboardAbove();
    bool isKeyboardVisible;  // 控制数字键盘显示状态的变量

    // 分页及数据显示
    struct PageInfo {
        int currentPage;
        int totalPages;
        int itemsPerPage;
        int totalItems;
        QString searchText;
        std::vector<std::vector<std::string>> items; // 假设每条记录是一个字符串，可以根据实际情况修改类型
    };

    PageInfo pageInfo;

    QString curProductName;

    // 变量页面是否处于管理状态
    bool isVarPageModifyOn = false;

    // 是否处于combox填充状态
    bool ignoreIndexChanged = false;

    // 是否处于combox填充状态
//    bool isCurrentPageChanged = false;

    int scrollIndex = 0;

//    文件地址选择
    QString openFile();
    void Add2datasheet(QList<QStringList> signalList);

    void Add2Vardatasheet(QList<QStringList> dataList);


    QList<QStringList> fileLoad2QList();

    void compareSignalsData();

    /**
     * @brief keyBoardInit
     * 键盘
     */
    void keyBoardInit();
    void showKeyBoard();
    void handleButtonClick(const QString &text);
    void handleDeleteButton();

    void proEditKeyboard();



    QWidget *alphanumericKeyboard;  // 字母数字键盘
    void alphanumericKeyBoardInit();
    void handleKeyboardButtonClick(const QString &text);
    void handleKeyboardDeleteButton();
    void handleKeyboardClearButton();
    bool isUpperCase;  // 是否大写模式

    /**
     * @brief chargeInit
     * 整体页面内容初始化
     */
    void chargeInit();

    /**
     * @brief updateSignalsTable
     * @param updateSignalItems
     */
    void updateSignalsTable(std::vector<std::vector<std::string>> updateSignalItems);

    /**
     * @brief signal_status_labelShow
     * @param ioStatus
     * 信号页面：IO状态
     */
    void signal_status_labelShow(QString ioStatus);

    /**
     * @brief datasheetOut2List
     * @param pageType
     * @return
     * 表格内容转换为list
     */
    QList<QStringList> datasheetOut2List(int pageType);

    /**
     * @brief setModData
     * @param sendData
     * 设置modbus数据
     */
    int setModData(int sendData = -1);

    /**
     * @brief fillSignalCombox
     * 信号页面下拉框填充
     */
    void fillSignalCombox();

    /**
     * @brief fillProductCombox
     * 变量页面下拉框填充
     */
    void fillProductCombox();

    /**
     * @brief ex_page2modify_status
     * 变量页面管理的展示切换
     */
    void ex_page2modify_status();

    // 文件页面显示文件信息
    QString fileRootPath = "";
    QString fileViewTextPath = "";
    void fillFileViewCombox();
    void fileViewTextShow();
    void fileViewPathEx();

    void pageInfoSet(int currentPage);
    PageInfo getPageInfo(int currentPage, int itemsPerPage, QString serchText);


    void pageInfoShow();

    void pageLogoShow();

    void systemPassCheck(bool useInput);
    int robotLogin();


    QStringListModel *m_logModel;  // 日志模型

    void addLogMessage(const QString &message);

public:
    std::vector<std::vector<std::string>> current_pageSignales;
};

#include "logger.h"
#include <QMessageBox>
// 新线程类
class DataRetrievalThread : public QThread
{
    Q_OBJECT

signals:
//    void dataRetrieved();
    //发送对应数据到主线程进行数据刷新
    void dataSendToMaster(std::vector<std::vector<std::string>> signalsend);

public slots:
    void exchangeThreadStatus(bool isthreadoff); // 停止线程的槽函数

    void exchangeThreadStatus_lock(bool islockoff);

    void set_lock_mod_addr(int lockmodaddr);

    void set_thread_start();


    void signalGet(std::vector<std::vector<std::string>> signalsGet);

private:
    std::vector<std::vector<std::string>> threadsignalsGet;

    bool isSignalBlock;

    //定义全局控制器
    ServiceInterface robotService;

    //modbus控制器
    modbus_service modCon;


//    检查是否存在乱码
    bool hasGarbage(const std::vector<std::vector<std::string>>& signalsGet);

    bool containsGarbage(const std::string& str);

protected:

    bool m_start = false;
    bool m_stop; // 标志来指示线程是否应该停止
    bool m_lock = true; // 标志来指示线程是否应该停止
    int m_lockmodaddr = 2999;
    /**
     * @brief run
     * 多线程进行数据获取
     * 检测对应地区的数据值,并在出现异常时重新链接对应的modbus处理程序
     */
    void run() override {
        try{
            //处理好所有数据后,再开始线程
            while(!m_start){
                std::cout << "线程未启动!!!" << std::endl;
                getLogger().log("线程未启动!!!");
                QThread::sleep(1);
            }
            getLogger().log("线程开始运行，当前锁地址：" + QString::number(m_lockmodaddr));

            while(m_lock){
                std::cout << "当前为锁定状态" << std::endl;
                modCon.on_pbn_set_digital(m_lockmodaddr,1);
                std::cout << m_lockmodaddr << std::endl;
                getLogger().log("当前为锁定状态，锁地址：" + QString::number(m_lockmodaddr));
                QThread::sleep(3);
            }

            modCon.on_pbn_set_digital(m_lockmodaddr,0);
            getLogger().log("解锁信号发送：" + QString::number(m_lockmodaddr));

            qRegisterMetaType<std::vector<std::vector<std::string>>>("std::vector<std::vector<std::string>>");

            int num = 0;
            int loginRes = 10000;

            while(true){
                if(!m_stop){
                    num++;

                    // 检查登录状态并重新登录
                    if(loginRes != aubo_robot_namespace::InterfaceCallSuccCode){
                        robotService.robotServiceLogout();
                        QThread::sleep(1); // 等待注销完成

                        loginRes = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
                        std::cout << "进行线程连接:IP:" << SERVER_HOST << ",端口:" << SERVER_PORT << ",当前登录状态为-----" << loginRes << std::endl;

                        if(loginRes == aubo_robot_namespace::InterfaceCallSuccCode){
                            getLogger().log("机械臂登录成功!!!");
                            QThread::sleep(1); // 登录成功后等待连接稳定
                        }else{
                            getLogger().log("机械臂登录失败!!!，失败码：" + QString::number(loginRes));
                            QThread::sleep(3);
                        }
                        continue; // 重新登录后直接进入下一轮循环
                    }

                    std::cout<<"robot is login state."<<std::endl;

                    isSignalBlock = true;
                    std::vector<std::vector<std::string>> tempsignalsStatusGet = threadsignalsGet;
                    isSignalBlock = false;

                    bool hasConnectionError = false; // 添加连接错误标志

                    getLogger().log("获取数据中!!!");
                    // 使用范围for循环遍历外部vector
                    for (auto& innerVector : tempsignalsStatusGet) {
                        // 如果已经检测到连接错误，跳出循环
                        if(hasConnectionError) {
                            break;
                        }

                        if(loginRes == aubo_robot_namespace::InterfaceCallSuccCode)
                        {
                            std::string signal_name = innerVector[3];
                            std::cout << "现在获取的是" << signal_name << std::endl;

                            int signalTypeFlag = 0;
                            double value = 0.0;
                            int errnoRet = 0;

                            if(innerVector[2].find("IO") != std::string::npos || innerVector[2].find("TOOL") != std::string::npos){
                                signalTypeFlag = 1;
                                std::string getDataType= "";

                                if(innerVector[2].find("IO") != std::string::npos){
                                    aubo_robot_namespace::RobotIoType ioType = aubo_robot_namespace::RobotBoardUserDI;
                                    getDataType = "IO_IN";

                                    if(innerVector[6] == "OUT"){
                                        ioType = aubo_robot_namespace::RobotBoardUserDO;
                                        getDataType = "IO_OUT";
                                    }
                                    errnoRet = robotService.robotServiceGetBoardIOStatus(ioType, signal_name, value);
                                    std::cout << "获取用户IO数据RES:" << errnoRet << std::endl;
                                }else if(innerVector[2].find("TOOL") != std::string::npos){
                                    getDataType = "IO_TOOL";
                                    errnoRet = robotService.robotServiceGetToolIoStatus(signal_name, value);
                                    std::cout << "获取工具IO数据RES:" << errnoRet << std::endl;
                                }

                                if(errnoRet != aubo_robot_namespace::InterfaceCallSuccCode &&
                                   errnoRet != aubo_robot_namespace::ErrCode_RealRobotNoExist){
                                    QString logMsg = QString("线程:检索的IO参数为 -- DATA TYPE:%1,IO SIGNAL NAME：%2,ROBOT RES: %3,ROBOT VALUE: %4")
                                        .arg(QString::fromStdString(getDataType))
                                        .arg(QString::fromStdString(signal_name))
                                        .arg(errnoRet)
                                        .arg(value);
                                    getLogger().log(logMsg);
                                }
                            }

                            if(signalTypeFlag == 1){
                                if(errnoRet == aubo_robot_namespace::InterfaceCallSuccCode){
                                    std::cout << "线程:接口调用成功!!!" << std::endl;
                                    std::cout<< signal_name << value << std::endl;
                                    innerVector[4] = (value == 1.0) ? "ON" : "OFF";
                                }else if(errnoRet == aubo_robot_namespace::ErrCode_RealRobotNoExist){
                                    std::cout << "线程:接口调用失败!!!" << std::endl;
                                    innerVector[4] = "虚拟机";
                                }else if(errnoRet == aubo_robot_namespace::ErrCode_ParamError){
                                    std::cout << "线程:参数错误!" << std::endl;
                                    innerVector[4] = "参数错误!";
                                    getLogger().log("参数错误，信号：" + QString::fromStdString(signal_name));
                                    loginRes = aubo_robot_namespace::ErrCode_RealRobotNoExist;
                                    hasConnectionError = true;
                                    break;
                                }else{
                                    std::cout << "线程:机械臂断开连接!!!错误码：" << errnoRet << std::endl;
                                    getLogger().log("机械臂连接异常，错误码：" + QString::number(errnoRet) + "，信号：" + QString::fromStdString(signal_name));
                                    loginRes = aubo_robot_namespace::ErrCode_RealRobotNoExist;
                                    hasConnectionError = true;
                                    break;
                                }
                            } else if(innerVector[2].find("MOD") != std::string::npos && signalTypeFlag == 0){
                                try {
                                    if(innerVector[2].find("COIL") != std::string::npos){
                                        QString modGetRes = modCon.on_pbn_get_digital(std::stoi(signal_name));
                                        if(modGetRes == "1"){
                                            innerVector[4] = "ON";
                                        }else if(modGetRes == "0"){
                                            innerVector[4] = "OFF";
                                        }else {
                                            innerVector[4] = "ERROR!!!";
                                        }
                                    }else{
                                        QString modGetRes = modCon.on_pbn_get_register(std::stoi(signal_name));
                                        innerVector[4] = modGetRes.toStdString();
                                    }
                                } catch (const std::invalid_argument& e) {
                                    innerVector[4] = "地址位数据无法转换为字符串";
                                }
                            } else{
                                innerVector[4] = "信号异常";
                            }

                            std::cout << "信号:" << signal_name << "处理完成!" << std::endl;
                            signalTypeFlag = 0;
                        }

                        // 打印处理后的每一行
                        for (const auto& str : innerVector) {
                            std::cout << str << " ";
                        }
                        std::cout <<"当前行数据处理完成!" << std::endl;
                    }

                    // 只有在没有连接错误时才发送数据
                    if(!hasConnectionError){
                        emit dataSendToMaster(tempsignalsStatusGet);
                    }

                    QThread::sleep(1);
                }else{
                    qDebug() << "m_stop状态：" << m_stop;
                    QThread::sleep(2);
                }
            }
        }catch (const std::exception& e) {
            // 捕获所有标准异常
            QString errorMsg = QString("Exception caught: ") + e.what();
            getLogger().log(errorMsg);
            qDebug() << errorMsg;
        }
    }

};

//#include <QApplication>
#include <QTableWidget>
#include <QStyledItemDelegate>
#include <QPainter>
#include <QStyleOptionViewItem>
// 自定义委托类QStringListModel
class CircleDelegate : public QStyledItemDelegate {
public:
    CircleDelegate(QObject *parent = nullptr) : QStyledItemDelegate(parent) {}

    // 重写绘制方法
    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const override {
        // 获取单元格文本内容
        QString text = index.data(Qt::DisplayRole).toString();

        if(text == "ON" || text == "OFF"){
//            圆形套在文字外围
//            // 获取绘制区域
//            QRect rect = option.rect;

//            // 确保绘制的是正方形
//            int side = qMin(rect.width(), rect.height());
//            rect.setSize(QSize(side, side));
//            rect.moveCenter(option.rect.center());

            //圆形与文字分开
            // 获取绘制区域
            QRect rect = option.rect;

            // 计算圆形绘制区域，留出一定的边距
            int margin = 4; // 间距大小，根据需要调整
            int diameter = qMin(rect.width(), rect.height()) - 2 * margin; // 直径
            QRect circleRect = QRect(rect.topLeft() + QPoint(margin, margin), QSize(diameter, diameter));

            // 根据内容绘制圆形
            painter->setRenderHint(QPainter::Antialiasing); // 抗锯齿

            // 根据内容绘制圆形
            if (text == "ON") {
                painter->setBrush(Qt::green); // ON 状态为绿色圆形
            } else if (text == "OFF") {
                painter->setBrush(Qt::red); // OFF 状态为红色圆形
            } else {
                painter->setBrush(Qt::gray); // 其他状态为灰色圆形
            }
            painter->drawEllipse(circleRect);
        }

        // 绘制文本
        painter->drawText(option.rect, Qt::AlignCenter, text);

    }
};

#endif // CHARGEFORM_H
