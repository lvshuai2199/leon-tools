#include "logger.h"
#include <QTextStream>
#include <QDateTime>
#include <QMutexLocker>
#include <QDebug>
#include <QFileInfo>
#include <QDir>

Logger::Logger() : file(LOG_FILE_PATH) {

    // 确保日志目录存在
    QFileInfo fileInfo(LOG_FILE_PATH);
    QDir().mkpath(fileInfo.absolutePath());

    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        qWarning() << "无法打开日志文件:" << LOG_FILE_PATH;
    }
}

Logger::~Logger() {
    if (file.isOpen()) {
        file.close();
    }
}

void Logger::log(const QString& message) {
    QMutexLocker locker(&mutex);

    if (!file.isOpen()) return;

    QTextStream stream(&file);
    stream << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
           << " - " << message << "\n";
    stream.flush();
}

Logger& getLogger() {
    static Logger instance;
    return instance;
}
