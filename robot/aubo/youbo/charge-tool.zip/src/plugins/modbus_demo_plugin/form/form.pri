!isEmpty(FORM_PRI_INCLUDED):error("form.pri already included")
FORM_PRI_INCLUDED = 1

FORMS += \
    $$PWD/chargeform.ui \
    $$PWD/chargeconditionform.ui

HEADERS += \
    $$PWD/chargeform.h \
    $$PWD/db_manage.h \
    $$PWD/modbus_service.h \
    $$PWD/config_manage.h \
    $$PWD/utils.h \
    $$PWD/custominputdialog.h \
    $$PWD/md5.h \
    $$PWD/languagemanager.h \
    $$PWD/logger.h \
    $$PWD/chargeconditionform.h

SOURCES += \
    $$PWD/chargeform.cpp \
    $$PWD/db_manage.cpp \
    $$PWD/modbus_service.cpp \
    $$PWD/config_manage.cpp \
    $$PWD/utils.cpp \
    $$PWD/custominputdialog.cpp \
    $$PWD/md5.cpp \
    $$PWD/languagemanager.cpp \
    $$PWD/logger.cpp \
    $$PWD/chargeconditionform.cpp
