#ifndef CHARGECONDITIONFORM_H
#define CHARGECONDITIONFORM_H

#include "abstractwidget.h"

#include <QWidget>

#include "logger.h"

namespace Ui {
class chargeconditionform;
}

class AbsCondInfo;

class chargeconditionform : public AbstractWidget<Ui::chargeconditionform>
{
    Q_OBJECT

public:
    static chargeconditionform *instance();

    explicit chargeconditionform(QWidget *parent = 0);
    ~chargeconditionform();

    void updateCondForm(AbsCondInfo *absCondInfo);
private:
    Ui::chargeconditionform *ui;
};

#endif // CHARGECONDITIONFORM_H
