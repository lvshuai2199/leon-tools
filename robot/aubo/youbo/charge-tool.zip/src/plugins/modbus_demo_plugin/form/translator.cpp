#include "translator.h"

void Translator::initTranslations()
{
    // ========== 中文 (0) ==========
    m_dict[0]["start"] = "开始";
    m_dict[0]["stop"] = "停止";
    m_dict[0]["connect"] = "连接";
    m_dict[0]["disconnect"] = "断开";
    m_dict[0]["exit"] = "退出";
    m_dict[0]["import"] = "导入";
    m_dict[0]["export"] = "导出";
    m_dict[0]["sorted"] = "排序";
    m_dict[0]["save"] = "保存";
    m_dict[0]["search"] = "搜索";
    m_dict[0]["send"] = "发送";
    m_dict[0]["delete"] = "删除";
    m_dict[0]["refresh"] = "刷新";
    m_dict[0]["decode"] = "解密";
    m_dict[0]["confirm"] = "确认";
    m_dict[0]["cancel"] = "取消";
    m_dict[0]["clear"] = "清空";

    // 页面标题
    m_dict[0]["signal"] = "信号管理";
    m_dict[0]["signals"] = "信号管理";
    m_dict[0]["product"] = "产品切换";
    m_dict[0]["productChange"] = "产品切换";
    m_dict[0]["help"] = "帮助文档";
    m_dict[0]["setting"] = "系统设置";

    // 1. 信号页面
    m_dict[0]["signalName"] = "信号名称：";
    m_dict[0]["signalType"] = "信号类型：";
    m_dict[0]["signalAddr"] = "信号地址：";
    m_dict[0]["status"] = "状态：";
    m_dict[0]["currentStatus"] = "当前状态";
    m_dict[0]["switch"] = "切换";
    m_dict[0]["sn"] = "序号";
    m_dict[0]["name"] = "名称";
    m_dict[0]["type"] = "类型";
    m_dict[0]["address"] = "地址";
    m_dict[0]["sort"] = "排序";
    m_dict[0]["sign"] = "标识";

    // 2. 产品页面
    m_dict[0]["curProduct"] = "当前产品：";
    m_dict[0]["saveCopy"] = "存储副本";
    m_dict[0]["ex2Robot"] = "导出至机器人";
    m_dict[0]["createByCurrent"] = "基于当前创建";
    m_dict[0]["createByName"] = "按该名称新建产品";
    m_dict[0]["manage"] = "管理";
    m_dict[0]["delProduct"] = "删除此产品";
    m_dict[0]["delVar"] = "删除变量";
    m_dict[0]["varName"] = "名称：";
    m_dict[0]["varType"] = "类型：";
    m_dict[0]["category"] = "类别：";
    m_dict[0]["keep"] = "保持：";
    m_dict[0]["hold"] = "保持：";
    m_dict[0]["value"] = "值：";
    m_dict[0]["values"] = "值";
    m_dict[0]["pointRecord"] = "点位记录";
    m_dict[0]["waypointRecord"] = "路点记录";
    m_dict[0]["jointMotion"] = "关节运动";
    m_dict[0]["jointMove"] = "关节运动";
    m_dict[0]["linearMotion"] = "直线运动";
    m_dict[0]["lineMove"] = "直线运动";
    m_dict[0]["set"] = "设置";
    m_dict[0]["alias"] = "别名";
    m_dict[0]["remark"] = "备注";
    m_dict[0]["selectVarTip"] = "请选择需要操作的变量";
    m_dict[0]["searchBy"] = "搜索";

    // 表格列名
    m_dict[0]["id"] = "ID";
    m_dict[0]["varNameCol"] = "变量名称";
    m_dict[0]["varTypeCol"] = "变量类型";
    m_dict[0]["productCol"] = "产品";

    // 3. 帮助页面
    m_dict[0]["copy"] = "复制";
    m_dict[0]["hello"] = "你好，世界！！！";

    // 4. 设置页面
    m_dict[0]["language"] = "语言：";
    m_dict[0]["robotIP"] = "机器人IP：";
    m_dict[0]["logout"] = "注销";
    m_dict[0]["log"] = "日志信息：";
    m_dict[0]["logInfo"] = "日志信息：";
    m_dict[0]["robotThreadState"] = "机器人线程连接状态：";
    m_dict[0]["remainingValidity"] = "剩余有效期：";
    m_dict[0]["registerTips"] = "提示:系统未解密，将限制机床部分功能使用，解锁使用所有功能!!!";

    // 5. 注册/解锁页面
    m_dict[0]["currentState"] = "当前状态：";
    m_dict[0]["passwordInput"] = "密码输入";
    m_dict[0]["lockWord"] = "锁字";

    // 通用
    m_dict[0]["null"] = "空";
    m_dict[0]["textLabel"] = "文本标签";
    m_dict[0]["form"] = "表单";
    m_dict[0]["true"] = "真";
    m_dict[0]["false"] = "假";
    m_dict[0]["chinese"] = "中文";
    m_dict[0]["english"] = "英文";

    // ========== 英文 (1) ==========
    m_dict[1]["start"] = "Start";
    m_dict[1]["stop"] = "Stop";
    m_dict[1]["connect"] = "Connect";
    m_dict[1]["disconnect"] = "Disconnect";
    m_dict[1]["exit"] = "Exit";
    m_dict[1]["import"] = "Import";
    m_dict[1]["export"] = "Export";
    m_dict[1]["sorted"] = "Sort";
    m_dict[1]["save"] = "Save";
    m_dict[1]["search"] = "Search";
    m_dict[1]["send"] = "Send";
    m_dict[1]["delete"] = "Delete";
    m_dict[1]["refresh"] = "Refresh";
    m_dict[1]["decode"] = "Decode";
    m_dict[1]["confirm"] = "Confirm";
    m_dict[1]["cancel"] = "Cancel";
    m_dict[1]["clear"] = "Clear";

    // 页面标题
    m_dict[1]["signal"] = "SIGNALS";
    m_dict[1]["signals"] = "SIGNALS";
    m_dict[1]["product"] = "PRODUCT CHANGE";
    m_dict[1]["productChange"] = "PRODUCT CHANGE";
    m_dict[1]["help"] = "HELP";
    m_dict[1]["setting"] = "Setting";

    // 1. 信号页面
    m_dict[1]["signalName"] = "Signal Name:";
    m_dict[1]["signalType"] = "Signal Type:";
    m_dict[1]["signalAddr"] = "Signal Address:";
    m_dict[1]["status"] = "Status:";
    m_dict[1]["currentStatus"] = "Current Status";
    m_dict[1]["switch"] = "Switch";
    m_dict[1]["sn"] = "SN";
    m_dict[1]["name"] = "NAME";
    m_dict[1]["type"] = "TYPE";
    m_dict[1]["address"] = "ADDRESS";
    m_dict[1]["sort"] = "SORT";
    m_dict[1]["sign"] = "SIGN";

    // 2. 产品页面
    m_dict[1]["curProduct"] = "Current Product:";
    m_dict[1]["saveCopy"] = "Save Copy";
    m_dict[1]["ex2Robot"] = "Export to Robot";
    m_dict[1]["createByCurrent"] = "Create by Current";
    m_dict[1]["createByName"] = "Create Product by This Name";
    m_dict[1]["manage"] = "Manage";
    m_dict[1]["delProduct"] = "Delete This Product";
    m_dict[1]["delVar"] = "Delete Variable";
    m_dict[1]["varName"] = "Name:";
    m_dict[1]["varType"] = "Type:";
    m_dict[1]["category"] = "Category:";
    m_dict[1]["keep"] = "Keep:";
    m_dict[1]["hold"] = "Hold:";
    m_dict[1]["value"] = "Value:";
    m_dict[1]["values"] = "VALUES";
    m_dict[1]["pointRecord"] = "Point Record";
    m_dict[1]["waypointRecord"] = "Waypoint Record";
    m_dict[1]["jointMotion"] = "Joint Motion";
    m_dict[1]["jointMove"] = "Joint Move";
    m_dict[1]["linearMotion"] = "Linear Motion";
    m_dict[1]["lineMove"] = "Line Move";
    m_dict[1]["set"] = "SET";
    m_dict[1]["alias"] = "ALIAS";
    m_dict[1]["remark"] = "REMARK";
    m_dict[1]["selectVarTip"] = "Please select the variable to operate";
    m_dict[1]["searchBy"] = "Search By";

    // 表格列名
    m_dict[1]["id"] = "ID";
    m_dict[1]["varNameCol"] = "VAR NAME";
    m_dict[1]["varTypeCol"] = "VAR TYPE";
    m_dict[1]["productCol"] = "PRODUCT";

    // 3. 帮助页面
    m_dict[1]["copy"] = "Copy";
    m_dict[1]["hello"] = "Hello, World!!!";

    // 4. 设置页面
    m_dict[1]["language"] = "Language:";
    m_dict[1]["robotIP"] = "Robot IP:";
    m_dict[1]["logout"] = "Logout";
    m_dict[1]["log"] = "Log:";
    m_dict[1]["logInfo"] = "Log Information:";
    m_dict[1]["robotThreadState"] = "Robot Thread Connect State:";
    m_dict[1]["remainingValidity"] = "Remaining Validity Period:";
    m_dict[1]["registerTips"] = "Tips: The system is not decrypted, which will restrict the use of some functions of the machine tool. Unlock to use all functions.";

    // 5. 注册/解锁页面
    m_dict[1]["currentState"] = "Current State:";
    m_dict[1]["passwordInput"] = "Password Input";
    m_dict[1]["lockWord"] = "Lock Word";

    // 通用
    m_dict[1]["null"] = "NULL";
    m_dict[1]["textLabel"] = "TextLabel";
    m_dict[1]["form"] = "Form";
    m_dict[1]["true"] = "True";
    m_dict[1]["false"] = "False";
    m_dict[1]["chinese"] = "中文";
    m_dict[1]["english"] = "English";
}
