#include "custominputdialog.h"
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QDebug>

CustomInputDialog::CustomInputDialog(const QString &initialText, QWidget *parent)
    : QDialog(parent) {
    setWindowTitle("Input Dialog");

    QVBoxLayout *mainLayout = new QVBoxLayout(this);

    lineEdit = new QLineEdit(this);
    lineEdit->setText(initialText);  // 设置初始文本
    mainLayout->addWidget(lineEdit);

    QWidget *buttonPanel = createButtonPanel();
    mainLayout->addWidget(buttonPanel);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    QPushButton *okButton = new QPushButton("OK", this);
    QPushButton *cancelButton = new QPushButton("Cancel", this);

    buttonLayout->addWidget(okButton);
    buttonLayout->addWidget(cancelButton);

    mainLayout->addLayout(buttonLayout);

    connect(okButton, &QPushButton::clicked, this, &CustomInputDialog::accept);
    connect(cancelButton, &QPushButton::clicked, this, &CustomInputDialog::reject);
}

QString CustomInputDialog::text() const {
    return lineEdit->text();
}

QWidget* CustomInputDialog::createButtonPanel() {
    QWidget *panel = new QWidget(this);
    QGridLayout *gridLayout = new QGridLayout(panel);

    QString characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    int row = 0;
    int col = 0;

    for (int i = 0; i < characters.length(); ++i) {
        QPushButton *button = new QPushButton(QString(characters[i]), this);
        gridLayout->addWidget(button, row, col);
        connect(button, &QPushButton::clicked, this, &CustomInputDialog::handleButtonClick);

        col++;
        if (col > 5) {
            col = 0;
            row++;
        }
    }

    // 添加删除按钮，设置它占用整行
    QPushButton *deleteButton = new QPushButton("Del", this);
    gridLayout->addWidget(deleteButton, row, 0, 1, 6);  // 占用从第0列到第5列的整个行
    connect(deleteButton, &QPushButton::clicked, this, &CustomInputDialog::handleDeleteButtonClick);

    return panel;
}

void CustomInputDialog::handleButtonClick() {
    QPushButton *button = qobject_cast<QPushButton*>(sender());
    if (button) {
        lineEdit->insert(button->text());
    }
}

void CustomInputDialog::handleDeleteButtonClick() {
    QString text = lineEdit->text();
    if (!text.isEmpty()) {
        text.chop(1); // 删除最后一个字符
        lineEdit->setText(text);
    }
}
