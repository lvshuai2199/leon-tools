#ifndef MODBUS_SERVICE_H
#define MODBUS_SERVICE_H

#include <memory>
#include <QString>

#include "modbusdev.h"

#define SLAVE_ADDR                (0x01)
#define SLAVE_TIMEOUT              (500)
#define SLAVE_PORT (502)

#include "config_manage.h"

class modbus_service
{
public:
    modbus_service();

    //写寄存器
    int on_pbn_set_register(int addr,int var);
    //读寄存器
    QString on_pbn_get_register(int addr);

    void mod_reconnect();

    //写线圈
    int on_pbn_set_digital(int addr,int var);
    //读线圈
    QString on_pbn_get_digital(int addr);

//    //写寄存器
//    void on_pbn_set_register_clicked();
//    //读寄存器
//    void on_pbn_get_register_clicked();

private:
    //连接从站
    void connectModbusSlave();

    std::shared_ptr<ModbusDev> modbusdev_ptr_;

    config_manage configCon;
};

#endif // MODBUS_SERVICE_H
