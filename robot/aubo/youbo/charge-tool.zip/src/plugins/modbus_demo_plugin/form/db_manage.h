#ifndef DB_MANAGE_H
#define DB_MANAGE_H

#include <QObject>

#include <qthread.h>

#include "config_manage.h"

#include "logger.h"

class db_manage : public QObject
{
    Q_OBJECT // 添加QObject宏

public:
    explicit db_manage(QObject *parent = nullptr); // 构造函数声明为explicit


    // 获取信号页面的全部数据信息
    int getTotalItemCount(QString searchText);

    int getVarTotalItemCount(QString searchText, QString productName);
    void deleteDataByProductName(const QString &productName);

    void getfFilterFlag(QStringList &items);
    void getfFilterFlag(QStringList &items, const QString &productName);
    int deleteDataByID(const int &id);
    void dbExportInit();
signals:
    void dataLoaded(); // 数据加载完成信号声明


public slots:
    void ExcelLoad(QString filePath_str); // 槽函数声明
    void slot_test(QString filePath_str);

    void updateDBFromData(const QList<QStringList> &data);

    int updateProcedureDBData(const QList<QStringList> &data);

    std::vector<std::vector<std::string> > queryDatabase(int startIndex, int itemsPerPage, QString searchTerm );


    void getProductItems(QStringList &items);


    int arrInsert2ProcustDB(QList<QStringList> dbArr);
    int arrInsert2SysDB(QList<QStringList> dbArr);

    std::vector<std::vector<std::string> > queryProductDatabase(int startIndex, int itemsPerPage, QString searchTerm, QString productName);
    QList<QStringList> getAllProductDatabase(QString productName);
private:

    /**
     * @brief initDbFilePath
     * 设置全局的数据库位置信息
     */
    void initDbFilePath();
    // 声明全局变量
    QString DbFileName;
    QString DbSysFileName;
    QString currentDbName;

    int arrInsert2DB(QList<QStringList> dbArr);

    bool is_block = false;

    void waitBlockRemove();

    bool connectToDatabase();

    bool dbUseStart();
    bool dbUseEnd();

    config_manage configCon;

    // 声明枚举类型，页面排序
    enum DBRESCODE {
        dbSucc,
        dbFail
    };


};

// 全局单例访问函数
db_manage& getDbCon();

#endif // DB_MANAGE_H

