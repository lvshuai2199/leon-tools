#ifndef CONFIG_MANAGE_H
#define CONFIG_MANAGE_H
#include <QString>

class config_manage
{
public:
    config_manage();
public:
    int configFileSave();

    QString configFileLoad(int getDataType);

    void setupSettings();

    int updateConfig(int dataType, QString data);
    QStringList getPassKeys();
    void updatePassKeys(QString PassKey = "", QString LockWords = "");

    QString generateRandomString(int length);
private:
//    QString CONFIG_PATH = "/root/Documents/charge-tool/myconfig.ini";
    QString CONFIG_PATH = "/root/AuboRobotWorkSpace/teachpendant/share/teachpendant/plugins/ModbusDemo/myconfig.ini";
};

#endif // CONFIG_MANAGE_H
