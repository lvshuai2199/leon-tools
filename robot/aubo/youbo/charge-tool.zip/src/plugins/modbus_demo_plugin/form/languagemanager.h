// languagemanager.h
#ifndef LANGUAGEMANAGER_H
#define LANGUAGEMANAGER_H

#include <QString>
#include <QMap>

class LanguageManager  // ✅ 大写 L 和 M
{
public:
    static LanguageManager& instance();  // ✅ 加 static

    void setLanguage(int lang);
    QString tr(const QString &key);

private:
    LanguageManager();  // ✅ 大写，构造函数私有

    int m_lang;
    QMap<QString, QString> m_dict[2];

    void initDict();
};
// 全局访问宏
#define TR LanguageManager::instance()

#endif
