// languagemanager.cpp
#include "languagemanager.h"

LanguageManager& LanguageManager::instance()  // ✅ 都改成大写
{
    static LanguageManager mgr;  // ✅ 大写
    return mgr;
}

LanguageManager::LanguageManager() : m_lang(0)  // ✅ 大写
{
    initDict();
}

void LanguageManager::setLanguage(int lang)  // ✅ 大写
{
    m_lang = lang;
}

QString LanguageManager::tr(const QString &key)  // ✅ 大写
{
    return m_dict[m_lang].value(key, key);
}

void LanguageManager::initDict()  // ✅ 大写
{
    // ========== 中文翻译 (索引 0) ==========

    // 页面标题
    m_dict[0]["signals"] = "信号";
    m_dict[0]["productChange"] = "产品";
    m_dict[0]["help"] = "帮助";
    m_dict[0]["setting"] = "设置";

    // 信号页面按钮
    m_dict[0]["import"] = "导入";
    m_dict[0]["sorted"] = "排序";
    m_dict[0]["save"] = "保存";
    m_dict[0]["search"] = "搜索";
    m_dict[0]["switch"] = "切换";
    m_dict[0]["send"] = "发送";

    // 信号页面标签
    m_dict[0]["signalName"] = "信号名称";
    m_dict[0]["signalType"] = "信号类型";
    m_dict[0]["signalAddr"] = "信号地址";
    m_dict[0]["currentStatus"] = "当前状态";

    // 信号表格列标题
    m_dict[0]["sn"] = "序号";
    m_dict[0]["name"] = "名称";
    m_dict[0]["type"] = "类型";
    m_dict[0]["address"] = "地址";
    m_dict[0]["status"] = "状态";
    m_dict[0]["sort"] = "排序";
    m_dict[0]["sign"] = "标识";

    // 产品变量页面
    m_dict[0]["curProduct"] = "当前产品：";
    m_dict[0]["createByCurrent"] = "根据当前创建";
    m_dict[0]["createByName"] = "按该名称新建产品";
    m_dict[0]["ex2Robot"] = "导出到机器人";
    m_dict[0]["manage"] = "管理";
    m_dict[0]["exit"] = "退出";
    m_dict[0]["export"] = "导出";
    m_dict[0]["delProduct"] = "删除该产品";
    m_dict[0]["delVar"] = "删除变量";
    m_dict[0]["searchBy"] = "搜索";

    // 变量操作
    m_dict[0]["varName"] = "名称：";
    m_dict[0]["value"] = "值：";
    m_dict[0]["varType"] = "类型：";
    m_dict[0]["hold"] = "保持：";
    m_dict[0]["set"] = "设置";

    // 路点操作
    m_dict[0]["pointRecord"] = "路点记录";
    m_dict[0]["jointMove"] = "关节移动";
    m_dict[0]["lineMove"] = "直线移动";
    m_dict[0]["selectVarTip"] = "请选择需要操作的变量";

    // 变量表格列
    m_dict[0]["id"] = "ID";
    m_dict[0]["varNameCol"] = "变量名";
    m_dict[0]["varTypeCol"] = "变量类型";
    m_dict[0]["values"] = "值";
    m_dict[0]["holdCol"] = "保持";
    m_dict[0]["sortCol"] = "排序";
    m_dict[0]["signCol"] = "标识";
    m_dict[0]["alias"] = "别名";
    m_dict[0]["productCol"] = "产品";
    m_dict[0]["remark"] = "备注";

    // 帮助页面
    m_dict[0]["copy"] = "复制";
    m_dict[0]["hello"] = "你好，世界！！！";

    // 设置页面
    m_dict[0]["language"] = "语言：";
    m_dict[0]["logout"] = "登出";
    m_dict[0]["logInfo"] = "日志信息：";
    m_dict[0]["robotThreadState"] = "机器人线程连接状态：";
    m_dict[0]["remainingValidity"] = "剩余有效期：";
    m_dict[0]["curVersionTips"] = "版本";

    // 注册页面
    m_dict[0]["currentState"] = "当前状态：";
    m_dict[0]["refresh"] = "刷新";
    m_dict[0]["decode"] = "解码";
    m_dict[0]["openKeyboard"] = "打开键盘";

    // 通用
    m_dict[0]["null"] = "空";
    m_dict[0]["true"] = "真";
    m_dict[0]["false"] = "假";


    // ========== 英文翻译 (索引 1) ==========

    // 页面标题
    m_dict[1]["signals"] = "SIGNALS";
    m_dict[1]["productChange"] = "PRODUCT";
    m_dict[1]["help"] = "HELP";
    m_dict[1]["setting"] = "Setting";

    // 信号页面按钮
    m_dict[1]["import"] = "import";
    m_dict[1]["sorted"] = "sorted";
    m_dict[1]["save"] = "save";
    m_dict[1]["search"] = "Search";
    m_dict[1]["switch"] = "switch";
    m_dict[1]["send"] = "Send";

    // 信号页面标签
    m_dict[1]["signalName"] = "Signal Name:";
    m_dict[1]["signalType"] = "Signal Type:";
    m_dict[1]["signalAddr"] = "Signal Address:";
    m_dict[1]["currentStatus"] = "CurrentStatus";

    // 信号表格列标题
    m_dict[1]["sn"] = "SN";
    m_dict[1]["name"] = "NAME";
    m_dict[1]["type"] = "TYPE";
    m_dict[1]["address"] = "ADDRESS";
    m_dict[1]["status"] = "STATUS";
    m_dict[1]["sort"] = "SORT";
    m_dict[1]["sign"] = "SIGN";

    // 产品变量页面
    m_dict[1]["curProduct"] = "Current Product:";
    m_dict[1]["createByCurrent"] = "create by current";
    m_dict[1]["createByName"] = "Create by this name";
    m_dict[1]["ex2Robot"] = "export to robot";
    m_dict[1]["manage"] = "manage";
    m_dict[1]["exit"] = "exit";
    m_dict[1]["export"] = "export";
    m_dict[1]["delProduct"] = "del this product";
    m_dict[1]["delVar"] = "delete variable";
    m_dict[1]["searchBy"] = "Search By";

    // 变量操作
    m_dict[1]["varName"] = "name:";
    m_dict[1]["value"] = "value:";
    m_dict[1]["varType"] = "type:";
    m_dict[1]["hold"] = "hold:";
    m_dict[1]["set"] = "SET";

    // 路点操作
    m_dict[1]["pointRecord"] = "waypoint record";
    m_dict[1]["jointMove"] = "Joint Move";
    m_dict[1]["lineMove"] = "Line Move";
    m_dict[1]["selectVarTip"] = "Please select a variable to operate";

    // 变量表格列
    m_dict[1]["id"] = "ID";
    m_dict[1]["varNameCol"] = "VAR NAME";
    m_dict[1]["varTypeCol"] = "VAR TYPE";
    m_dict[1]["values"] = "VALUS";
    m_dict[1]["holdCol"] = "HOLD";
    m_dict[1]["sortCol"] = "SORT";
    m_dict[1]["signCol"] = "SIGN";
    m_dict[1]["alias"] = "ALIANS";
    m_dict[1]["productCol"] = "PRODUCT";
    m_dict[1]["remark"] = "REMARK";

    // 帮助页面
    m_dict[1]["copy"] = "Copy";
    m_dict[1]["hello"] = "Hello, World!!!";

    // 设置页面
    m_dict[1]["language"] = "language:";
    m_dict[1]["logout"] = "logout";
    m_dict[1]["logInfo"] = "Log Info:";
    m_dict[1]["robotThreadState"] = "Robot thread connect state:";
    m_dict[1]["remainingValidity"] = "remaining validity period:";
    m_dict[1]["curVersionTips"] = "Version:";

    // 注册页面
    m_dict[1]["currentState"] = "Current State:";
    m_dict[1]["refresh"] = "refresh";
    m_dict[1]["decode"] = "decode";
    m_dict[1]["openKeyboard"] = "open keyboard";

    // 通用
    m_dict[1]["null"] = "NULL";
    m_dict[1]["true"] = "true";
    m_dict[1]["false"] = "false";

    // ==================== 弹窗提示 ====================

    // 注销警告
    m_dict[0]["logoutWarning"] = "注销操作会关闭插件，部分功能将无法使用。\n重新使用需联系厂家解密，请谨慎操作！";
    m_dict[1]["logoutWarning"] = "Logout will disable the plugin and some functions will be unavailable.\nTo re-enable, please contact the manufacturer for decryption.\nPlease proceed with caution!";

    // ==================== 文件存储提示 ====================

    // 文件保存成功
    m_dict[0]["filesaveWarning"] = "文件保存成功！";
    m_dict[1]["filesaveWarning"] = "File saved successfully!";

    // 文件保存失败
    m_dict[0]["filesaveDefaultWarning"] = "文件保存失败！";
    m_dict[1]["filesaveDefaultWarning"] = "File save failed!";

    // ==================== 变量导入导出提示 ====================

    // 数据导入成功
    m_dict[0]["varExportSucc"] = "数据导入机械臂成功！\n重新启动机械臂后生效。";
    m_dict[1]["varExportSucc"] = "Data imported to robot successfully!\nPlease restart the robot to take effect.";

    // 数据导入失败 - 重复变量名
    m_dict[0]["varExportDefault1"] = "数据导入机械臂失败！\n请检查是否存在重复的变量名称。";
    m_dict[1]["varExportDefault1"] = "Data import to robot failed!\nPlease check for duplicate variable names.";

    // 数据导入失败 - 无数据
    m_dict[0]["varExportDefault2"] = "表格无数据，导入机械臂失败！";
    m_dict[1]["varExportDefault2"] = "No data in table, import to robot failed!";

    // ==================== 产品导入提示 ====================

    // 产品导入成功
    m_dict[0]["varSaveProSucc"] = "产品导入完成，已切换至产品：";
    m_dict[1]["varSaveProSucc"] = "Product imported successfully, switched to product: ";

    // 产品导入失败 - 数据冲突
    m_dict[0]["varSaveProDefault1"] = "与数据库中数据冲突，无法进行产品存储。\n产品导入失败，请确认产品名称后重新导入！";
    m_dict[1]["varSaveProDefault1"] = "Data conflict with database, unable to save product.\nProduct import failed, please verify the product name and try again!";

    // 产品导入失败 - 无产品信息
    m_dict[0]["varSaveProDefault2"] = "无产品信息，请重新选择产品。";
    m_dict[1]["varSaveProDefault2"] = "No product information, please select a product again.";

    // 机械臂信息
    m_dict[0]["robotLoginFailure"] = "机械臂登录失败";
    m_dict[1]["robotLoginFailure"] = "Failed to LoginRobot.";

    m_dict[0]["failure"] = "切换失败";
    m_dict[1]["failure"] = "Switching failed.";

    m_dict[0]["robotInit"] = "机械臂初始化";
    m_dict[1]["robotInit"] = "Robot Init";

}
