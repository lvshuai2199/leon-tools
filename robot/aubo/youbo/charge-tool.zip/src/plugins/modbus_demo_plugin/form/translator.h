#ifndef TRANSLATOR_H
#define TRANSLATOR_H

#include <QObject>
#include <QMap>
#include <QString>
#include <QDebug>

class Translator : public QObject
{
    Q_OBJECT

public:
    static Translator& instance() {
        static Translator instance;
        return instance;
    }

    // 在 translator.h 中
    QString tr(const QString& key) {
        qDebug() << "翻译单词" << key;
        if (!m_dict.contains(m_currentLanguage)) {
            qWarning() << "[Translator] Invalid language:" << m_currentLanguage;
            return key;
        }

        QString result = m_dict[m_currentLanguage].value(key, key);

        // 只在找不到翻译时输出警告
        if (result == key && !m_dict[m_currentLanguage].contains(key)) {
            qWarning() << "[Translator] Missing translation for key:" << key
                       << "in language:" << m_currentLanguage;
        }

        return result;
    }


    // 设置语言 - 修复版本
    void setLanguage(int langIndex) {
        qDebug() << "setLanguage called with index:" << langIndex;
        qDebug() << "Current language before:" << m_currentLanguage;

        if (langIndex >= 0 && langIndex <= 1) {
            if (m_currentLanguage != langIndex) {  // 只有语言真正改变时才发射信号
                m_currentLanguage = langIndex;
                qDebug() << "Language changed to:" << m_currentLanguage;
                emit languageChanged(m_currentLanguage);  // 发射信号并传递语言索引
                qDebug() << "languageChanged signal emitted";
            } else {
                qDebug() << "Language not changed, same as current";
            }
        } else {
            qDebug() << "Invalid language index:" << langIndex;
        }
    }

    // 获取当前语言
    int getCurrentLanguage() const {
        return m_currentLanguage;
    }

signals:
    void languageChanged(int langIndex);  // 添加参数，方便接收者使用

private:
    Translator() {
        m_currentLanguage = 0; // 默认中文
        qDebug() << "Translator initialized with language:" << m_currentLanguage;
        initTranslations();
    }

    void initTranslations();

    int m_currentLanguage;
    QMap<int, QMap<QString, QString>> m_dict;

    // 禁止拷贝
    Translator(const Translator&) = delete;
    Translator& operator=(const Translator&) = delete;
};

// 全局访问宏
#define TR Translator::instance()

#endif // TRANSLATOR_H
