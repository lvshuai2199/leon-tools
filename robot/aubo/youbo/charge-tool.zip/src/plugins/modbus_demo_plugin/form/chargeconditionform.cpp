#include "chargeconditionform.h"
#include "ui_chargeconditionform.h"
#include "common.h"
#include <QTimer>
#include <QDebug>
#include <QJsonObject>
#include <QJsonDocument>
#include "extensionsystem/iplugin.h"
#include "extensionsystem/pluginmanager.h"

static chargeconditionform *s_instance = 0;
chargeconditionform *chargeconditionform::instance()
{
    return s_instance;
}

chargeconditionform::chargeconditionform(QWidget *parent) :
    // 关键点：显式调用基类构造函数，传入设计时的原始分辨率（比如 800, 600）
    AbstractWidget(parent, 600, 642),
    ui(AbstractWidget::ui)
{
    // 调用基类的 setupUi
    // 内部会执行：ui->setupUi(this) 和 initAllComponents()
    setupUi(this);
    s_instance = this;
    getLogger().log("新建并进入插件节点");
    ui->input_text->setWhatsThis(
                QString::number(KeyboardType_DigitalKeyboard));
}

chargeconditionform::~chargeconditionform()
{
    delete ui;
}



void chargeconditionform::updateCondForm(
        AbsCondInfo *absCondInfo)
{
    // 写入日志
    QString logMsg = QString("界面刷新，节点点击");
    getLogger().log(logMsg);
}
