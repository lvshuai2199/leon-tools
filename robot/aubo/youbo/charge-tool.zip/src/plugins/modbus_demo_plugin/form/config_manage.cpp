#include "config_manage.h"
#include <QSettings>
#include <QTextCodec>

#include <iostream>
#include <chrono>
#include <iomanip>

#include "qfile.h"

config_manage::config_manage()
{
    setupSettings();
    std::srand(std::time(0));
}

// 在程序初始化或配置阶段设置默认编码
void config_manage::setupSettings()
{
    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QSettings settings(CONFIG_PATH, QSettings::IniFormat);
    settings.setIniCodec(codec);
}


int config_manage::configFileSave()
{
    // 创建一个 QSettings 对象来管理配置信息
    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QSettings settings(CONFIG_PATH, QSettings::IniFormat);
    settings.setIniCodec(codec);

    // 设置一个字符串值到配置项 "key"
    QString slave_ip = "127.0.0.1";
    settings.setValue("SLAVEIP", slave_ip);

    // 定义一个列表或一维数组
    QStringList myList;
    myList << "/root/Documents/fileShow/中文库.txt" << "/root/Documents/fileShow/参数及报警说明.txt" << "/root/Documents/fileShow/参数及报警说明 (copy).txt";

    // 将列表转换为字符串，并使用逗号分隔
    QString myListStr = myList.join(",");

    // 存储字符串到配置项
    settings.setValue("FileList", myListStr);

    return 0;
}

int config_manage::updateConfig(int dataType, QString data){

    // 创建一个 QSettings 对象来管理配置信息
    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QSettings settings(CONFIG_PATH, QSettings::IniFormat);
    settings.setIniCodec(codec);

    switch (dataType) {
    case 1:
        settings.setValue("SLAVEIP", data);
        break;
    case 2:
        settings.setValue("FileList", data);
        break;
    case 3:
        settings.setValue("ROOTDIR", data);
        break;
    case 4:
        settings.setValue("DbSysFileName", data);
        break;
    case 5:
        settings.setValue("CURRENTPRODUCT", data);
        break;
    case 8:
        settings.setValue("LANGUAGE", data);
        break;
    case 9:
        settings.setValue("LOCKMODADDR", data);
        break;
    default:
        break;
    }

    return 0;
}

QString config_manage::configFileLoad(int getDataType)
{
    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QSettings settings(CONFIG_PATH, QSettings::IniFormat);
    settings.setIniCodec(codec);

    QString resultStr;

    switch (getDataType) {
        case 1:
            // 从配置中读取存储的字符串值 SLAVEIP
            resultStr = settings.value("SLAVEIP").toString();
            break;
        case 2:
            // 从配置中读取存储的字符串值 FileList
            resultStr = settings.value("FileList").toString();
            break;
        case 3:
            // 从配置中读取 ROOTDIR 和 DbFileName 的组合值
            resultStr = settings.value("ROOTDIR").toString() + settings.value("DbFileName").toString();
            break;
        case 4:
            // 从配置中读取存储的字符串值 DbSysFileName
            resultStr = settings.value("DbSysFileName").toString();
            break;
        case 5:
            // 从配置中读取存储的字符串值 CURRENTPRODUCT
            resultStr = settings.value("CURRENTPRODUCT").toString();
            break;

        case 6:
            // 从配置中读取存储的字符串值 FileROOTDIR
            resultStr = settings.value("FileROOTDIR").toString();
            break;
        case 7:
            // 从配置中读取存储的字符串值 LOCKMODADDR
            resultStr = settings.value("LOCKMODADDR").toString();
            break;
        case 8:
            // 从配置中读取存储的字符串值 LANGUAGE
            resultStr = settings.value("LANGUAGE").toString();
            if(resultStr.isEmpty())resultStr == "0";
            break;


        default:
            // 如果 getDataType 不在预期范围内，返回空字符串或其他适当的默认值
            resultStr = "";
            break;
    }

    return resultStr;
}

void config_manage::updatePassKeys(QString PassKey, QString LockWords) {
    QString wordPass = "/root/.config/aubope/passWords.conf";
    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QSettings settings(wordPass, QSettings::IniFormat);
    settings.setIniCodec(codec);

    settings.setValue("LockWords", LockWords);
    settings.setValue("PassKey", PassKey);

    // 获取当前系统时间
    std::time_t now_time_t = std::time(nullptr);
    std::tm* local_time = std::localtime(&now_time_t);

    // 手动格式化日期
    char buffer[80];
    if (std::strftime(buffer, sizeof(buffer), "%Y-%m-%d", local_time)) {
        // 将 char 数组转换为 QString
        QString dateStr = QString::fromUtf8(buffer);

        // 输出日期
        std::cout << "Current date: " << dateStr.toStdString() << std::endl;
        settings.setValue("updateTime", dateStr);
    } else {
        // 处理错误情况
        std::cerr << "Error formatting date." << std::endl;
    }
}



QStringList config_manage::getPassKeys() {
    /**
     * @brief wordPass
     * 密码为:
     * 1. 原密码字符串
     * 2. 存储记录的密码
     * 3. 修改记录的时间
     */
    QString wordPass = "/root/.config/aubope/passWords.conf";

    // 检查文件是否存在
    QFile file(wordPass);
    if (!file.exists()) {
        // 如果文件不存在，返回空的 QStringList 或者抛出异常，这里选择返回空的 QStringList
        return QStringList();
    }

    QTextCodec *codec = QTextCodec::codecForName("UTF-8");
    QSettings settings(wordPass, QSettings::IniFormat);
    settings.setIniCodec(codec);

    QStringList passKeys;

    // 获取密码和更新时间
    QString lockWords = settings.value("LockWords").toString();
    QString passKey = settings.value("PassKey").toString();
    QString updateTime = settings.value("updateTime").toString();

    passKeys << lockWords << passKey << updateTime;

    return passKeys;
}
