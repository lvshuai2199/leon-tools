#include "config_manege.h"

#define CONFIG_PATH "/root/Desktop/myconfig.ini"

config_manege::config_manege()
{

}
