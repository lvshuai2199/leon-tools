include(../../teachpendantplugin.pri)
QT += core gui widgets sql serialport
QMAKE_CXXFLAGS_WARN_ON += -Wno-reorder


include(common/common.pri)
include(form/form.pri)
include(modbus/modbus.pri)

include(sdk/sdk.pri)

#include(dependents/QXlsx/QXlsx.pri)


HEADERS += modbus_demo_plugin.h

SOURCES += modbus_demo_plugin.cpp

INCLUDEPATH += $$processPath($$HEADERS, $$INCLUDEPATH)
DEPENDPATH += $$processPath($$HEADERS, $$DEPENDPATH)
#DESTDIR = /root/Aubo/TeachPendant/build-teachpendant/lib/teachpendant/plugins/Template


CONFIG += c++11

    #32bit OS
    contains(QT_ARCH, i386){

        CONFIG += c++11

        DEFINES += _GLIBCXX_USE_CXX11_ABI=0

        INCLUDEPATH += $$PWD/dependents/inc/aubo_sdk32

        LIBS += -L$$PWD/dependents/lib/x32 -laubo_sdk

        LIBS += -L$$PWD/dependents/lib/x32 -laral

        LIBS += -lpthread
    }
    #64bit OS
    contains(QT_ARCH, x86_64){

        CONFIG += c++11

        INCLUDEPATH += $$PWD/dependents/inc/aubo_sdk64

        LIBS += -L$$PWD/dependents/lib/x64 -laubo_sdk

        LIBS += -L$$PWD/dependents/lib/x64 -laral

        LIBS += -lpthread
    }
