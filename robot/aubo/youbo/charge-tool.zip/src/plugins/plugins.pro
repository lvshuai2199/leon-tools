include(../../teachpendant.pri)

TEMPLATE  = subdirs

SUBDIRS   = \
    modbus_demo_plugin\
