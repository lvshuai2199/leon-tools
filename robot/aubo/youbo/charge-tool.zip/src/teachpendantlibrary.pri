include($$replace(_PRO_FILE_PWD_, ([^/]+$), \\1/\\1_dependencies.pri))
TARGET = $$TP_LIB_NAME

include(../teachpendant.pri)

DESTDIR = $$TP_LIBRARY_PATH

TARGET = $$_qtLibraryTargetName($$TARGET)

TEMPLATE = lib
CONFIG += shared dll
