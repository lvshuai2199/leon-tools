#include "mainwidget.h"
#include "ui_mainwidget.h"
#include <QDir>
#include <QDebug>
#include "extensionsystem/pluginmanager.h"
#include "extensionsystem/pluginspec.h"
#include <QLayout>
#include <QSignalMapper>
#include "toolbox.h"
#include <QRadioButton>

using namespace ExtensionSystem;

static MainWidget *s_instance = 0;
MainWidget *MainWidget::instance()
{
    return s_instance;
}

MainWidget::MainWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MainWidget)
{
    ui->setupUi(this);

    s_instance = this;

    new PluginManager;
    PluginManager::setPluginIID(
                QLatin1String("com.qt-project.AUBO.TeachPendantPlugin"));
    PluginManager::setPluginMessageBoxParentWidget(this);
    PluginManager::setPluginParentWidget(this);
    PluginManager::setPluginPaths(
                QStringList()
                << QDir::cleanPath(QApplication::applicationDirPath()
                                   + '/' + RELATIVE_PLUGIN_PATH));
    PluginManager::loadPlugins();

    setFixedSize(1024, 642);

//    this->setWindowFlags(Qt::FramelessWindowHint);
//    this->setGeometry(0, 0, this->width(), this->height());

    m_toolBox = new ToolBox(this);
    m_toolBox->setFixedWidth(122);
    ui->mainLayout->insertWidget(0, m_toolBox);

    QSignalMapper *signalMapper = new QSignalMapper(this);

    const QMap<QString, QList<PluginSpec *>> pluginCategories
            = PluginManager::pluginCategories();
    for (auto it = pluginCategories.cbegin();
         it != pluginCategories.cend(); ++it)
    {
        if ("Extensions" == it.key().section('/', 0, 0))
        {
            QWidget *page = new QWidget();
            QVBoxLayout *vLayout = new QVBoxLayout(page);
            vLayout->setContentsMargins(6, 0, 6, 0);

            m_mapDrawerAndPlugin[m_toolBox->count()]
                    = ui->stackedWidget->count();

            bool firstPlugin = true;
            foreach (PluginSpec *spec, it.value())
            {
                QRadioButton *pbnPlugin = new QRadioButton(page);
                pbnPlugin->setFixedSize(QSize(110, 35));
                pbnPlugin->setChecked(firstPlugin);
                firstPlugin = false;
                vLayout->addWidget(pbnPlugin);

                connect(pbnPlugin, SIGNAL(clicked()),
                        signalMapper, SLOT(map()));
                signalMapper->setMapping(
                            pbnPlugin,
                            QString("%1,%2")
                            .arg(m_toolBox->count())
                            .arg(ui->stackedWidget->count()));

                pbnPlugin->setText(spec->name());
                ui->stackedWidget->addWidget(spec->widget());
            }

            QSpacerItem *vSpacer
                    = new QSpacerItem(20, 40, QSizePolicy::Minimum,
                                      QSizePolicy::Expanding);
            vLayout->addItem(vSpacer);

            m_toolBox->addItem(page, it.key().section('/', 1, 1));
        }
    }

    connect(signalMapper, SIGNAL(mapped(QString)),
            this, SLOT(slot_pbnPluginPressed(QString)));

    ui->stackedWidget->setCurrentIndex(0);

    m_toolBox->init();
    connect(m_toolBox, SIGNAL(signal_itemClicked(int)),
            this, SLOT(slot_toolBox_itemClicked(int)));

    connect(this, SIGNAL(signal_sendTraceInfo(int,QString)),
            this, SLOT(slot_recvTraceInfo(int,QString)));

    //test
#if 0
    if (TemplatePlugin *templatePlugin
            = PluginManager::getObject<TemplatePlugin>())
    {
        QString ret;
        templatePlugin->pluginCommonInterface("add|1.1,2.2", ret);
        qDebug() << "ret1 : " << ret;
    }

    if (TemplatePlugin2 *templatePlugin2
            = static_cast<TemplatePlugin2 *>(
                PluginManager::getObjectByName("Template2")))
    {
        QString ret;
        templatePlugin2->pluginCommonInterface("sub|3.1,2.1", ret);
        qDebug() << "ret2 : " << ret;
    }

    if (TemplatePlugin3 *templatePlugin3
            = static_cast<TemplatePlugin3 *>(
                PluginManager::getObjectByClassName("TemplatePlugin3")))
    {
        QString ret;
        templatePlugin3->pluginCommonInterface("mul|1.1,1.1", ret);
        qDebug() << "ret3 : " << ret;
    }

    QList<QObject *> all = PluginManager::allObjects();
    foreach (QObject *obj, all) {
        if (IPlugin *result = static_cast<IPlugin *>(obj))
        {
            QString ret;
            result->pluginCommonInterface("div|3.3,1.1", ret);
            qDebug() << "ret4 : " << ret;
        }
    }
#endif
}

MainWidget::~MainWidget()
{
    delete ui;
}

void MainWidget::slot_recvTraceInfo(int level, QString info)
{
    qDebug() << "level : " << level << "info : " << info;
}

void MainWidget::slot_toolBox_itemClicked(int index)
{
    ui->stackedWidget->setCurrentIndex(m_mapDrawerAndPlugin[index]);
    m_toolBox->setCurrentIndex(index);
}

void MainWidget::slot_pbnPluginPressed(QString content)
{
    ui->stackedWidget->setCurrentIndex(content.section(',', 1, 1).toInt());
    m_mapDrawerAndPlugin[content.section(',', 0, 0).toInt()]
            = content.section(',', 1, 1).toInt();
}
