#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QMap>

class ToolBox;

namespace Ui {
class MainWidget;
}

class MainWidget : public QWidget
{
    Q_OBJECT

public:
    static MainWidget *instance();

    explicit MainWidget(QWidget *parent = 0);
    ~MainWidget();

signals:
    void signal_sendTraceInfo(int level, QString info);
    void signal_sendMessageBoxInfo(int messageType, QString hint, int buttonRole1, int buttonRole2, int buttonRole3);

private slots:
    void slot_recvTraceInfo(int level, QString info);

    void slot_toolBox_itemClicked(int index);

    void slot_pbnPluginPressed(QString content);

private:
    Ui::MainWidget *ui;

    QMap<int, int> m_mapDrawerAndPlugin;

    ToolBox *m_toolBox;
};

#endif // MAINWIDGET_H
