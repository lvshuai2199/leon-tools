#ifndef TOOLBOX_H
#define TOOLBOX_H

#include <QToolBox>

class ToolBox : public QToolBox
{
    Q_OBJECT

public:
    explicit ToolBox(QWidget *parent = 0);

    void init();

signals:
    void signal_itemClicked(int index);
};

#endif // TOOLBOX_H
