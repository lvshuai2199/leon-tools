#include "mainwidget.h"
#include <QApplication>
#include <QDir>

void createWorkDir(QDir curDir, const QString &dirName)
{
    if (!curDir.cd(dirName))
        curDir.mkdir(dirName);
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QDir::setCurrent(QCoreApplication::applicationDirPath());

    createWorkDir(QDir(QString("%1/../")
                       .arg(QApplication::applicationDirPath())),
                  "share");
    createWorkDir(QDir(QString("%1/../share")
                       .arg(QApplication::applicationDirPath())),
                  TP_ID);
    createWorkDir(QDir(QString("%1/../share/%2")
                       .arg(QApplication::applicationDirPath())
                       .arg(TP_ID)),
                  "plugins");

    MainWidget w;
    w.show();

    return a.exec();
}
