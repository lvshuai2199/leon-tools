#----------------------------------------------------------------------------
#
# Project created by QtCreator 2016-06-30T14:57:34
# Copyright (C) 2015-2018 Aubo(Beijing) Intelligent Technology Co., Ltd.
# Contact : http://www.aubo-robotics.com/
# Author  : Yifei Pan
# Version : V4.x.x
#
#----------------------------------------------------------------------------

!isEmpty(APP_PRI_INCLUDED) \
:error("app.pri already included")
APP_PRI_INCLUDED = 1

include(../../teachpendant.pri)

QT += core gui widgets sql network serialport opengl

TEMPLATE = app

QMAKE_CXXFLAGS_WARN_ON += \
    -Wno-reorder \
    -Wno-unused-result \
    -Wno-unused-but-set-variable \
    -Wno-array-bounds \
    -Wno-sign-compare \
    -Wno-empty-body

TARGET = MainProgram
DESTDIR += $$TP_APP_PATH

SOURCES += main.cpp\
        mainwidget.cpp \
    toolbox.cpp

HEADERS  += mainwidget.h \
    toolbox.h

FORMS    += mainwidget.ui \

INCLUDEPATH += $$processPath($$HEADERS, $$INCLUDEPATH)
DEPENDPATH += $$processPath($$HEADERS, $$DEPENDPATH)

unix{
    contains(QT_ARCH, i386){
        LIBS *= -L$$TP_SOURCE_TREE/lib/teachpendant/linux_x32 \
            -l$$qtLibraryName(ExtensionSystem) -l$$qtLibraryName(Stl)
    }
    contains(QT_ARCH, x86_64){
        LIBS *= -L$$TP_SOURCE_TREE/lib/teachpendant/linux_x64 \
            -l$$qtLibraryName(ExtensionSystem) -l$$qtLibraryName(Stl)
    }
}
