#include "toolbox.h"
#include <QAbstractButton>
#include <QSignalMapper>

ToolBox::ToolBox(QWidget *parent) :
    QToolBox(parent)
{
}

void ToolBox::init()
{
    QSignalMapper *signalMapper = new QSignalMapper(this);
    QList<QAbstractButton *> btnList
            = findChildren<QAbstractButton *>("qt_toolbox_toolboxbutton");

    for (int i = 0; i < btnList.size(); i++)
    {
        connect(btnList.at(i), SIGNAL(clicked()),
                signalMapper, SLOT(map()));
        signalMapper->setMapping(btnList.at(i), i);
    }

    connect(signalMapper, SIGNAL(mapped(int)),
            this, SIGNAL(signal_itemClicked(int)));
}
