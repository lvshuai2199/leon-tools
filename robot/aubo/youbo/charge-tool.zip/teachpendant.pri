!isEmpty(PLUGINMANAGER_PRI_INCLUDED)\
:error("pluginmanager.pri already included")
PLUGINMANAGER_PRI_INCLUDED = 1

TP_VERSION = 4.2.6
TP_COMPAT_VERSION = 4.2.6

isEmpty(TP_DISPLAY_NAME):           TP_DISPLAY_NAME = AUBOPE
isEmpty(TP_ID):                     TP_ID = teachpendant
isEmpty(TP_CASED_ID):               TP_CASED_ID = TeachPendant

DEFINES += $$shell_quote(TP_DISPLAY_NAME=\"$$TP_DISPLAY_NAME\")
DEFINES += $$shell_quote(TP_ID=\"$$TP_ID\")
DEFINES += $$shell_quote(TP_CASED_ID=\"$$TP_CASED_ID\")

CONFIG += c++11

defineReplace(qtLibraryTargetName) {
   unset(LIBRARY_NAME)
   LIBRARY_NAME = $$1
   CONFIG(debug, debug|release) {
      !debug_and_release|build_pass {
          mac:RET = $$member(LIBRARY_NAME, 0)_debug
              else:win32:RET = $$member(LIBRARY_NAME, 0)d
      }
   }
   isEmpty(RET):RET = $$LIBRARY_NAME
   return($$RET)
}

defineReplace(qtLibraryName) {
   RET = $$qtLibraryTargetName($$1)
   win32 {
      VERSION_LIST = $$split(TP_VERSION, .)
      RET = $$RET$$first(VERSION_LIST)
   }
   return($$RET)
}

defineTest(minQtVersion) {
    maj = $$1
    min = $$2
    patch = $$3
    isEqual(QT_MAJOR_VERSION, $$maj) {
        isEqual(QT_MINOR_VERSION, $$min) {
            isEqual(QT_PATCH_VERSION, $$patch) {
                return(true)
            }
            greaterThan(QT_PATCH_VERSION, $$patch) {
                return(true)
            }
        }
        greaterThan(QT_MINOR_VERSION, $$min) {
            return(true)
        }
    }
    greaterThan(QT_MAJOR_VERSION, $$maj) {
        return(true)
    }
    return(false)
}

defineReplace(processPath) {
    unset(headers)
    unset(includePath)

    headers = $$1
    includePath = $$2

    headerList = $$split(headers, " ")
    headerDirList = ""
    for(headerDir, headerList) {
        dirName = $$dirname(headerDir)
        !isEmpty(dirName) : headerDirList += $$dirName
    }

    unset(ret)
    headerDirSet = $$unique(headerDirList)
    for(headerDir, headerDirSet) {
        !contains(includePath, $$headerDir) : ret += $$headerDir
    }

    return($$ret)
}

isEmpty(TP_LIBRARY_BASENAME) {
    TP_LIBRARY_BASENAME = lib
}

TP_SOURCE_TREE = $$PWD
isEmpty(TP_BUILD_TREE) {
    sub_dir = $$_PRO_FILE_PWD_
    sub_dir ~= s,^$$re_escape($$PWD),,
    TP_BUILD_TREE = $$clean_path($$OUT_PWD)
    TP_BUILD_TREE ~= s,$$re_escape($$sub_dir)$,,
}

TP_APP_PATH = $$TP_BUILD_TREE/bin

isEmpty(TP_OUTPUT_PATH): TP_OUTPUT_PATH = $$TP_BUILD_TREE

TP_LIBRARY_PATH = $$TP_OUTPUT_PATH/$$TP_LIBRARY_BASENAME/$$TP_ID
TP_PLUGIN_PATH  = $$TP_LIBRARY_PATH/plugins
TP_BIN_PATH     = $$TP_OUTPUT_PATH/bin
LINK_LIBRARY_PATH = $$TP_BUILD_TREE/$$TP_LIBRARY_BASENAME/$$TP_ID
LINK_PLUGIN_PATH  = $$LINK_LIBRARY_PATH/plugins

RELATIVE_PLUGIN_PATH = $$relative_path($$TP_PLUGIN_PATH, $$TP_BIN_PATH)
DEFINES += $$shell_quote(RELATIVE_PLUGIN_PATH=\"$$RELATIVE_PLUGIN_PATH\")

INCLUDEPATH += \
    $$TP_BUILD_TREE/src \ # for <app/app_version.h> in case of actual build directory
    $$TP_SOURCE_TREE/src \ # for <app/app_version.h> in case of binary package with dev package
    $$TP_SOURCE_TREE/src/libs \

TP_PLUGIN_DIRS += $$TP_SOURCE_TREE/src/plugins
for(dir, TP_PLUGIN_DIRS) {
    INCLUDEPATH += $$dir
}

CONFIG += \
    depend_includepath \
    no_include_pwd

LIBS *= -L$$LINK_LIBRARY_PATH  # Qt Creator libraries
exists($$TP_LIBRARY_PATH): LIBS *= -L$$TP_LIBRARY_PATH  # library path from output path

unix {
    CONFIG(debug, debug|release):OBJECTS_DIR = $${OUT_PWD}/.obj/debug-shared
    CONFIG(release, debug|release):OBJECTS_DIR = $${OUT_PWD}/.obj/release-shared

    CONFIG(debug, debug|release):MOC_DIR = $${OUT_PWD}/.moc/debug-shared
    CONFIG(release, debug|release):MOC_DIR = $${OUT_PWD}/.moc/release-shared

    RCC_DIR = $${OUT_PWD}/.rcc
    UI_DIR = $${OUT_PWD}/.uic
}

!isEmpty(TP_PLUGIN_DEPENDS) {
    LIBS *= -L$$TP_PLUGIN_PATH  # plugin path from output directory
    LIBS *= -L$$LINK_PLUGIN_PATH  # when output path is different from Qt Creator build directory
}

# recursively resolve plugin deps
done_plugins =
for(ever) {
    isEmpty(TP_PLUGIN_DEPENDS): \
        break()
    done_plugins += $$TP_PLUGIN_DEPENDS
    for(dep, TP_PLUGIN_DEPENDS) {
        dependencies_file =
        for(dir, TP_PLUGIN_DIRS) {
            exists($$dir/$$dep/$${dep}_dependencies.pri) {
                dependencies_file = $$dir/$$dep/$${dep}_dependencies.pri
                break()
            }
        }
        isEmpty(dependencies_file): \
            error("Plugin dependency $$dep not found")
        include($$dependencies_file)
        LIBS += -l$$qtLibraryName($$TP_PLUGIN_NAME)
    }
    TP_PLUGIN_DEPENDS = $$unique(TP_PLUGIN_DEPENDS)
    TP_PLUGIN_DEPENDS -= $$unique(done_plugins)
}

# recursively resolve library deps
done_libs =
for(ever) {
    isEmpty(TP_LIB_DEPENDS): \
        break()
    done_libs += $$TP_LIB_DEPENDS
    for(dep, TP_LIB_DEPENDS) {
        include($$PWD/src/libs/$$dep/$${dep}_dependencies.pri)
        unix{
            contains(QT_ARCH, i386){
                LIBS *= -L$$TP_SOURCE_TREE/lib/teachpendant/linux_x32 \
                    -l$$qtLibraryName($$TP_LIB_NAME)
            }
            contains(QT_ARCH, x86_64){
                LIBS *= -L$$TP_SOURCE_TREE/lib/teachpendant/linux_x64 \
                    -l$$qtLibraryName($$TP_LIB_NAME)
            }
        }
    }
    TP_LIB_DEPENDS = $$unique(TP_LIB_DEPENDS)
    TP_LIB_DEPENDS -= $$unique(done_libs)
}
