#!/bin/bash

# 相对路径的源文件和目标路径
source_file="libModbusDemo.so"
target_directory="/root/AuboRobotWorkSpace/teachpendant/lib/teachpendant/plugins/"

db_file="test.db"
db_target_directory="/root/AuboRobotWorkSpace/teachpendant/bin/"

# 检查源文件是否存在
if [ ! -f "$source_file" ]; then
    echo "Source file $source_file does not exist."
    exit 1
fi

if [ ! -f "$db_file" ]; then
    echo "DB file $db_file does not exist."
    exit 1
fi

# 检查目标目录是否存在
if [ ! -d "$target_directory" ]; then
    echo "Target directory $target_directory does not exist."
    exit 1
fi

if [ ! -d "$db_target_directory" ]; then
    echo "DB target directory $db_target_directory does not exist."
    exit 1
fi

# 复制并替换文件
# 替换 libModbusDemo.so
if [ -f "$target_directory/$(basename $source_file)" ]; then
    echo "Replacing existing file $target_directory/$(basename $source_file)"
    rm -f "$target_directory/$(basename $source_file)"
fi
cp "$source_file" "$target_directory"
if [ $? -ne 0 ]; then
    echo "Failed to copy $source_file to $target_directory."
    exit 1
fi

# 替换 test.db
if [ -f "$db_target_directory/$(basename $db_file)" ]; then
    echo "Replacing existing file $db_target_directory/$(basename $db_file)"
    rm -f "$db_target_directory/$(basename $db_file)"
fi
cp "$db_file" "$db_target_directory"
if [ $? -ne 0 ]; then
    echo "Failed to copy $db_file to $db_target_directory."
    exit 1
fi

echo "Files copied and replaced successfully."

# 终止 auboControllerServer 进程
echo "Terminating auboControllerServer..."
killall auboControllerServer
