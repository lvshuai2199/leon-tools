/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../chargeTool_uber/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[22];
    char stringdata0[455];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 10), // "updateTime"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 21), // "on_reboot_btn_clicked"
QT_MOC_LITERAL(4, 45, 25), // "on_export2tar_btn_clicked"
QT_MOC_LITERAL(5, 71, 13), // "onCopyStarted"
QT_MOC_LITERAL(6, 85, 14), // "onCopyFinished"
QT_MOC_LITERAL(7, 100, 7), // "success"
QT_MOC_LITERAL(8, 108, 7), // "message"
QT_MOC_LITERAL(9, 116, 31), // "on_export_pluginlog_btn_clicked"
QT_MOC_LITERAL(10, 148, 30), // "on_clear_pluginlog_btn_clicked"
QT_MOC_LITERAL(11, 179, 27), // "on_set_robot_ip_btn_clicked"
QT_MOC_LITERAL(12, 207, 35), // "on_import_charge_config_btn_c..."
QT_MOC_LITERAL(13, 243, 25), // "on_export_all_btn_clicked"
QT_MOC_LITERAL(14, 269, 25), // "on_select_tar_btn_clicked"
QT_MOC_LITERAL(15, 295, 23), // "onItemCheckStateChanged"
QT_MOC_LITERAL(16, 319, 14), // "QStandardItem*"
QT_MOC_LITERAL(17, 334, 4), // "item"
QT_MOC_LITERAL(18, 339, 21), // "updateSelectionStatus"
QT_MOC_LITERAL(19, 361, 29), // "on_tar_and_export_btn_clicked"
QT_MOC_LITERAL(20, 391, 30), // "on_export_robotlog_btn_clicked"
QT_MOC_LITERAL(21, 422, 32) // "on_restartController_btn_clicked"

    },
    "MainWindow\0updateTime\0\0on_reboot_btn_clicked\0"
    "on_export2tar_btn_clicked\0onCopyStarted\0"
    "onCopyFinished\0success\0message\0"
    "on_export_pluginlog_btn_clicked\0"
    "on_clear_pluginlog_btn_clicked\0"
    "on_set_robot_ip_btn_clicked\0"
    "on_import_charge_config_btn_clicked\0"
    "on_export_all_btn_clicked\0"
    "on_select_tar_btn_clicked\0"
    "onItemCheckStateChanged\0QStandardItem*\0"
    "item\0updateSelectionStatus\0"
    "on_tar_and_export_btn_clicked\0"
    "on_export_robotlog_btn_clicked\0"
    "on_restartController_btn_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   94,    2, 0x08 /* Private */,
       3,    0,   95,    2, 0x08 /* Private */,
       4,    0,   96,    2, 0x08 /* Private */,
       5,    0,   97,    2, 0x08 /* Private */,
       6,    2,   98,    2, 0x08 /* Private */,
       9,    0,  103,    2, 0x08 /* Private */,
      10,    0,  104,    2, 0x08 /* Private */,
      11,    0,  105,    2, 0x08 /* Private */,
      12,    0,  106,    2, 0x08 /* Private */,
      13,    0,  107,    2, 0x08 /* Private */,
      14,    0,  108,    2, 0x08 /* Private */,
      15,    1,  109,    2, 0x08 /* Private */,
      18,    0,  112,    2, 0x08 /* Private */,
      19,    0,  113,    2, 0x08 /* Private */,
      20,    0,  114,    2, 0x08 /* Private */,
      21,    0,  115,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, QMetaType::QString,    7,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->updateTime(); break;
        case 1: _t->on_reboot_btn_clicked(); break;
        case 2: _t->on_export2tar_btn_clicked(); break;
        case 3: _t->onCopyStarted(); break;
        case 4: _t->onCopyFinished((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 5: _t->on_export_pluginlog_btn_clicked(); break;
        case 6: _t->on_clear_pluginlog_btn_clicked(); break;
        case 7: _t->on_set_robot_ip_btn_clicked(); break;
        case 8: _t->on_import_charge_config_btn_clicked(); break;
        case 9: _t->on_export_all_btn_clicked(); break;
        case 10: _t->on_select_tar_btn_clicked(); break;
        case 11: _t->onItemCheckStateChanged((*reinterpret_cast< QStandardItem*(*)>(_a[1]))); break;
        case 12: _t->updateSelectionStatus(); break;
        case 13: _t->on_tar_and_export_btn_clicked(); break;
        case 14: _t->on_export_robotlog_btn_clicked(); break;
        case 15: _t->on_restartController_btn_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
