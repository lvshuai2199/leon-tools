/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QListView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout_3;
    QFrame *frame;
    QVBoxLayout *verticalLayout_4;
    QVBoxLayout *verticalLayout_3;
    QLabel *label_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label;
    QLabel *cur_tarname_label;
    QListView *tarcontent_list;
    QCheckBox *is_plugin_import_checkbox;
    QHBoxLayout *horizontalLayout;
    QPushButton *select_tar_btn;
    QPushButton *import_charge_config_btn;
    QFrame *frame_2;
    QVBoxLayout *verticalLayout_5;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QLineEdit *export_dirname_edit;
    QPushButton *export2tar_btn;
    QPushButton *export_robotlog_btn;
    QPushButton *export_pluginlog_btn;
    QSpacerItem *verticalSpacer;
    QPushButton *export_all_btn;
    QPushButton *tar_and_export_btn;
    QFrame *frame_3;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_4;
    QSpacerItem *verticalSpacer_2;
    QPushButton *clear_pluginlog_btn;
    QPushButton *reboot_btn;
    QPushButton *set_robot_ip_btn;
    QVBoxLayout *verticalLayout_6;
    QLabel *label_5;
    QPushButton *restartController_btn;
    QStatusBar *statusBar;
    QToolBar *toolBar;
    QToolBar *mainToolBar;
    QMenuBar *menuBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(742, 466);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        horizontalLayout_3 = new QHBoxLayout(centralWidget);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        frame = new QFrame(centralWidget);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        verticalLayout_4 = new QVBoxLayout(frame);
        verticalLayout_4->setSpacing(6);
        verticalLayout_4->setContentsMargins(11, 11, 11, 11);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        verticalLayout_3 = new QVBoxLayout();
        verticalLayout_3->setSpacing(6);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        label_2 = new QLabel(frame);
        label_2->setObjectName(QStringLiteral("label_2"));
        QFont font;
        font.setPointSize(13);
        font.setBold(true);
        font.setItalic(false);
        font.setWeight(75);
        label_2->setFont(font);
        label_2->setAlignment(Qt::AlignCenter);

        verticalLayout_3->addWidget(label_2);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        label = new QLabel(frame);
        label->setObjectName(QStringLiteral("label"));

        horizontalLayout_2->addWidget(label);

        cur_tarname_label = new QLabel(frame);
        cur_tarname_label->setObjectName(QStringLiteral("cur_tarname_label"));

        horizontalLayout_2->addWidget(cur_tarname_label);


        verticalLayout_3->addLayout(horizontalLayout_2);

        tarcontent_list = new QListView(frame);
        tarcontent_list->setObjectName(QStringLiteral("tarcontent_list"));

        verticalLayout_3->addWidget(tarcontent_list);

        is_plugin_import_checkbox = new QCheckBox(frame);
        is_plugin_import_checkbox->setObjectName(QStringLiteral("is_plugin_import_checkbox"));

        verticalLayout_3->addWidget(is_plugin_import_checkbox);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        select_tar_btn = new QPushButton(frame);
        select_tar_btn->setObjectName(QStringLiteral("select_tar_btn"));

        horizontalLayout->addWidget(select_tar_btn);

        import_charge_config_btn = new QPushButton(frame);
        import_charge_config_btn->setObjectName(QStringLiteral("import_charge_config_btn"));

        horizontalLayout->addWidget(import_charge_config_btn);


        verticalLayout_3->addLayout(horizontalLayout);


        verticalLayout_4->addLayout(verticalLayout_3);


        horizontalLayout_3->addWidget(frame);

        frame_2 = new QFrame(centralWidget);
        frame_2->setObjectName(QStringLiteral("frame_2"));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        verticalLayout_5 = new QVBoxLayout(frame_2);
        verticalLayout_5->setSpacing(6);
        verticalLayout_5->setContentsMargins(11, 11, 11, 11);
        verticalLayout_5->setObjectName(QStringLiteral("verticalLayout_5"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_3 = new QLabel(frame_2);
        label_3->setObjectName(QStringLiteral("label_3"));
        QFont font1;
        font1.setPointSize(13);
        font1.setBold(true);
        font1.setWeight(75);
        label_3->setFont(font1);
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_3);

        export_dirname_edit = new QLineEdit(frame_2);
        export_dirname_edit->setObjectName(QStringLiteral("export_dirname_edit"));

        verticalLayout->addWidget(export_dirname_edit);

        export2tar_btn = new QPushButton(frame_2);
        export2tar_btn->setObjectName(QStringLiteral("export2tar_btn"));

        verticalLayout->addWidget(export2tar_btn);

        export_robotlog_btn = new QPushButton(frame_2);
        export_robotlog_btn->setObjectName(QStringLiteral("export_robotlog_btn"));

        verticalLayout->addWidget(export_robotlog_btn);

        export_pluginlog_btn = new QPushButton(frame_2);
        export_pluginlog_btn->setObjectName(QStringLiteral("export_pluginlog_btn"));

        verticalLayout->addWidget(export_pluginlog_btn);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        export_all_btn = new QPushButton(frame_2);
        export_all_btn->setObjectName(QStringLiteral("export_all_btn"));

        verticalLayout->addWidget(export_all_btn);

        tar_and_export_btn = new QPushButton(frame_2);
        tar_and_export_btn->setObjectName(QStringLiteral("tar_and_export_btn"));

        verticalLayout->addWidget(tar_and_export_btn);


        verticalLayout_5->addLayout(verticalLayout);


        horizontalLayout_3->addWidget(frame_2);

        frame_3 = new QFrame(centralWidget);
        frame_3->setObjectName(QStringLiteral("frame_3"));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        verticalLayout_7 = new QVBoxLayout(frame_3);
        verticalLayout_7->setSpacing(6);
        verticalLayout_7->setContentsMargins(11, 11, 11, 11);
        verticalLayout_7->setObjectName(QStringLiteral("verticalLayout_7"));
        label_4 = new QLabel(frame_3);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setFont(font1);
        label_4->setAlignment(Qt::AlignCenter);

        verticalLayout_7->addWidget(label_4);

        verticalSpacer_2 = new QSpacerItem(20, 162, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_2);

        clear_pluginlog_btn = new QPushButton(frame_3);
        clear_pluginlog_btn->setObjectName(QStringLiteral("clear_pluginlog_btn"));

        verticalLayout_7->addWidget(clear_pluginlog_btn);

        reboot_btn = new QPushButton(frame_3);
        reboot_btn->setObjectName(QStringLiteral("reboot_btn"));

        verticalLayout_7->addWidget(reboot_btn);

        set_robot_ip_btn = new QPushButton(frame_3);
        set_robot_ip_btn->setObjectName(QStringLiteral("set_robot_ip_btn"));

        verticalLayout_7->addWidget(set_robot_ip_btn);

        verticalLayout_6 = new QVBoxLayout();
        verticalLayout_6->setSpacing(6);
        verticalLayout_6->setObjectName(QStringLiteral("verticalLayout_6"));
        label_5 = new QLabel(frame_3);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout_6->addWidget(label_5);

        restartController_btn = new QPushButton(frame_3);
        restartController_btn->setObjectName(QStringLiteral("restartController_btn"));

        verticalLayout_6->addWidget(restartController_btn);


        verticalLayout_7->addLayout(verticalLayout_6);


        horizontalLayout_3->addWidget(frame_3);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        toolBar = new QToolBar(MainWindow);
        toolBar->setObjectName(QStringLiteral("toolBar"));
        MainWindow->addToolBar(Qt::RightToolBarArea, toolBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 742, 28));
        MainWindow->setMenuBar(menuBar);

        mainToolBar->addSeparator();

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        label_2->setText(QApplication::translate("MainWindow", "\346\225\260\346\215\256\345\257\274\345\205\245", 0));
        label->setText(QApplication::translate("MainWindow", "\346\234\272\345\236\213:", 0));
        cur_tarname_label->setText(QApplication::translate("MainWindow", "\350\257\267\345\205\210\351\200\211\346\213\251\345\257\271\345\272\224\346\226\207\344\273\266", 0));
        is_plugin_import_checkbox->setText(QApplication::translate("MainWindow", "\346\230\257\345\220\246\345\257\274\345\205\245\346\217\222\344\273\266\347\233\256\345\275\225", 0));
        select_tar_btn->setText(QApplication::translate("MainWindow", "\351\200\211\346\213\251\345\216\213\347\274\251\345\214\205", 0));
        import_charge_config_btn->setText(QApplication::translate("MainWindow", "\345\257\274\345\205\245\346\234\272\346\242\260\350\207\202", 0));
        label_3->setText(QApplication::translate("MainWindow", "\345\244\207\344\273\275\345\217\212\345\257\274\345\207\272", 0));
        export_dirname_edit->setText(QString());
        export_dirname_edit->setPlaceholderText(QApplication::translate("MainWindow", "\345\257\274\345\207\272\345\211\215\347\274\200", 0));
        export2tar_btn->setText(QApplication::translate("MainWindow", "\345\257\274\345\207\272\345\244\207\344\273\275", 0));
        export_robotlog_btn->setText(QApplication::translate("MainWindow", "\345\257\274\345\207\272\346\234\272\346\242\260\350\207\202\346\227\245\345\277\227", 0));
        export_pluginlog_btn->setText(QApplication::translate("MainWindow", "\345\257\274\345\207\272\346\217\222\344\273\266\346\227\245\345\277\227", 0));
        export_all_btn->setText(QApplication::translate("MainWindow", "\344\270\200\351\224\256\345\244\207\344\273\275", 0));
        tar_and_export_btn->setText(QApplication::translate("MainWindow", "\345\216\213\347\274\251\345\271\266\345\257\274\345\207\272\350\207\263U\347\233\230", 0));
        label_4->setText(QApplication::translate("MainWindow", "\345\205\266\344\273\226\345\212\237\350\203\275", 0));
        clear_pluginlog_btn->setText(QApplication::translate("MainWindow", "\346\270\205\347\220\206\346\217\222\344\273\266\346\227\245\345\277\227", 0));
        reboot_btn->setText(QApplication::translate("MainWindow", "\351\207\215\345\220\257", 0));
        set_robot_ip_btn->setText(QApplication::translate("MainWindow", "\350\256\276\347\275\256\347\275\221\347\273\234", 0));
        label_5->setText(QApplication::translate("MainWindow", "\350\260\203\350\257\225:", 0));
        restartController_btn->setText(QApplication::translate("MainWindow", "restartController", 0));
        toolBar->setWindowTitle(QApplication::translate("MainWindow", "toolBar", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
