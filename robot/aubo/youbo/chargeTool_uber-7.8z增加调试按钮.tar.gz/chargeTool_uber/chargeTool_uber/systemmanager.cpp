// systemmanager.cpp
#include "systemmanager.h"
#include <QDir>
#include <QSysInfo>
#include <QDateTime>

SystemManager::SystemManager(QObject *parent)
    : QObject(parent), copyProcess_(0)
{
}

SystemManager::~SystemManager()
{
    if (copyProcess_) {
        copyProcess_->kill();
        copyProcess_->waitForFinished();
        delete copyProcess_;
    }
}

// 同步方法
bool SystemManager::createDirectory(const QString& path)
{
    return QDir().mkpath(path);
}

bool SystemManager::directoryExists(const QString& path)
{
    return QDir(path).exists();
}

QString SystemManager::getSystemInfo()
{
    return QSysInfo::prettyProductName();
}

// 异步方法
void SystemManager::reboot()
{
    emit rebootStarted();
    QProcess::execute("sudo", QStringList() << "reboot");
}

void SystemManager::restartController()
{
    emit rebootStarted();
    QProcess::execute("killall auboControllerServer");

}

void SystemManager::copyFolder(const QString& source, const QString& dest)
{
    if (copyProcess_) {
        delete copyProcess_;
    }

    copyProcess_ = new QProcess(this);
    connect(copyProcess_,
            SIGNAL(finished(int, QProcess::ExitStatus)),
            this, SLOT(onCopyFinished(int, QProcess::ExitStatus)));

    emit copyStarted();

    // 关键修复：确保目标路径不以斜杠结尾
    QString cleanDest = dest;
    if (cleanDest.endsWith('/')) {
        cleanDest.chop(1);
    }

    // 确保源路径以斜杠结尾（复制文件夹内容，而不是文件夹本身）
    QString cleanSource = source;
    if (!cleanSource.endsWith('/')) {
        cleanSource += '/';
    }

    qDebug() << "复制命令: cp -r" << cleanSource << cleanDest;
    copyProcess_->start("cp", QStringList() << "-r" << cleanSource << cleanDest);
}

void SystemManager::onCopyFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    if (exitStatus == QProcess::NormalExit && exitCode == 0) {
        emit copyFinished(true, "文件夹拷贝完成");
    } else {
        QString error = copyProcess_->readAllStandardError();
        if (error.isEmpty()) {
            error = "拷贝过程异常终止";
        }
        emit copyFinished(false, "拷贝失败: " + error);
    }
}

QString SystemManager::createTimestampFolder(const QString& basePath,const QString& dirName)
{
    // 获取当前日期时间，格式：yyyy-MM-dd_HH-mm-ss
    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd_HH-mm-ss");

    // 组合完整路径
    QString folderPath = basePath + "/" + dirName + timestamp;

    // 创建文件夹
    if (createDirectory(folderPath)) {
        return folderPath;
    }

    return "";  // 创建失败返回空字符串
}

bool SystemManager::setNetworkConfig(const QString& interface, const QString& ip,
                                      const QString& netmask, const QString& gateway)
{
    // 临时生效
    QProcess process;
    process.start("ifconfig", QStringList() << interface << ip << "netmask" << netmask);
    process.waitForFinished(5000);
    if (process.exitCode() != 0) {
        qDebug() << "设置IP失败:" << process.readAllStandardError();
        return false;
    }

    QProcess routeProcess;
    routeProcess.start("route", QStringList() << "del" << "default");
    routeProcess.waitForFinished(3000);
    routeProcess.start("route", QStringList() << "add" << "default" << "gw" << gateway);
    routeProcess.waitForFinished(5000);
    if (routeProcess.exitCode() != 0) {
        qDebug() << "设置网关失败:" << routeProcess.readAllStandardError();
        return false;
    }

    // 持久化写入 /etc/network/interfaces
    QString config = QString(
        "auto lo\n"
        "iface lo inet loopback\n\n"
        "auto %1\n"
        "iface %1 inet static\n"
        "    address %2\n"
        "    netmask %3\n"
        "    gateway %4\n"
    ).arg(interface, ip, netmask, gateway);

    QFile file("/etc/network/interfaces");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "写入配置文件失败:" << file.errorString();
        return false;
    }
    QTextStream out(&file);
    out << config;
    file.close();

    return true;
}

bool SystemManager::removeDirectory(const QString& path)
{
    QDir dir(path);
    if (!dir.exists()) {
        return false;  // 目录不存在
    }

    return dir.removeRecursively();  // 递归删除文件夹及其所有内容
}

QStringList SystemManager::getFirstLevelFiles(const QString& dirPath)
{
    QDir dir(dirPath);
    if (!dir.exists()) return {};

    return dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
}

// 简单压缩函数
bool SystemManager::compressToZip(const QString &sourceFolder, const QString &zipFilePath)
{
    qDebug() << "开始压缩:" << sourceFolder << "->" << zipFilePath;

    // 检查源文件夹
    QDir dir(sourceFolder);
    if (!dir.exists()) {
        qDebug() << "源文件夹不存在:" << sourceFolder;
        return false;
    }

    // 获取文件夹名称和父目录
    QString folderName = QFileInfo(sourceFolder).fileName();
    QString parentDir = QFileInfo(sourceFolder).absolutePath();

    // 使用zip命令压缩
    QProcess process;
    process.setWorkingDirectory(parentDir);

    QStringList args;
    args << "-r" << zipFilePath << folderName;

    qDebug() << "执行命令: zip" << args;

    process.start("zip", args);

    // 等待压缩完成（最多5分钟）
    if (!process.waitForFinished(300000)) {
        qDebug() << "压缩超时";
        process.terminate();
        return false;
    }

    int exitCode = process.exitCode();
    qDebug() << "压缩退出码:" << exitCode;

    // 检查压缩文件是否创建成功
    QFile zipFile(zipFilePath);
    return zipFile.exists();
}

// 简单查找U盘
QString SystemManager::findUSBDrive()
{
    // 检查常见的U盘挂载点
    QStringList possiblePaths;
    possiblePaths << "/media" << "/mnt" << "/run/media";

    for (const QString &basePath : possiblePaths) {
        QDir dir(basePath);
        if (dir.exists()) {
            QStringList entries = dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);
            for (const QString &entry : entries) {
                QString fullPath = basePath + "/" + entry;
                qDebug() << "检查路径:" << fullPath;
                return fullPath;  // 返回第一个找到的
            }
        }
    }

    return QString();  // 没找到
}

QString SystemManager::extractZipToTemp(const QString& zipPath)
{
    qDebug() << "开始解压文件:" << zipPath;

    // 检查ZIP文件是否存在
    if (!QFile::exists(zipPath)) {
        qWarning() << "ZIP文件不存在:" << zipPath;
        return "";
    }

    // 创建临时解压目录
    QString tempDir = "/tmp/uber_import_" +
                     QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss");

    QDir dir(tempDir);
    if (!dir.mkpath(".")) {
        qWarning() << "无法创建临时目录:" << tempDir;
        return "";
    }

    // 解压文件 - 直接解压到tempDir，不创建子目录
    QProcess unzipProcess;
    unzipProcess.setWorkingDirectory(tempDir);  // 设置工作目录

    // 直接在当前目录解压
    unzipProcess.start("unzip", QStringList() << "-o" << zipPath);

    if (!unzipProcess.waitForFinished(30000)) {
        qWarning() << "解压超时";
        return "";
    }

    if (unzipProcess.exitCode() != 0) {
        QString error = unzipProcess.readAllStandardError();
        qWarning() << "解压失败:" << error;
        return "";
    }

    qDebug() << "解压成功到:" << tempDir;

    // 检查解压后的内容
    QStringList entries = dir.entryList(QDir::AllEntries | QDir::NoDotAndDotDot);
    qDebug() << "解压后的内容:" << entries;

    return tempDir;
}


void SystemManager::cleanupTempDir(const QString& tempDir)
{
    if (tempDir.isEmpty()) {
        return;
    }

    // 确保只删除/tmp目录下的文件
    if (tempDir.startsWith("/tmp/")) {
        QProcess cleanupProcess;
        cleanupProcess.start("rm", QStringList() << "-rf" << tempDir);
        cleanupProcess.waitForFinished();
        qDebug() << "清理临时目录:" << tempDir;
    }
}
