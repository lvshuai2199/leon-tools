#-------------------------------------------------
#
# Project created by QtCreator 2026-03-05T08:55:46
#
#-------------------------------------------------

QT       += core gui
CONFIG += c++11

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

VERSION = 1.1.12

TARGET = chargeTool_uber_$$VERSION
TEMPLATE = app


SOURCES += main.cpp\
        mainwindow.cpp \
    systemmanager.cpp

HEADERS  += mainwindow.h \
    systemmanager.h

FORMS    += mainwindow.ui

DEFINES += APP_VERSION="\\\"$$VERSION\\\""



