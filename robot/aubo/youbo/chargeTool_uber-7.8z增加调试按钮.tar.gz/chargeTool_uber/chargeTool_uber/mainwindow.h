// mainwindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QTimer>
#include <QDateTime>
#include "systemmanager.h"

#include <QFileDialog>


#include <QStandardItemModel>
#include <QStandardItem>


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void updateTime();
    void on_reboot_btn_clicked();
    /**
     * @brief on_export2tar_btn_clicked
     * 拷贝对应文件包括:
     * 插件
     * 工程
     * 数据库
     * /root/AuboRobotWorkSpace/teachpendant/share/teachpendant/
     * /root/AuboRobotWorkSpace/teachpendant/share/teachpendant/
     * 配置
     *
     */
    void on_export2tar_btn_clicked();

    // SystemManager 的槽函数
    void onCopyStarted();
    void onCopyFinished(bool success, const QString& message);

    void on_export_pluginlog_btn_clicked();

    void on_clear_pluginlog_btn_clicked();

    void on_set_robot_ip_btn_clicked();

    void on_import_charge_config_btn_clicked();

    void on_export_all_btn_clicked();

    void on_select_tar_btn_clicked();

    void onItemCheckStateChanged(QStandardItem *item);

    void updateSelectionStatus();

    void on_tar_and_export_btn_clicked();

    void on_export_robotlog_btn_clicked();

    void on_restartController_btn_clicked();

private:
    void pageInit();

    // 添加这个函数声明
    QStringList getCheckedFiles() const;

    Ui::MainWindow *ui;
    QLabel *versionLabel;
    QLabel *timeLabel;
    QTimer *timeTimer;
    SystemManager *systemManager_;



    bool robotCopyState = false;
    bool robotCopyError = false;
    // 机械臂程序目录
    QString program_path = "/root/AuboRobotWorkSpace/teachpendant/share/teachpendant";
    // 插件目录
    QString plugin_path = "/root/AuboRobotWorkSpace/teachpendant/lib/teachpendant/plugins";

    //机械臂日志目录
    QStringList robot_log_path = {"/root/AuboRobotWorkSpace/RobotServer/bin/logfiles",
                                  "/root/AuboRobotWorkSpace/teachpendant/bin/logfiles"};
    // 固定的参数位置
    // 插件日志目录
    QString plugin_log_path = "/root/Documents/log";
    // 目标存放位置
    QString target_file_path = "/root/Documents";
//    QString target_file_path = "/tmp/";

    QString import_dir_path = "";
    // 机械臂程序目录
    QString import_program_path = "/root/AuboRobotWorkSpace/teachpendant/share";
    // 插件目录
    QString import_plugin_path = "/root/AuboRobotWorkSpace/teachpendant/lib/teachpendant";

    QString tempExtractDir = "";

    // 添加这些成员变量
    QStandardItemModel *fileListModel;  // 文件列表模型
    QString target_dir_name = "";

    void backup2Dir(const QList<int>& backupFileTypes);

    enum{
        PROGRAMFILE = 0,
        PLUGINFILE,
        PLUGINLOG,
        ROBOTLOG
    };
};

#endif // MAINWINDOW_H
