#include "mainwindow.h"
#include <QApplication>

bool fixPermissions(const QString &programPath)
{
    QFile file(programPath);
    if (!file.exists()) {
        qWarning() << "文件不存在:" << programPath;
        return false;
    }

    // 检查是否有可执行权限
    QFileDevice::Permissions perms = file.permissions();
    if (!(perms & QFileDevice::ExeUser)) {
        qDebug() << "设置可执行权限...";
        return file.setPermissions(perms | QFileDevice::ExeUser |
                                   QFileDevice::ExeGroup | QFileDevice::ExeOther);
    }

    return true;
}


int main(int argc, char *argv[])
{
    // 首先修复自己的权限
    fixPermissions(argv[0]);


    QApplication a(argc, argv);
    MainWindow w;
    w.show();

    return a.exec();
}
