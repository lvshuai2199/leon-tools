// systemmanager.h
#ifndef SYSTEMMANAGER_H
#define SYSTEMMANAGER_H

#include <QObject>
#include <QProcess>
#include <QString>
#include <QDebug>
#include <QThread>
#include <QDirIterator>



class SystemManager : public QObject
{
    Q_OBJECT

public:
    explicit SystemManager(QObject *parent = 0);
    ~SystemManager();

    // 同步方法 - 简单快速的操作
    bool createDirectory(const QString& path);
    bool directoryExists(const QString& path);
    QString getSystemInfo();
    QString createTimestampFolder(const QString& basePath,const QString& dirName);

    // systemmanager.h
    bool setNetworkConfig(const QString& interface, const QString& ip,
                          const QString& netmask, const QString& gateway);


    // 删除文件夹
    bool removeDirectory(const QString& path);

    // 异步方法 - 耗时操作
    void reboot();
    void restartController();
    void copyFolder(const QString& source, const QString& dest);

    QStringList getFirstLevelFiles(const QString &dirPath);

    // 新增简单压缩函数
    bool compressToZip(const QString &sourceFolder, const QString &zipFilePath);
    QString findUSBDrive();

    // 简单解压方法
    QString extractZipToTemp(const QString& zipPath);
    void cleanupTempDir(const QString &tempDir);
signals:
    void copyStarted();
    void copyFinished(bool success, const QString& message);
    void rebootStarted();

private slots:
    void onCopyFinished(int exitCode, QProcess::ExitStatus exitStatus);

private:
    QProcess *copyProcess_;
};

#endif // SYSTEMMANAGER_H
