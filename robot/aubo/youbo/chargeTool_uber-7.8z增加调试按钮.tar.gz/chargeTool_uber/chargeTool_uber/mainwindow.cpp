// mainwindow.cpp
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDateTime>
#include <QLabel>
#include <QTimer>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 创建 SystemManager
    systemManager_ = new SystemManager(this);

    // 连接信号槽
    connect(systemManager_, &SystemManager::copyStarted,
            this, &MainWindow::onCopyStarted);
    connect(systemManager_, &SystemManager::copyFinished,
            this, &MainWindow::onCopyFinished);


    // 初始化fileListModel（但不要填充数据）
    fileListModel = new QStandardItemModel(this);
    ui->tarcontent_list->setModel(fileListModel);

    // 只在这里连接一次
    connect(fileListModel, &QStandardItemModel::itemChanged,
            this, &MainWindow::onItemCheckStateChanged);


    pageInit();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::pageInit()
{
    versionLabel = new QLabel(APP_VERSION, this);
    statusBar()->addPermanentWidget(versionLabel);

    timeLabel = new QLabel(this);
    statusBar()->addPermanentWidget(timeLabel);

    timeTimer = new QTimer(this);
    connect(timeTimer, SIGNAL(timeout()), this, SLOT(updateTime()));
    timeTimer->start(1000);

    timeLabel->setText(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));
    statusBar()->showMessage("就绪");


    ui->export_dirname_edit->setText("uber_");

}

QStringList MainWindow::getCheckedFiles() const
{
    QStringList checkedFiles;

    // 检查模型是否存在
    if (!fileListModel) {
        qDebug() << "fileListModel 不存在";
        return checkedFiles;
    }

    qDebug() << "开始获取勾选的文件，总行数:" << fileListModel->rowCount();

    // 遍历所有行
    for (int i = 0; i < fileListModel->rowCount(); ++i) {
        QStandardItem *item = fileListModel->item(i);
        if (item) {
            bool isChecked = (item->checkState() == Qt::Checked);
            QString fileName = item->text();
            qDebug() << "行" << i << ":" << fileName << "- 勾选状态:" << isChecked;

            if (isChecked) {
                checkedFiles.append(fileName);
            }
        }
    }

    qDebug() << "最终获取到的勾选文件:" << checkedFiles;
    return checkedFiles;
}

void MainWindow::backup2Dir(const QList<int>& backupFileTypes)
{
    // 检查目标目录
    if (systemManager_->directoryExists(target_dir_name) && target_dir_name != "") {
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "确认备份",
                                      "原备份已存在,是否覆盖!",
                                      QMessageBox::Yes | QMessageBox::No);

        if (reply == QMessageBox::Yes) {
            statusBar()->showMessage("覆盖原备份...");
        } else {
            statusBar()->showMessage("取消备份");
            return;
        }
    } else {
        target_dir_name = systemManager_->createTimestampFolder(target_file_path, "uber_");
        if (target_dir_name.isEmpty()) {
            QMessageBox::warning(this, "错误", "无法创建目标目录");
            return;
        }
    }

    if (backupFileTypes.contains(PROGRAMFILE)) {
        // 只有在备份PROGRAMFILE时才处理teachpendant文件夹
        QString teachpendantTargetPath;
        if (backupFileTypes.contains(PROGRAMFILE)) {
            teachpendantTargetPath = target_dir_name + "/teachpendant";

            // 检查teachpendant文件夹是否已经存在
            if (!systemManager_->directoryExists(teachpendantTargetPath)) {
                // 不存在则创建
                QDir targetDir(target_dir_name);
                if (!targetDir.mkdir("teachpendant")) {
                    QMessageBox::warning(this, "错误", "无法创建teachpendant文件夹");
                    return;
                }
                qDebug() << "创建teachpendant文件夹:" << teachpendantTargetPath;
            } else {
                qDebug() << "teachpendant文件夹已存在:" << teachpendantTargetPath;
            }
        }
        // 只备份teachpendant下的特定文件夹
        QString teachpendantSourcePath = program_path;
        QStringList foldersToExport = {"database", "plugins", "procedure", "project", "script", "resources"};

        for (const QString& folder : foldersToExport) {
            QString fullPath = teachpendantSourcePath + "/" + folder;
            if (systemManager_->directoryExists(fullPath)) {
                // 设置目标路径为teachpendant文件夹下
                QString targetFolderPath = teachpendantTargetPath;

                // 先确保目标文件夹存在
                QDir(teachpendantTargetPath).mkdir(folder);

                // 复制文件夹
                systemManager_->copyFolder(fullPath, targetFolderPath);

                // 等待复制完成
                while (robotCopyState) {
                    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
                }

                // 检查是否出错
                if (robotCopyError) {
                    QMessageBox::warning(this, "错误", QString("拷贝失败: %1").arg(folder));
                    return;
                }
            } else {
                qDebug() << "文件夹不存在:" << fullPath;
            }
        }
    }

    QString sourceFolder;
    if (backupFileTypes.contains(PLUGINFILE)) {

        sourceFolder = plugin_path;
        if (!systemManager_->directoryExists(sourceFolder)) {
            QMessageBox::warning(this, "错误", QString("源文件夹不存在: %1").arg(sourceFolder));
            return;
        }
        systemManager_->copyFolder(sourceFolder, target_dir_name);

        while (robotCopyState) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
        }

        if (robotCopyError) {
            QMessageBox::warning(this, "错误", QString("拷贝失败: %1").arg(sourceFolder));
            return;
        }
    }

    // 日志备份 - 修改为分别保存到不同文件夹
    if (backupFileTypes.contains(PLUGINLOG)) {
        sourceFolder = plugin_log_path;
        if (!systemManager_->directoryExists(sourceFolder)) {
            QMessageBox::warning(this, "错误", QString("源文件夹不存在: %1 -- 插件日志").arg(sourceFolder));
            return;
        }

        systemManager_->copyFolder(sourceFolder, target_dir_name);

        while (robotCopyState) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
        }

        if (robotCopyError) {
            QMessageBox::warning(this, "错误", QString("拷贝失败: %1").arg(sourceFolder));
            return;
        }
    }

    if (backupFileTypes.contains(ROBOTLOG)) {
        // 机械臂日志目录 - 分别备份到不同子文件夹
        QStringList robotLogPaths = {
            "/root/AuboRobotWorkSpace/RobotServer/bin/logfiles",
            "/root/AuboRobotWorkSpace/teachpendant/bin/logfiles"
        };

        for (int i = 0; i < robotLogPaths.size(); i++) {
            QString sourcePath = robotLogPaths[i];
            if (!systemManager_->directoryExists(sourcePath)) {
                qDebug() << "机械臂日志文件夹不存在:" << sourcePath;
                continue;
            }

            // 为每个日志文件夹创建不同的目标文件夹名称
            QString targetSubFolder;
            if (i == 0) {
                targetSubFolder = "RobotServer_logs";  // 第一个改为RobotServer_logs
            } else {
                targetSubFolder = "TeachPendant_logs"; // 第二个改为TeachPendant_logs
            }

            QString targetPath = target_dir_name + "/" + targetSubFolder;

            // 先创建目录再复制
            QDir(target_dir_name).mkdir(targetSubFolder);

            systemManager_->copyFolder(sourcePath, targetPath);

            while (robotCopyState) {
                QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
            }

            if (robotCopyError) {
                QMessageBox::warning(this, "错误", QString("机械臂日志拷贝失败: %1").arg(sourcePath));
                return;
            }
        }
    }

    statusBar()->showMessage("导出完成");
    QMessageBox::information(this, "完成", "备份完成");
}

void MainWindow::updateTime()
{
    timeLabel->setText(QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss"));
}

void MainWindow::on_reboot_btn_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认重启",
                                  "确定要重启系统吗？",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        statusBar()->showMessage("正在重启系统...");
        systemManager_->reboot();
    } else {
        statusBar()->showMessage("已取消重启");
    }
}

void MainWindow::on_export2tar_btn_clicked()
{
    backup2Dir({ PROGRAMFILE, PLUGINFILE });
}


void MainWindow::onCopyStarted()
{
    statusBar()->showMessage("正在拷贝文件夹...");
    ui->export2tar_btn->setEnabled(false);
    ui->export_pluginlog_btn->setEnabled(false);
    ui->export_robotlog_btn->setEnabled(false);
    ui->export_all_btn->setEnabled(false);
//    qDebug() << "拷贝开始";
    robotCopyState = true;
}

void MainWindow::onCopyFinished(bool success, const QString& message)
{
    ui->export2tar_btn->setEnabled(true);
    ui->export_pluginlog_btn->setEnabled(true);
    ui->export_robotlog_btn->setEnabled(true);
    ui->export_all_btn->setEnabled(true);
    qDebug() << "拷贝完成";
    robotCopyState = false;
    robotCopyError = !success;  // 加这一行

    // 把下面的弹窗去掉，交给 on_export2tar_btn_clicked 统一处理
    statusBar()->showMessage(success ? "拷贝完成" : "拷贝失败");
}


void MainWindow::on_export_pluginlog_btn_clicked()
{
    backup2Dir({ PLUGINLOG });
}

void MainWindow::on_clear_pluginlog_btn_clicked()
{
    bool clearRes = systemManager_->removeDirectory(plugin_log_path);
    if(clearRes){
        QMessageBox::information(this, "完成", "文件清理已完成");
        statusBar()->showMessage("文件清理已完成");

    }else{
        QMessageBox::warning(this, "错误", "源文件夹不存在");
        statusBar()->showMessage("文件清理失败");
    }

}

void MainWindow::on_set_robot_ip_btn_clicked()
{
    // 此处可改为获取输入框的密码
    QString robotIP = "192.168.6.1";
    QString gateway = "192.168.6.1";

    bool setRes = systemManager_->setNetworkConfig("eth0", robotIP, "255.255.255.0", gateway);

    if(setRes){
        QMessageBox::information(this, "完成", "网络设置成功");
        statusBar()->showMessage("网络设置成功");

    }else{
        QMessageBox::warning(this, "错误", "网络设置失败!!!");
        statusBar()->showMessage("网络设置失败!!!");
    }
}

void MainWindow::on_import_charge_config_btn_clicked()
{
    qDebug() << "导入插件复选框状态:" << ui->is_plugin_import_checkbox->checkState();

    // 显示确认对话框
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认导入",
                                  "确认导入所选内容？\n\n",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply != QMessageBox::Yes) {
        statusBar()->showMessage("取消导入");
        return;
    }

    // 检查是否勾选了导入插件
    if(ui->is_plugin_import_checkbox->checkState()) {
        qDebug() << "开始导入插件...";

        // 源文件夹路径
        QString sourceFolder = import_dir_path + "/plugins";

        // 检查源文件夹是否存在
        if (!systemManager_->directoryExists(sourceFolder)) {
            QMessageBox::warning(this, "错误", QString("源文件夹不存在: %1").arg(sourceFolder));
            return;
        }

        qDebug() << "源文件夹路径:" << sourceFolder;
        qDebug() << "目标文件夹路径:" << plugin_path;

        // 显示确认对话框
        QMessageBox::StandardButton reply;
        reply = QMessageBox::question(this, "确认导入",
                                      "确定要全量导入插件文件夹的所有内容吗？\n\n"
                                      "这将导入plugins文件夹下的所有文件和子文件夹到目标位置。",
                                      QMessageBox::Yes | QMessageBox::No);

        if (reply != QMessageBox::Yes) {
            statusBar()->showMessage("取消导入");
            return;
        }

        statusBar()->showMessage("正在导入插件内容...");

        // 直接调用SystemManager的copyFolder函数
        // 这会递归复制sourceFolder下的所有内容到plugin_path
        systemManager_->copyFolder(sourceFolder, import_plugin_path);

        // 等待复制完成
        while (robotCopyState) {
            QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
        }

        // 检查是否出错
        if (robotCopyError) {
            QMessageBox::warning(this, "错误", "插件导入失败");
            statusBar()->showMessage("导入失败");
        } else {
            QMessageBox::information(this, "完成", "插件全量导入成功");
            statusBar()->showMessage("导入完成");
        }

    }

    // 在需要获取勾选文件的地方调用
    QStringList selectedFiles = getCheckedFiles();

    bool allSuccess = true;
    QStringList failedFolders;

    // 遍历勾选的每个文件夹并复制
    for (const QString &folder : selectedFiles) {
       QString sourceFolder = import_dir_path + "/teachpendant/" + folder;
       QString targetFolder = import_program_path + "/teachpendant";

       qDebug() << "正在导入:" << folder;
       qDebug() << "源路径:" << sourceFolder;
       qDebug() << "目标路径:" << targetFolder;

       // 检查源文件夹是否存在
       if (!systemManager_->directoryExists(sourceFolder)) {
           qDebug() << "源文件夹不存在:" << sourceFolder;
           failedFolders.append(folder + " (不存在)");
           allSuccess = false;
           continue;
       }

       // 复制文件夹
       systemManager_->copyFolder(sourceFolder, targetFolder);

       // 等待复制完成
       while (robotCopyState) {
           QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
       }

       // 检查是否出错
       if (robotCopyError) {
           failedFolders.append(folder);
           allSuccess = false;
           robotCopyError = false; // 重置错误状态
       } else {
           qDebug() << "文件夹导入成功:" << folder;
       }
    }

    // 显示结果
    if (allSuccess) {
       QMessageBox::information(this, "完成",
           QString("程序:所有文件夹导入成功！\n\n已导入：\n%1").arg(selectedFiles.join("\n")));
       statusBar()->showMessage("导入完成");
    } else {
       QString successCount = QString::number(selectedFiles.size() - failedFolders.size());
       QString errorMsg = QString("部分文件夹导入失败！\n\n"
                                 "成功：%1 个\n"
                                 "失败：%2 个\n\n"
                                 "失败的文件夹：\n%3")
                                 .arg(successCount)
                                 .arg(failedFolders.size())
                                 .arg(failedFolders.join("\n"));

       QMessageBox::warning(this, "警告", errorMsg);
       statusBar()->showMessage("部分导入失败");
    }
}


void MainWindow::on_export_all_btn_clicked()
{
    backup2Dir({ PROGRAMFILE, PLUGINFILE, PLUGINLOG, ROBOTLOG });
}

void MainWindow::on_select_tar_btn_clicked()
{

    // 方案1,选择压缩包
    // 清理之前的临时目录
    if (!tempExtractDir.isEmpty()) {
        systemManager_->cleanupTempDir(tempExtractDir);
        tempExtractDir.clear();
    }

    // 选择 ZIP 压缩包
    QString zipPath = QFileDialog::getOpenFileName(this, tr("选择ZIP压缩包"), "/root",
                                                   tr("ZIP文件 (*.zip)"));
    if(zipPath.isEmpty()) {
        return;
    }

    qDebug() << "选择的ZIP文件:" << zipPath;

    // 解压到临时目录
    tempExtractDir = systemManager_->extractZipToTemp(zipPath);

    if (tempExtractDir.isEmpty()) {
        QMessageBox::warning(this, "错误", "解压文件失败");
        return;
    }

    // 设置导入目录路径
    QStringList zipfileList = systemManager_->getFirstLevelFiles(tempExtractDir);

    ui->cur_tarname_label->setText(zipfileList.at(0));
    import_dir_path = tempExtractDir + "/" + zipfileList.at(0);
    QString dirPath = import_dir_path;


//    // 方案2:直接选择文件夹,获取文件列表
//    QString dirPath = QFileDialog::getExistingDirectory(this, tr("选择文件夹"), "/root");
//    if(dirPath.isEmpty()) {
//        return;
//    }

//    import_dir_path = dirPath;


    QStringList fileList = systemManager_->getFirstLevelFiles(dirPath + "/teachpendant");

    qDebug() << "找到文件:" << fileList;


    // 删除旧的模型（如果存在）
    if (fileListModel) {
        delete fileListModel;
        fileListModel = nullptr;
    }

    // 创建新的模型
    fileListModel = new QStandardItemModel(this);

    // 连接勾选状态变化的信号（用于调试）
    connect(fileListModel, &QStandardItemModel::itemChanged,
            this, [](QStandardItem *item) {
        qDebug() << "勾选状态变化 - 文件:" << item->text()
                 << "状态:" << (item->checkState() == Qt::Checked ? "已勾选" : "未勾选");
    });

    // 填充列表
    for (const QString &file : fileList) {
        QStandardItem *item = new QStandardItem(file);
        item->setCheckable(true);
        item->setCheckState(Qt::Checked);  // 默认未勾选
        item->setEditable(false);
        fileListModel->appendRow(item);
    }

    // 设置到ListView
    ui->tarcontent_list->setModel(fileListModel);

    ui->is_plugin_import_checkbox->setChecked(true);
}

void MainWindow::onItemCheckStateChanged(QStandardItem *item)
{
    if (item && item->isCheckable()) {
        QString fileName = item->text();
        Qt::CheckState state = item->checkState();

        qDebug() << "文件勾选状态变化:";
        qDebug() << "  文件名:" << fileName;
        qDebug() << "  状态:" << (state == Qt::Checked ? "已勾选" : "未勾选");

        // 更新状态栏
        updateSelectionStatus();
    }
}

void MainWindow::updateSelectionStatus()
{
    if (!fileListModel) {
        ui->statusBar->showMessage("文件列表未初始化");
        return;
    }

    int totalCount = fileListModel->rowCount();
    int checkedCount = 0;

    for (int i = 0; i < totalCount; ++i) {
        QStandardItem *item = fileListModel->item(i);
        if (item && item->checkState() == Qt::Checked) {
            checkedCount++;
        }
    }

    QString status = QString("已选择 %1/%2 个文件").arg(checkedCount).arg(totalCount);
    ui->statusBar->showMessage(status);

    qDebug() << "选择状态:" << status;
}

// mainwindow.cpp - 修改后的函数
void MainWindow::on_tar_and_export_btn_clicked()
{
    // 1. 设置要压缩的文件夹
    // 是否需要选择需要导出的文件夹
//    QString dirPath = QFileDialog::getExistingDirectory(this, tr("选择文件夹"), "/root");
//    if(dirPath.isEmpty()) {
//        return;
//    }
    if(target_dir_name == ""){
        statusBar()->showMessage("导出失败,请先备份对应程序!");
        return;
    }
    QString folderToCompress = target_dir_name;  // 使用你的程序路径

    // 2. 查找U盘 - 直接检查/media/root目录
    QString usbBasePath = "/media/root";
    QDir usbDir(usbBasePath);

    if (!usbDir.exists()) {
        QMessageBox::warning(this, "U盘未挂载",
            "U盘目录不存在，请插入U盘。");
        return;
    }

    // 获取/media/root下的所有文件夹
    QStringList usbFolders = usbDir.entryList(QDir::Dirs | QDir::NoDotAndDotDot);

    if (usbFolders.isEmpty()) {
        QMessageBox::warning(this, "未找到U盘",
            "在/media/root目录下未找到U盘设备。");
        return;
    }

    // 使用第一个找到的U盘
    QString usbPath = usbBasePath + "/" + usbFolders.first();
    qDebug() << "U盘路径:" << usbPath;

    // 3. 生成压缩文件名
    QString folderName = QFileInfo(folderToCompress).fileName();
    QString timestamp = QDateTime::currentDateTime().toString("_yyyyMMdd_hhmmss");
    QString zipFilePath = usbPath + "/" + folderName + timestamp + ".zip";

    // 4. 开始压缩
    QProcess process;
    QString parentDir = QFileInfo(folderToCompress).absolutePath();
    QString dirName = QFileInfo(folderToCompress).fileName();

    process.setWorkingDirectory(parentDir);
    process.start("zip", QStringList() << "-r" << zipFilePath << dirName);

    if (process.waitForFinished()) {
        QMessageBox::information(this, "完成", "压缩导出成功！");
    } else {
        QMessageBox::warning(this, "错误", "压缩失败");
    }
}

void MainWindow::on_export_robotlog_btn_clicked()
{
       backup2Dir({ ROBOTLOG });
}

void MainWindow::on_restartController_btn_clicked()
{
    statusBar()->showMessage("正在重启auboController...");
    systemManager_->restartController();

}
