#!/bin/bash
# 一键创建U盘安装包

echo "开始打包程序..."
echo "程序路径：/root/Documents/chargeTool_uber/build-chargeTool_uber-qt5_5_1-Release/chargeTool_uber_1.1.10"
echo "=========================================="

# 定义程序路径
APP_PATH="/root/Documents/chargeTool_uber/build-chargeTool_uber-qt5_5_1-Release/chargeTool_uber_1.1.10"
APP_NAME="chargeTool_uber"
VERSION="1.1.10"

# 创建打包目录
PACKAGE_DIR="$HOME/Desktop/${APP_NAME}_USB_Package"
rm -rf "$PACKAGE_DIR"
mkdir -p "$PACKAGE_DIR"
cd "$PACKAGE_DIR"

echo "1. 复制程序文件..."
if [ ! -f "$APP_PATH" ]; then
    echo "错误：找不到程序文件！"
    echo "请确保路径正确：$APP_PATH"
    exit 1
fi

# 复制主程序
cp "$APP_PATH" "./${APP_NAME}"
chmod +x "./${APP_NAME}"

# 查找并复制Qt依赖库
echo "2. 查找依赖库..."
QT_LIBS=$(ldd "./${APP_NAME}" | grep "Qt" | awk '{print \$3}' | sort -u)

if [ -n "$QT_LIBS" ]; then
    echo "找到Qt库，创建lib目录..."
    mkdir -p lib
    for lib in $QT_LIBS; do
        if [ -f "$lib" ]; then
            cp "$lib" lib/
            echo "  复制: $(basename "$lib")"
        fi
    done
fi

echo "3. 创建安装脚本..."
# 创建主安装脚本
cat > "安装程序.sh" << 'INSTALL_SCRIPT'
#!/bin/bash
# 充电工具安装脚本 v1.1.10

set -e  # 出错时退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 显示欢迎信息
clear
echo -e "${GREEN}╔════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        充电工具 ${VERSION} 安装向导             ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${YELLOW}注意：${NC}"
echo -e "1. 本程序需要Qt5库支持"
echo -e "2. 建议安装到用户目录或桌面"
echo -e "3. 安装完成后可创建桌面快捷方式"
echo ""
echo "请选择安装方式："
echo "1) 安装到当前目录（推荐）"
echo "2) 安装到桌面"
echo "3) 直接运行（不安装）"
echo "4) 查看系统依赖"
echo "5) 退出"
echo ""

read -p "请输入选项 [1-5]: " choice

case $choice in
    1)
        INSTALL_DIR="."
        echo "将安装到当前目录"
        ;;
    2)
        INSTALL_DIR="$HOME/Desktop/充电工具"
        echo "将安装到：$INSTALL_DIR"
        ;;
    3)
        echo "直接运行程序..."
        if [ -f "./chargeTool_uber" ]; then
            chmod +x ./chargeTool_uber
            ./chargeTool_uber &
        else
            echo -e "${RED}错误：找不到程序文件！${NC}"
            exit 1
        fi
        exit 0
        ;;
    4)
        echo "检查系统依赖..."
        echo "需要的Qt库："
        if command -v ldd &> /dev/null; then
            ldd ./chargeTool_uber 2>/dev/null | grep -i qt || echo "未找到Qt依赖"
        fi
        echo ""
        read -p "按回车键返回主菜单..." dummy
        exec "\$0"  # 重新运行脚本
        ;;
    5)
        echo "退出安装"
        exit 0
        ;;
    *)
        echo -e "${RED}无效选项！${NC}"
        exit 1
        ;;
esac

# 创建安装目录
mkdir -p "$INSTALL_DIR"
echo "创建目录：$INSTALL_DIR"

# 复制程序文件
echo "复制程序文件..."
cp -f ./chargeTool_uber "$INSTALL_DIR/"
chmod +x "$INSTALL_DIR/chargeTool_uber"

# 复制库文件（如果有）
if [ -d "./lib" ]; then
    echo "复制库文件..."
    mkdir -p "$INSTALL_DIR/lib"
    cp -rf ./lib/* "$INSTALL_DIR/lib/"
fi

# 创建启动脚本
echo "创建启动脚本..."
cat > "$INSTALL_DIR/启动充电工具.sh" << 'LAUNCHER'
#!/bin/bash
# 充电工具启动脚本

# 设置库路径
CURRENT_DIR=$(dirname "$(realpath "\$0")")
if [ -d "$CURRENT_DIR/lib" ]; then
    export LD_LIBRARY_PATH="$CURRENT_DIR/lib:$LD_LIBRARY_PATH"
fi

# 运行程序
cd "$CURRENT_DIR"
./chargeTool_uber "$@"
LAUNCHER

chmod +x "$INSTALL_DIR/启动充电工具.sh"

# 创建桌面快捷方式
if [ "$choice" != "2" ]; then
    echo "创建桌面快捷方式..."
    cat > "$HOME/Desktop/充电工具.desktop" << 'DESKTOP'
[Desktop Entry]
Version=1.0
Type=Application
Name=充电工具 v1.1.10
Comment=电池充电管理工具
Exec=bash -c "cd \"%s/Desktop/充电工具\" && ./启动充电工具.sh"
Icon=battery-full
Terminal=false
Categories=Utility;
StartupNotify=true
DESKTOP
    chmod +x "$HOME/Desktop/充电工具.desktop"
fi

echo ""
echo -e "${GREEN}════════════════════════════════════════════════${NC}"
echo -e "${GREEN}安装成功！${NC}"
echo -e "${GREEN}════════════════════════════════════════════════${NC}"
echo ""
echo "安装目录：$INSTALL_DIR"
echo ""
echo "启动方式："
echo "1. 双击桌面上的'充电工具'图标"
echo "2. 运行：$INSTALL_DIR/启动充电工具.sh"
echo ""
echo -e "${YELLOW}提示：${NC}"
echo "如果程序无法启动，请尝试："
echo "1. 安装Qt5库：sudo apt install qt5-default"
echo "2. 运行：sudo apt install libqt5core5a libqt5gui5 libqt5widgets5"
echo ""
read -p "按回车键退出..."
INSTALL_SCRIPT

# 设置脚本变量
sed -i "s/\${VERSION}/$VERSION/g" "安装程序.sh"
chmod +x "安装程序.sh"

# 创建双击启动的.desktop文件
echo "4. 创建桌面启动器..."
cat > "双击安装.desktop" << 'DESKTOP'
[Desktop Entry]
Version=1.0
Type=Application
Name=安装充电工具
Comment=点击运行安装程序
Icon=system-run
Exec=bash -c "cd \"%s\" && chmod +x ./安装程序.sh && ./安装程序.sh"
Terminal=true
Categories=Utility;
DESKTOP

# 创建说明文件
echo "5. 创建说明文档..."
cat > "使用说明.txt" << 'README'
充电工具 v1.1.10 - 使用说明
════════════════════════════════════════

一、快速安装：
1. 双击"双击安装.desktop"文件
2. 选择"信任并启动"
3. 按照提示选择安装方式
4. 完成后双击桌面图标运行

二、手动安装：
1. 右键点击"安装程序.sh"
2. 选择"属性" → "权限"
3. 勾选"允许作为程序执行文件"
4. 双击运行

三、直接运行：
1. 打开终端
2. 输入：chmod +x chargeTool_uber
3. 输入：./chargeTool_uber

四、常见问题：
1. 如果提示缺少Qt库，请运行：
   sudo apt install qt5-default

2. 如果无法双击运行，请使用终端运行

技术支持：请联系开发者
════════════════════════════════════════
README

echo ""
echo -e "${GREEN}════════════════════════════════════════════════${NC}"
echo -e "${GREEN}打包完成！${NC}"
echo -e "${GREEN}════════════════════════════════════════════════${NC}"
echo ""
echo "U盘安装包已创建到："
echo "$PACKAGE_DIR"
echo ""
echo "包含以下文件："
ls -la "$PACKAGE_DIR"
echo ""
echo "请将此目录所有文件复制到U盘根目录"
echo ""
echo "用户使用步骤："
echo "1. 插入U盘"
echo "2. 双击'双击安装.desktop'"
echo "3. 点击'信任并启动'"
echo "4. 按照提示安装"

