#!/bin/bash
# 创建完整的U盘安装包

echo "创建U盘安装包..."
echo "========================"

# 创建U盘目录结构
mkdir -p USB_PACKAGE
cd USB_PACKAGE

# 复制程序
cp /root/Documents/chargeTool_uber/build-chargeTool_uber-qt5_5_1-Release/chargeTool_uber_1.1.10 ./
chmod +x chargeTool_uber_1.1.10

# 创建主安装脚本（用户双击这个）
cat > 双击安装.desktop << 'DESKTOP'
[Desktop Entry]
Version=1.0
Type=Application
Name=双击这里安装程序
Comment=运行安装向导
Icon=dialog-information
Exec=bash -c "chmod +x ./install.sh && ./install.sh"
Terminal=true
Categories=Utility;
DESKTOP

# 创建安装脚本
cat > install.sh << 'INSTALL'
#!/bin/bash
# 主安装脚本

clear
echo "╔══════════════════════════════════════╗"
echo "║        程序安装向导                  ║"
echo "╚══════════════════════════════════════╝"
echo ""
echo "请选择操作："
echo "1) 安装程序到当前目录（推荐）"
echo "2) 安装程序到桌面"
echo "3) 直接运行（不安装）"
echo "4) 退出"
echo ""
read -p "请输入选项 [1-4]: " choice

case $choice in
    1)
        echo "正在安装到当前目录..."
        DIR="."
        ;;
    2)
        echo "正在安装到桌面..."
        DIR="$HOME/Desktop"
        ;;
    3)
        echo "直接运行程序..."
        chmod +x ./chargeTool_uber_1.1.10
        ./chargeTool_uber_1.1.10
        exit 0
        ;;
    4)
        echo "退出安装"
        exit 0
        ;;
    *)
        echo "无效选项"
        exit 1
        ;;
esac

# 设置执行权限
chmod +x ./chargeTool_uber_1.1.10

# 创建启动脚本
cat > "$DIR/启动程序.sh" << 'LAUNCHER'
#!/bin/bash
cd "$(dirname "\$0")"
./chargeTool_uber_1.1.10
LAUNCHER

chmod +x "$DIR/启动程序.sh"

echo ""
echo "════════════════════════════════════════"
echo "安装完成！"
echo "请运行：$DIR/启动程序.sh"
echo "════════════════════════════════════════"
read -p "按回车键退出..."
INSTALL

chmod +x install.sh

# 创建说明文件
cat > 使用说明.txt << 'README'
使用方法：
════════════════════════════════════════

方法1（最简单）：
1. 双击"双击安装.desktop"
2. 选择"信任并启动"
3. 按照提示操作

方法2：
1. 右键点击"install.sh"
2. 选择"属性"
3. 勾选"允许作为程序执行文件"
4. 双击运行

方法3（终端）：
1. 打开终端
2. 输入：chmod +x install.sh
3. 输入：./install.sh
README

echo "U盘安装包已创建到 USB_PACKAGE/ 目录"
echo "请将此目录所有文件复制到U盘根目录"

