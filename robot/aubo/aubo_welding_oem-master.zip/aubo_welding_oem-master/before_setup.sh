#!/bin/bash
ROOT_DIR=$(dirname $(readlink -f $0))/oem

# 配置安装
export INSTALL_AUBO_SCOPE=true
export INSTALL_WEBSCOPE=true

# 设置默认配置文件
# INSTALL_DIR=$(dirname $(readlink -f $0))
chmod a+x ${ROOT_DIR}/setup.sh || echo "setup.sh script not found"
