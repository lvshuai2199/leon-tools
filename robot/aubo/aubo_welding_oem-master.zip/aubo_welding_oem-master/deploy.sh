#!/bin/bash -e

echo "开始运行脚本"

# 获取当前脚本所在目录的路径
ROOT_DIR=$(dirname "$(readlink -f "\$0")")

# 定义下载的 URL
URL="https://download.aubo-robotics.cn/extensions"
ROCKER_VERSION="rocker-0.2.7-Linux_x86_64+8acfa36.zip"
WELD_EXTENSION_VERSION="weld-1.0.7+1736d93.zip"

# 获取 git 信息
echo "获取 Git 版本信息..."
GIT_HASH=$(git rev-parse --short HEAD 2>/dev/null || echo "unknown")

# 获取 git 标签信息
echo "获取 Git 标签信息..."
GIT_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "test")

# 定义版本号和构建目录
PACKAGE_NAME="Welding-${GIT_TAG}"
TARGET_DIR="${ROOT_DIR}/${PACKAGE_NAME}"

# 创建构建目录（如果不存在）
echo "创建构建目录：${TARGET_DIR}"
mkdir -p "${TARGET_DIR}"

# 下载和解压 rocker 文件
echo "下载和解压：${ROCKER_VERSION}"
wget -q "${URL}/${ROCKER_VERSION}" -O "${TARGET_DIR}/${ROCKER_VERSION}" || { echo "下载失败"; exit 1; }
unzip -oq -d "${TARGET_DIR}" "${TARGET_DIR}/${ROCKER_VERSION}" && rm -f "${TARGET_DIR}/${ROCKER_VERSION}"

# 下载和解压 weld_extension 文件
echo "下载和解压：${WELD_EXTENSION_VERSION}"
wget -q "${URL}/${WELD_EXTENSION_VERSION}" -O "${TARGET_DIR}/${WELD_EXTENSION_VERSION}" || { echo "下载失败"; exit 1; }
unzip -oq -d "${TARGET_DIR}" "${TARGET_DIR}/${WELD_EXTENSION_VERSION}" && rm -f "${TARGET_DIR}/${WELD_EXTENSION_VERSION}"

# 复制当前目录中的所有文件到目标目录中，排除特殊文件和目录
echo "复制当前目录中的文件到 ${TARGET_DIR}，排除特殊文件和目录..."
shopt -s dotglob extglob
for item in "${ROOT_DIR}"/*; do
    # 排除目标目录和不需要复制的文件
    if [[ "$item" != "${TARGET_DIR}" && "$item" != "${ROOT_DIR}/.gitlab-ci.yml" && "$item" != "${ROOT_DIR}/deploy.sh" && "$item" != "${ROOT_DIR}/build" && "$item" != "${ROOT_DIR}/.git" ]]; then
        echo "复制文件：$item 到 ${TARGET_DIR}"
        cp -r "$item" "${TARGET_DIR}/"
    fi
done

# 定义构建目录，放置在当前目录同级
BUILD_DIR="${ROOT_DIR}/build"

# 创建构建目录（如果不存在）
echo "创建构建目录：${BUILD_DIR}"
mkdir -p "${BUILD_DIR}"

# 定义输出文件名，保留文件夹名称并添加 Git 版本信息和标签，后缀为 .oem
OEM_PACKAGE_NAME="${PACKAGE_NAME}+${GIT_HASH}.oem"

# 压缩并生成目标文件
echo "正在压缩总文件夹：${PACKAGE_NAME}"
cd "${ROOT_DIR}"
zip -r "${BUILD_DIR}/${OEM_PACKAGE_NAME}" "${PACKAGE_NAME}" && echo "压缩完成，生成的文件为: ${BUILD_DIR}/${OEM_PACKAGE_NAME}"

echo "脚本执行完成！"
