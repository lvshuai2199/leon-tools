#!/bin/bash -e
ROOT_DIR=$(dirname $(readlink -f $0))
GIT_HASH=$(git rev-parse --short HEAD)
VERSION_NUM=$(git describe --abbrev=0 --tags)
VERSION_NUM=${VERSION_NUM#v}

OEM_PACKAGE_NAME="dn-${VERSION_NUM}+${GIT_HASH}.oem"
URL="https://download.aubo-robotics.cn/extensions"
ICM_SRV_VERSION="icm_srv-0.1.17+1666313.zip"
ICM_SRV_PACKAGE_NAME=${URL}/${ICM_SRV_VERSION}

BUILD_DIR=${ROOT_DIR}/dn-${VERSION_NUM}

[ -d ${BUILD_DIR} ] || mkdir -p ${BUILD_DIR}

wget ${ICM_SRV_PACKAGE_NAME} -O ${ROOT_DIR}/${ICM_SRV_VERSION}
unzip -d ${BUILD_DIR} ${ROOT_DIR}/${ICM_SRV_VERSION}

# copy 定制化资源目录到软件包中
mkdir -p ${BUILD_DIR}/service
mkdir -p ${BUILD_DIR}/resources
OEM_PATH=oem/${ICM_SRV_VERSION%.*} envsubst < service/aubo_icm.service | sed -e 's/§/$/g' >> ${BUILD_DIR}/service/aubo_icm.service

cp -arv ${ROOT_DIR}/config/* ${BUILD_DIR}/
cp -av ${ROOT_DIR}/setup.sh ${BUILD_DIR}
cp -arv ${ROOT_DIR}/resources/* ${BUILD_DIR}/resources/

mkdir -p ${ROOT_DIR}/build
cd $(dirname ${BUILD_DIR}) && zip -q -r ${ROOT_DIR}/build/${OEM_PACKAGE_NAME} ./$(basename ${BUILD_DIR})
