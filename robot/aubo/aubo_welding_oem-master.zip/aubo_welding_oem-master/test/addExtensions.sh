#!/bin/bash

# 配置文件路径
CONFIG_FILE="/root/arcs_ws/config/aubo_control.conf"

# 备份文件路径
BACKUP_FILE="${CONFIG_FILE}.old"

# 新的[[Extension]] rocker 模块内容
NEW_ROCKER_EXTENSION=$(cat << 'EOF'

[[Extension]]
    location = "extensions/rocker/rocker.so"
    bundle = "rocker"

    # 别名
    alias = "rocker"
    enable = true

    # 配置参数
    [Extension.options]
        device_info = "/dev/ttyRobotTool,115200,N,8,1"
        # Tool的XYZ对应Rocker的XYZ(1,2,3)
        tool_x = 1
        tool_y = -3
        tool_z = 2
        pose_speed_fast = 0.15
        pose_speed_slow = 0.06
        ori_velc = 0.008
        acc = 1.0
        debug = 1
        rotation = 0.0 # 安装方式与末端坐标系的安装旋转角度(浮点数)
EOF
)

# 要确保存在的[RobotHw.options]参数
HW_OPTIONS=(
    "tool_bus_type = 1 # 末端串口类型 0-modbus 1-485串口 2-力传感器"
    "baudrate = \"115200\" # 末端串口支持的波特率 \"4800\" \"9600\" \"19200\" \"38400\" \"57600\" \"115200\" \"230400\" \"460800\""
    "stopbits = \"1\" # 末端串口支持的停止位 \"1\" \"0.5\" \"1.5\" \"2\""
    "parity = \"none\" # 末端串口支持的校验位 \"none\" \"even\" \"odd\""
)

# 创建备份文件
create_backup() {
    if [ ! -f "$BACKUP_FILE" ]; then
        echo "正在备份配置文件为 $BACKUP_FILE..."
        cp -av "$CONFIG_FILE" "$BACKUP_FILE"
        echo "备份完成。"
    else
        echo "备份文件已存在：$BACKUP_FILE"
    fi
}

# 检查并添加新的[[Extension]] rocker 模块
check_and_append_rocker_module() {
    if grep -qPzo "\[\[Extension\]\][^\[]*alias = \"rocker\"" "$CONFIG_FILE"; then
        echo "文件中已经存在完整的'rocker'模块，未做任何修改。"
    else
        echo "文件中没有找到完整的'rocker'模块，正在追加新的'rocker'模块..."
        echo "$NEW_ROCKER_EXTENSION" >> "$CONFIG_FILE"
        echo "新的'rocker'模块已追加到配置文件末尾。"
    fi
}

# 定义要追加的参数（每行前有 8 个空格）
HW_OPTIONS=(
"tool_bus_type = 1 # 末端串口类型 0-modbus 1-485串口 2-力传感器"
"baudrate = \"115200\" # 末端串口支持的波特率 \"4800\" \"9600\" \"19200\" \"38400\" \"57600\" \"115200\" \"230400\" \"460800\""
"stopbits = \"1\" # 末端串口支持的停止位 \"1\" \"0.5\" \"1.5\" \"2\""
"parity = \"none\" # 末端串口支持的校验位 \"none\" \"even\" \"odd\""
)

# 更新 [RobotHw.options] 参数的函数
check_and_append_hw_options() {
    # 检查 [[RobotHw]] 是否包含 alias = "robot_driver1"
    if grep -qPzo "(?s)\[\[RobotHw\]\][^\[]*alias = \"robot_driver1\"" "$CONFIG_FILE"; then
        echo "已找到 [[RobotHw]] 模块的 alias = \"robot_driver1\" 部分，开始检查和追加参数..."

        # 定位到 alias = "robot_driver1" 的块
        BLOCK_START=$(grep -n "alias = \"robot_driver1\"" "$CONFIG_FILE" | head -n 1 | cut -d: -f1)
        BLOCK_END=$(tail -n +$BLOCK_START "$CONFIG_FILE" | grep -n "^\[" | head -n 1 | cut -d: -f1)
        if [ -z "$BLOCK_END" ]; then
            BLOCK_END=$(wc -l < "$CONFIG_FILE")
        else
            BLOCK_END=$((BLOCK_START + BLOCK_END - 1))
        fi

        # 检查 [RobotHw.options] 是否存在
        if ! sed -n "${BLOCK_START},${BLOCK_END}p" "$CONFIG_FILE" | grep -qF "[RobotHw.options]"; then
            echo "未找到 [RobotHw.options] 部分，正在自动创建..."
            sed -i "${BLOCK_START},${BLOCK_END}s/alias = \"robot_driver1\"/&\n        [RobotHw.options]/" "$CONFIG_FILE"
        fi

        # 定位 [RobotHw.options] 的具体行号
        OPTIONS_LINE=$(sed -n "${BLOCK_START},${BLOCK_END}p" "$CONFIG_FILE" | grep -nF "[RobotHw.options]" | cut -d: -f1)
        if [ -n "$OPTIONS_LINE" ]; then
            OPTIONS_LINE=$((BLOCK_START + OPTIONS_LINE - 1))
        else
            echo "错误：未能正确定位 [RobotHw.options] 部分，脚本终止。"
            exit 1
        fi

        # 遍历参数并逐行追加到 [RobotHw.options]
        for option in "${HW_OPTIONS[@]}"; do
            if ! sed -n "${OPTIONS_LINE},${BLOCK_END}p" "$CONFIG_FILE" | grep -qF "$option"; then
                echo "追加参数: $option"
                sed -i "${OPTIONS_LINE}a\        $option" "$CONFIG_FILE"
                OPTIONS_LINE=$((OPTIONS_LINE + 1))
            else
                echo "参数已存在，无需重复添加: $option"
            fi
        done

        echo "参数已成功追加到 alias = \"robot_driver1\" 的 [RobotHw.options] 中。"
    else
        echo "未找到 alias = \"robot_driver1\" 的 [[RobotHw]] 模块，请检查配置文件结构是否符合预期。"
    fi
}

# 检查配置文件是否存在
if [ ! -f "$CONFIG_FILE" ]; then
    echo "错误：配置文件 $CONFIG_FILE 不存在！"
    exit 1
fi

# 执行脚本逻辑
create_backup
check_and_append_rocker_module
check_and_append_hw_options
