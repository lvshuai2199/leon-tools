#!/bin/bash
ROOT_DIR=$(dirname $(readlink -f $0))
DIR_NAME=$(basename $(dirname $(readlink -f $0)))

declare $(grep "^VERSION=" /etc/default/arcs) &>/dev/null
declare $(grep "^PREFIX=" /etc/default/arcs) &>/dev/null

rm -rf ${PREFIX}/oem/${DIR_NAME}
mkdir -p ${PREFIX}/oem/${DIR_NAME}
cp -av ${ROOT_DIR}/* ${PREFIX}/oem/${DIR_NAME}

#( [ -f /etc/default/arcs ] && source /etc/default/arcs ) || echo "arcs env file not found"

# 写入OEM_VERSION变量
if ! grep -q "OEM_VERSION" /etc/default/arcs; then
   echo "OEM_VERSION=${DIR_NAME}" >> /etc/default/arcs
else
   # 如果OEM_VERSION存在，强制替换为当前GeneralWelding版本
   sed -Ei "s@(^OEM_VERSION=).*@\1${DIR_NAME}@g" /etc/default/arcs
fi

if [ -z ${VERSION} ];then
   echo "version env not declare"
else
   rm -rf ${PREFIX}/${VERSION}/oem
   ln -sv ${PREFIX}/oem/${DIR_NAME} ${PREFIX}/${VERSION}/oem
fi

${PREFIX}/${VERSION}/setup.sh install

reboot
