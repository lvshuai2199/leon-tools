#include "aubo_sdk/rpc.h"
#include <bitset>
#ifdef WIN32
#include <Windows.h>
#endif

using namespace arcs::aubo_sdk;

// 标准数字IO
void exampleStandardDigitalIO(RpcClientPtr cli) {
  // 接口调用: 获取机器人的名字
  auto robot_name = cli->getRobotNames().front();
  auto robot = cli->getRobotInterface(robot_name);

  // 接口调用: 获取标准数字输入和输出数量
  int default_do_num = robot->getIoControl()->getStandardDigitalOutputNum();
  int default_di_num = robot->getIoControl()->getStandardDigitalInputNum();
  std::cout << "StandardDigitalInputNum（标准数字输入数量）: " << default_di_num
            << std::endl;
  std::cout << "StandardDigitalOutputNum（标准数字输出数量）: "
            << default_do_num << std::endl;

  // 打印所有的标准数字输入值
  for (int i = 0; i < default_di_num; i++) {
    // 接口调用: 获取标准数字输入值
    auto input_value = robot->getIoControl()->getStandardDigitalInput(i);
    std::cout << "管脚" << i << "数字输入:" << input_value << std::endl;
  }

  // 打印所有的标准数字输出值
  for (int i = 0; i < default_do_num; i++) {
    //        // 接口调用: 设置标准数字输出值
    //        robot->getIoControl()->setStandardDigitalOutput(i, true);
    //        std::this_thread::sleep_for(std::chrono::seconds(1));
    // 接口调用: 获取标准数字输出值
    auto output_value = robot->getIoControl()->getStandardDigitalOutput(i);
    std::cout << "管脚" << i << "数字输出:" << output_value << std::endl;
  }

  // 接口调用: 设置输入出发动作为Freedrive
  StandardInputAction input_action = StandardInputAction::Handguide;
  robot->getIoControl()->setStandardDigitalInputAction(0x00000003,
                                                       input_action);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置标准数字输入触发动作为：" << input_action << std::endl;
  // 接口调用: 获取输入触发动作
  input_action =
      robot->getIoControl()->getStandardDigitalInputAction(0x00000003);
  std::cout << "获取标准数字输入触发动作为：" << input_action << std::endl;

  // 接口调用: 设置所有的输入出发动作为Default
  robot->getIoControl()->setDigitalInputActionDefault();
  std::this_thread::sleep_for(std::chrono::seconds(1));
  // 接口调用: 获取输入触发动作
  input_action =
      robot->getIoControl()->getStandardDigitalInputAction(0x00000003);
  std::cout << "获取标准数字输入触发动作为：" << input_action << std::endl;

  // 接口调用: 设置输出状态选择为Freedrive
  StandardOutputRunState output_runstate = StandardOutputRunState::Handguiding;
  robot->getIoControl()->setStandardDigitalOutputRunstate(0x00000003,
                                                          output_runstate);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置标准数字输出状态选择为：" << output_runstate << std::endl;
  // 接口调用: 获取输出状态选择
  output_runstate =
      robot->getIoControl()->getStandardDigitalOutputRunstate(0x00000003);
  std::cout << "获取标准数字输出状态选择为：" << output_runstate << std::endl;

  // 接口调用: 设置所有的输出状态选择为NONE
  robot->getIoControl()->setDigitalOutputRunstateDefault();
  std::this_thread::sleep_for(std::chrono::seconds(1));
  // 接口调用: 获取输出状态选择
  output_runstate =
      robot->getIoControl()->getStandardDigitalOutputRunstate(0x00000003);
  std::cout << "获取标准数字输出状态选择为：" << output_runstate << std::endl;
}

// 标准模拟IO
void exampleStandardAnalogIO(RpcClientPtr cli) {
  // 接口调用: 获取机器人的名字
  auto robot_name = cli->getRobotNames().front();
  auto robot = cli->getRobotInterface(robot_name);

  // 接口调用: 获取标准模拟输入和输出数量
  std::cout << "StandardAnalogInputNum（标准模拟输入数量）: "
            << robot->getIoControl()->getStandardAnalogInputNum() << std::endl;
  std::cout << "StandardAnalogOutputNum（标准模拟输出数量）: "
            << robot->getIoControl()->getStandardAnalogOutputNum() << std::endl;

  // 接口调用: 设置和获取标准模拟输入范围
  int input_domain = 9;
  robot->getIoControl()->setStandardAnalogInputDomain(0, input_domain);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置标准模拟输入范围是:" << input_domain << std::endl;
  input_domain = robot->getIoControl()->getStandardAnalogInputDomain(0);
  std::cout << "获取标准模拟输入范围是:" << input_domain << std::endl;

  // 接口调用: 获取标准模拟输入
  double input_value = robot->getIoControl()->getStandardAnalogInput(0);
  std::cout << "获取标准模拟输入:" << input_value << std::endl;

  // 接口调用: 设置和获取标准模拟输出范围
  int output_domain = 9;
  robot->getIoControl()->setStandardAnalogOutputDomain(0, output_domain);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置标准模拟输出范围是:" << output_domain << std::endl;
  output_domain = robot->getIoControl()->getStandardAnalogOutputDomain(0);
  std::cout << "获取标准模拟输出范围是:" << output_domain << std::endl;

  // 接口调用: 设置和获取标准模拟输出状态选择
  StandardOutputRunState output_runstate = StandardOutputRunState::StopLow;
  robot->getIoControl()->setStandardAnalogOutputRunstate(1, output_runstate);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置标准模拟输出状态选择:" << output_runstate << std::endl;
  output_runstate = robot->getIoControl()->getStandardAnalogOutputRunstate(1);
  std::cout << "获取标准模拟输出状态选择:" << output_runstate << std::endl;

  // 接口调用: 设置和获取标准模拟输出
  double output_value = 3.3;
  robot->getIoControl()->setStandardAnalogOutput(0, output_value);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置标准模拟输出:" << output_value << std::endl;
  output_value = robot->getIoControl()->getStandardAnalogOutput(0);
  std::cout << "获取标准模拟输出:" << output_value << std::endl;
}

// 工具端数字IO
void exampleToolDigitalIO(RpcClientPtr cli) {
  // 接口调用: 获取机器人的名字
  auto robot_name = cli->getRobotNames().front();
  auto robot = cli->getRobotInterface(robot_name);

  // 接口调用: 获取工具端数字输入和输出数量
  std::cout << "ToolDigitalInputNum（工具端数字输入数量）: "
            << robot->getIoControl()->getToolDigitalInputNum() << std::endl;
  std::cout << "ToolDigitalOutputNum（工具端数字输出数量）: "
            << robot->getIoControl()->getToolDigitalOutputNum() << std::endl;

  // 接口调用: 设置指定的工具端数字IO的类型
  bool isInput = true;
  robot->getIoControl()->setToolIoInput(1, isInput);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置工具端数字IO的类型为:" << (isInput ? "输入" : "输出")
            << std::endl;
  // 接口调用: 判断指定的工具端IO是否为输入
  isInput = robot->getIoControl()->isToolIoInput(1);
  std::cout << "指定的工具端IO是否为输入:" << (isInput ? "是" : "否")
            << std::endl;
  // 接口调用: 获取工具端数字输入值
  bool input = robot->getIoControl()->getToolDigitalInput(1);
  std::cout << "获取工具端数字输入值:" << (input ? "高电平" : "低电平")
            << std::endl;

  // 接口调用: 设置和获取工具端数字输入触发动作
  StandardInputAction input_action = StandardInputAction::Default;
  robot->getIoControl()->setToolDigitalInputAction(0, input_action);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置工具端数字输入触发动作:" << input_action << std::endl;
  input_action = robot->getIoControl()->getToolDigitalInputAction(0);
  std::cout << "获取工具端数字输入触发动作:" << input_action << std::endl;

  // 接口调用: 设置和获取工具端数字输出状态选择
  StandardOutputRunState output_runstate = StandardOutputRunState::StopLow;
  robot->getIoControl()->setToolDigitalOutputRunstate(3, output_runstate);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置工具端数字输出状态选择:" << output_runstate << std::endl;
  output_runstate = robot->getIoControl()->getToolDigitalOutputRunstate(3);
  std::cout << "获取工具端数字输出状态选择:" << output_runstate << std::endl;

  // 接口调用: 设置指定的工具端数字IO的类型
  isInput = false;
  robot->getIoControl()->setToolIoInput(1, isInput);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置工具端数字IO的类型为:" << (isInput ? "输入" : "输出")
            << std::endl;

  // 接口调用: 设置工具端数字输出值
  bool output = true;
  robot->getIoControl()->setToolDigitalOutput(1, output);
  std::this_thread::sleep_for(std::chrono::seconds(1));
  std::cout << "设置工具端数字输出值:" << (output ? "高电平" : "低电平")
            << std::endl;
  // 接口调用: 获取工具端数字输出值
  output = robot->getIoControl()->getToolDigitalOutput(1);
  std::cout << "获取工具端数字输出值:" << (output ? "高电平" : "低电平")
            << std::endl;
}

// 工具端模拟IO
void exampleToolAnalogIO(RpcClientPtr cli) {
  // 接口调用: 获取机器人的名字
  auto robot_name = cli->getRobotNames().front();
  auto robot = cli->getRobotInterface(robot_name);

  // 接口调用: 获取工具端模拟输入数量
  std::cout << "ToolAnalogInputNum（工具端模拟输入数量）: "
            << robot->getIoControl()->getToolAnalogInputNum() << std::endl;

  // 接口调用: 获取工具端模拟输入范围
  int input_domain = robot->getIoControl()->getToolAnalogInputDomain(0);
  std::cout << "获取工具端模拟输入范围:" << input_domain << std::endl;

  // 接口调用: 获取工具端模拟输入值
  double input = robot->getIoControl()->getToolAnalogInput(0);
  std::cout << "获取工具端模拟输入值:" << input << std::endl;
}

// 安全IO
void exampleSafetyIO(RpcClientPtr cli) {
  // 接口调用: 获取机器人的名字
  auto robot_name = cli->getRobotNames().front();
  auto robot = cli->getRobotInterface(robot_name);

  // 接口调用: 获取安全IO输入和输出数量
  int safety_input_num =
      robot->getIoControl()->getConfigurableDigitalInputNum();
  int safety_output_num =
      robot->getIoControl()->getConfigurableDigitalOutputNum();

  std::cout << "安全IO的输入数量: " << safety_input_num << std::endl;
  std::cout << "安全IO的输出数量: " << safety_output_num << std::endl;

  // 获取安全IO输入的值
  for (int i = 0; i < safety_input_num; i++) {
    // 接口调用: 获取安全IO输入的值
    auto value = robot->getIoControl()->getConfigurableDigitalInput(i);
    std::cout << "管脚" << i << "安全IO输入的值:" << value << std::endl;
  }

  // 获取安全IO输出的值
  for (int i = 0; i < safety_output_num; i++) {
    // 接口调用: 获取安全IO输出的值
    auto value = robot->getIoControl()->getConfigurableDigitalOutput(i);
    std::cout << "管脚" << i << "安全IO输出的值:" << value << std::endl;
  }
}

// 联动IO
void exampleStaticLinkIO(RpcClientPtr cli) {
  // 接口调用: 获取机器人的名字
  auto robot_name = cli->getRobotNames().front();
  auto robot = cli->getRobotInterface(robot_name);

  // 接口调用: 获取联动IO输入和输出数量
  int link_input_num = robot->getIoControl()->getStaticLinkInputNum();
  int link_output_num = robot->getIoControl()->getStaticLinkOutputNum();
  std::cout << "联动IO的输入数量: " << link_input_num << std::endl;
  std::cout << "联动IO的输出数量: " << link_output_num << std::endl;

  // 获取联动IO输入的值
  int input_value_decimal = robot->getIoControl()->getStaticLinkInputs();
  // 将十进制数转换为二进制数
  std::bitset<32> input_value_binary(input_value_decimal);
  // 将std::bitset<32>转换为字符串
  std::string input_value_string = input_value_binary.to_string();
  // 反转二进制数
  std::reverse(input_value_string.begin(), input_value_string.end());

  std::cout << "所有联动IO输入的值: "
            << input_value_string.substr(0, link_input_num) << std::endl;

  // 获取联动IO输出的值
  int output_value_decimal = robot->getIoControl()->getStaticLinkOutputs();
  // 将十进制数转换为二进制数
  std::bitset<32> output_value_binary(output_value_decimal);
  // 将std::bitset<32>转换为字符串
  std::string output_value_string = output_value_binary.to_string();
  // 反转二进制数
  std::reverse(output_value_string.begin(), output_value_string.end());

  std::cout << "所有联动IO输出的值: "
            << output_value_string.substr(0, link_output_num) << std::endl;
}

#define LOCAL_IP "127.0.0.1"

/**
 * 功能:IO
 * 步骤:
 * 第一步: 连接 RPC 服务、机械臂登录
 * 第二步: 标准数字IO:
 *       1.获取标准数字输入和输出数量
 *       2.获取标准数字输入和输出值
 *       3.设置和获取输入触发动作
 *       4.设置和获取输出状态选择
 * 第三步: 标准模拟IO:
 *       1.获取标准模拟输入和输出数量
 *       2.设置和获取标准模拟输入范围
 *       3.获取标准模拟输入
 *       4.设置和获取标准模拟输出范围
 *       5.设置和获取标准模拟输出状态选择
 *       6.设置和获取标准模拟输出
 * 第四步: 工具端数字IO
 *       1.获取工具端数字输入和输出数量
 *       2.设置和获取工具端数字输入触发动作
 *       3.设置和获取工具端数字输出状态选择
 * 第五步: 工具端模拟IO
 *       1.获取工具端模拟输入数量
 *       2.获取工具端模拟输入范围
 *       3.获取工具端模拟输入
 * 第六步: 安全IO
 *       1.获取安全IO输入和输出数量
 *       2.获取安全IO输入和输出值
 * 第七步: 联动IO
 *       1.获取联动IO输入和输出数量
 *       2.获取联动IO输入和输出值
 * 第八步: 退出登录、断开 RPC 连接
 */
int main(int argc, char **argv) {
#ifdef WIN32
  // 将Windows控制台输出代码页设置为 UTF-8
  SetConsoleOutputCP(CP_UTF8);
#endif
  auto rpc_cli = std::make_shared<RpcClient>();
  // 接口调用: 设置 RPC 超时
  rpc_cli->setRequestTimeout(1000);
  // 接口调用: 连接到 RPC 服务
  rpc_cli->connect(LOCAL_IP, 30004);
  // 接口调用: 登录
  rpc_cli->login("aubo", "123456");

  // 标准数字IO
  exampleStandardDigitalIO(rpc_cli);

  // 标准模拟IO
  exampleStandardAnalogIO(rpc_cli);

  // 工具端数字IO
  exampleToolDigitalIO(rpc_cli);

  //     工具端模拟IO
  exampleToolAnalogIO(rpc_cli);

  // 安全IO
  exampleSafetyIO(rpc_cli);

  // 联动IO
  exampleStaticLinkIO(rpc_cli);

  // 接口调用: 退出登录
  rpc_cli->logout();
  // 接口调用: 断开连接
  rpc_cli->disconnect();

  return 0;
}
