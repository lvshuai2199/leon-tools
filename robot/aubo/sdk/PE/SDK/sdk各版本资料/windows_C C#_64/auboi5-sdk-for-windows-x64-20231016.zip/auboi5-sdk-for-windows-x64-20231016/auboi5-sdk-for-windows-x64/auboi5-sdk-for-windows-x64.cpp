// auboi5-sdk-for-windows-x64.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include "rsdef.h"
#include <string>
#include "example.h"

#define ROBOT_ADDR "192.168.10.10"
#define ROBOT_PORT 8899

#define MAX_LINE 4200

#define M_PI 3.14159265358979323846

//��е�ۿ��������ľ��
RSHD g_rshd = -1;

FILE* fp;

FILE* outp;

int _tmain(int argc, _TCHAR* argv[])
{
	double file_Joint[6];

	char* str_joint_1;
	char* str_joint_2;
	char* str_joint_3;
	char* str_joint_4;
	char* str_joint_5;
	char* str_joint_6;

	int ret = -1;

	errno_t err;

	char buf[MAX_LINE];

	int len;

	

	//��¼������
	if (example_login(g_rshd, ROBOT_ADDR, ROBOT_PORT))
	{
		////������е��(����������ʵ��е�ۣ�
		example_robotStartup(g_rshd);

		//��������
		rs_project_startup(g_rshd);



		double initPos[6] = { 0 / 180.0 *M_PI, 
							  0 / 180.0 * M_PI,
			               -150 / 180.0 * M_PI,
			                29.9999 / 180.0 * M_PI,
			                 90 / 180.0 * M_PI, 
							0 / 180.0 * M_PI };

		rs_init_global_move_profile(g_rshd);

		/** �ӿڵ���: ���ùؽ����˶��������ٶ� ***/
		aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
		jointMaxAcc.jointPara[0] = 10.0 / 180.0 * M_PI;
		jointMaxAcc.jointPara[1] = 10.0 / 180.0 * M_PI;
		jointMaxAcc.jointPara[2] = 10.0 / 180.0 * M_PI;
		jointMaxAcc.jointPara[3] = 10.0 / 180.0 * M_PI;
		jointMaxAcc.jointPara[4] = 10.0 / 180.0 * M_PI;
		jointMaxAcc.jointPara[5] = 10.0 / 180.0 * M_PI;   //�ӿ�Ҫ��λ�ǻ���
		rs_set_global_joint_maxacc(g_rshd, &jointMaxAcc);

		/** �ӿڵ���: ���ùؽ����˶�������ٶ� ***/
		aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
		jointMaxVelc.jointPara[0] = 10.0 / 180.0 * M_PI;
		jointMaxVelc.jointPara[1] = 10.0 / 180.0 * M_PI;
		jointMaxVelc.jointPara[2] = 10.0 / 180.0 * M_PI;
		jointMaxVelc.jointPara[3] = 10.0 / 180.0 * M_PI;
		jointMaxVelc.jointPara[4] = 10.0 / 180.0 * M_PI;
		jointMaxVelc.jointPara[5] = 10.0 / 180.0 * M_PI;   //�ӿ�Ҫ��λ�ǻ���
		rs_set_global_joint_maxvelc(g_rshd, &jointMaxVelc);

		rs_leave_tcp2canbus_mode(g_rshd);

		//�����˶�����ʼλ��
		if (ret = rs_move_joint(g_rshd, initPos) == RS_SUCC)
		{
			ret = true;
			std::cout << "movej succ" << std::endl;


		}
		else
		{
			std::cerr << "movej failed!" << std::endl;
		}
		Sleep(5000);

		ret = rs_enter_tcp2canbus_mode(g_rshd);


	//	rs_remove_all_waypoint(g_rshd);


		SYSTEMTIME sys;
		

		fp = fopen("E://aubo_code/20230925/windows_touchuan/track_3.txt", "r");
		outp = fopen("E://aubo_code/20230925/windows_touchuan/delay_time_kuai.txt", "w");

		int line_num = 1;

		int before_time;
		int after_time;
		RobotDiagnosis m_Diagnosis_info;

		if (fp != 0)
		{
			printf("open file sucessfully\n");
			while (fgets(buf, MAX_LINE, fp) != NULL)
			{
				len = strlen(buf);
				buf[len - 1] = '\0';
				//printf("%s\n", buf);

				str_joint_1 = strtok(buf, " ,");
				str_joint_2 = strtok(NULL, " ,");
				str_joint_3 = strtok(NULL, " ,");
				str_joint_4 = strtok(NULL, " ,");
				str_joint_5 = strtok(NULL, " ,");
				str_joint_6 = strtok(NULL, " ,");

				file_Joint[0] = atof(str_joint_1) / 180.0 * M_PI;
				file_Joint[1] = atof(str_joint_2) / 180.0 * M_PI;
				file_Joint[2] = atof(str_joint_3) / 180.0 * M_PI;
				file_Joint[3] = atof(str_joint_4) / 180.0 * M_PI;
				file_Joint[4] = atof(str_joint_5) / 180.0 * M_PI;
				file_Joint[5] = atof(str_joint_6) / 180.0 * M_PI;

				/*printf("%f,", file_Joint[0]);
				printf("%f,", file_Joint[1]);
				printf("%f,", file_Joint[2]);
				printf("%f,", file_Joint[3]);
				printf("%f,", file_Joint[4]);
				printf("%f ", file_Joint[5]);
				printf("%d\n", line_num);*/
				line_num++;
				//rs_add_waypoint(g_rshd, file_Joint);
				//Sleep(2);

				GetLocalTime(&sys);
				//printf("%4d/%02d/%02d %02d:%02d:%02d.%03d ����%1d\n", sys.wYear, sys.wMonth, sys.wDay, sys.wHour, sys.wMinute, sys.wSecond, sys.wMilliseconds, sys.wDayOfWeek);

				before_time = (sys.wMinute * 60 * 1000) + (sys.wSecond * 1000) + sys.wMilliseconds;
				printf("%03d\n", before_time);
				//Sleep(1);


				rs_get_diagnosis_info(g_rshd, &m_Diagnosis_info);

				GetLocalTime(&sys);
				after_time = (sys.wMinute * 60 * 1000) + (sys.wSecond * 1000) + sys.wMilliseconds;
				printf("%03d,%d\n", after_time, after_time - before_time);

				fprintf(outp, "%d\n", after_time - before_time);


				ret = rs_set_waypoint_to_canbus(g_rshd, file_Joint);

				
				
				
			}
		}
		else
		{
			printf("open file failed %d \n", fp);
		}

		rs_leave_tcp2canbus_mode(g_rshd);

	//	ret = rs_move_track(g_rshd, JOINT_UBSPLINEINTP,true);
	//	printf("movetrack return is %d\n",ret);

		//����ֹͣ
		rs_project_stop(g_rshd);

		//�˳���¼
		example_logout(g_rshd);
	}

	//����ʼ���ӿڿ�
	rs_uninitialize();

	std::cout<<"please enter to exit"<<std::endl;
	//getchar();

	return 0;
}

