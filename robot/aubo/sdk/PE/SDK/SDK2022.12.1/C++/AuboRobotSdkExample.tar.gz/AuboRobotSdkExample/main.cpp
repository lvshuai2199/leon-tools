#include <iostream>

#include <stdio.h>
#include <unistd.h>

#include "example_0.h"
#include "example_1.h"
#include "example_3.h"
#include "example_4.h"
#include "example_5.h"
#include "example_6.h"
#include "example_8.h"
#include "example_9.h"
#include "example_tcp2can.h"


int main()
{
    //case tcp2can: 透传模式应用
    //Example_Tcp2Can::demo();
   // Example_Tcp2Can::demo1();
    //Case 0: Using the SDK to build a control engineering for the simplest robotic arm
//    Example_0::demo();//使用sdk建立一个工程

    //Case 1: The way of the callback function to obtain the real-time waypoint,
    //the end speed, the event of the manipulator, about the acquisition of the relevant state of the manipulator
    //Example_1::demo();//机械臂回调函数
    //Example_1::getJointStatus();
    //Example_1::getCurrentWaypointInfo();

    //Case 3: Joint Movement
    Example_3::demo();//轴动
//    Example_3::demo1();

    //Case 4: Line Movement
 // Example_4::demo();//直线运动
  //Example_4::demo_relativeOri();

    //Case 5: Trajectory movement
    //Example_5::demo1();//轨迹运动
    //Example_5::demo();

    //Case 6: Movement to the target position
//    Example_6::demo();//运动到目标点

    //Case 8: Positive and negative solutions
    //Example_8::demo();//正逆解

    //Case 9: About the use case of io
//    Example_9::demo();//用户io控制

    return 0;
}

