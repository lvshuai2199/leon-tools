#include "example_3.h"

#include <unistd.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <sstream>
#include <fstream>
#include "util.h"


#define SERVER_HOST "127.0.0.1"
#define SERVER_PORT 8899

void Example_3::demo()
{
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cout<<"login successful."<<std::endl;
    }
    else
    {
        std::cerr<<"login failed."<<std::endl;
    }

     std::cout<<"Robot arm initialization....."<<std::endl;


     /** If the real robot arm is connected, the arm needs to be initialized.**/
     aubo_robot_namespace::ROBOT_SERVICE_STATE result;

     //Tool dynamics parameter
     aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
     memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

     ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**Tool dynamics parameter**/,
                                                6        /*Collision level*/,
                                                true     /*Whether to allow reading poses defaults to true*/,
                                                true,    /*Leave the default to true */
                                                1000,    /*Leave the default to 1000 */
                                                result); /*Robot arm initialization*/
     if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
     {
         std::cout<<"Robot arm initialization succeeded."<<std::endl;
     }
     else
     {
         std::cerr<<"Robot arm initialization failed."<<std::endl;
     }

    /** Business block **/
    /** Interface call: Initialize motion properties ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of the articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;//50
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** Interface call: set the maximum speed of articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;//50
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    /** Robot arm movement to zero posture **/
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
    Util::initJointAngleArray(jointAngle, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);


    std::cout<<"Calling the motion function"<<std::endl;
    ret = robotService.robotServiceJointMove(jointAngle, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement to zero posture failure.　ret:"<<ret<<std::endl;
    }

    for(int i=0;i>-1;i++)
    {
//        /** Interface call: set offset**/
//        aubo_robot_namespace::MoveRelative relativeMoveOnBase;
//        relativeMoveOnBase.ena = true;
//        relativeMoveOnBase.relativePosition[0] = 0;
//        relativeMoveOnBase.relativePosition[1] = 0;
//        relativeMoveOnBase.relativePosition[2] = 0.05*(i%4);   //Unit: m

//        relativeMoveOnBase.relativeOri.w=1;
//        relativeMoveOnBase.relativeOri.x=0;
//        relativeMoveOnBase.relativeOri.y=0;
//        relativeMoveOnBase.relativeOri.z=0;
//        robotService.robotServiceSetMoveRelativeParam(relativeMoveOnBase);


        /** Waypoint 1 movement **/
        Util::initJointAngleArray(jointAngle, 0.0/180.0*M_PI,  0.0/180.0*M_PI,  90.0/180.0*M_PI, 0.0/180.0*M_PI, 90.0/180.0*M_PI, 0.0/180.0*M_PI);
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement to waypoint 1 failed.　ret:"<<ret<<std::endl;
            break;
        }

        /** Waypoint 2 movement **/
        Util::initJointAngleArray(jointAngle, 15.0/180.0*M_PI,  0.0/180.0*M_PI,  90.0/180.0*M_PI, 0.0/180.0*M_PI, 90.0/180.0*M_PI, 0.0/180.0*M_PI);
        robotService.robotServiceJointMove(jointAngle, true);
        if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
        {
            std::cerr<<"Movement to waypoint 2 failed.　ret:"<<ret<<std::endl;
            break;
        }
    }

    sleep(10);

    /** Robotic arm shutdown **/
    robotService.robotServiceRobotShutdown();

    /** Interface call: logout　**/
    robotService.robotServiceLogout();
}

void Example_3::demo1()
{
    ServiceInterface robotService;

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: login ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cout<<"login successful."<<std::endl;
    }
    else
    {
        std::cerr<<"login failed."<<std::endl;
    }

     std::cout<<"Robot arm initialization....."<<std::endl;


     /** If the real robot arm is connected, the arm needs to be initialized.**/
     aubo_robot_namespace::ROBOT_SERVICE_STATE result;

     //Tool dynamics parameter
     aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
     memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

     ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**Tool dynamics parameter**/,
                                                6        /*Collision level*/,
                                                true     /*Whether to allow reading poses defaults to true*/,
                                                true,    /*Leave the default to true */
                                                1000,    /*Leave the default to 1000 */
                                                result); /*Robot arm initialization*/
     if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
     {
         std::cout<<"Robot arm initialization succeeded."<<std::endl;
     }
     else
     {
         std::cerr<<"Robot arm initialization failed."<<std::endl;
     }
    robotService.robotServiceInitGlobalMoveProfile();


    robotService.robotServiceInitGlobalMoveProfile();
     //设置关节运动最大加速度
     aubo_robot_namespace::JointVelcAccParam m_set_jointacc;
     m_set_jointacc.jointPara[0] = 30*M_PI/180;
     m_set_jointacc.jointPara[1] = 30*M_PI/180;
     m_set_jointacc.jointPara[2] = 30*M_PI/180;
     m_set_jointacc.jointPara[3] = 30*M_PI/180;
     m_set_jointacc.jointPara[4] = 30*M_PI/180;
     m_set_jointacc.jointPara[5] = 30*M_PI/180;
     robotService.robotServiceSetGlobalMoveJointMaxAcc(m_set_jointacc);
     //设置关节运动最大速度
     aubo_robot_namespace::JointVelcAccParam m_set_jointvelc;
     m_set_jointvelc.jointPara[0] = 15*M_PI/180;
     m_set_jointvelc.jointPara[1] = 15*M_PI/180;
     m_set_jointvelc.jointPara[2] = 15*M_PI/180;
     m_set_jointvelc.jointPara[3] = 15*M_PI/180;
     m_set_jointvelc.jointPara[4] = 15*M_PI/180;
     m_set_jointvelc.jointPara[5] = 15*M_PI/180;
     robotService.robotServiceSetGlobalMoveJointMaxVelc(m_set_jointvelc);
     //设置末端型运动最大加速度
     double m_set_end_lineacc = 0.02;//0.2
     robotService.robotServiceSetGlobalMoveEndMaxLineAcc(m_set_end_lineacc);
     //设置末端型运动最大速度
     double m_set_end_linevelc = 0.02;//0.2
     robotService.robotServiceSetGlobalMoveEndMaxLineVelc(m_set_end_linevelc);
     double wp1[6] = {};
     wp1[0] = 60.443151*M_PI/180;
     wp1[1] = 42.275463*M_PI/180;
     wp1[2] = -97.679737*M_PI/180;
     wp1[3] = -49.990510*M_PI/180;
     wp1[4] = -90.007372*M_PI/180;
     wp1[5] = 62.567046*M_PI/180;
     //关节运动
     robotService.robotServiceJointMove(wp1,true);
     /**** 设置 User 坐标系(p1)下的相对偏移 *****/
     aubo_robot_namespace::CoordCalibrateByJointAngleAndTool userCoord;
     userCoord.coordType = aubo_robot_namespace::WorldCoordinate;
     userCoord.methods = aubo_robot_namespace::Origin_AnyPointOnPositiveYAxis_AnyPointOnPositiveZAxis;
     userCoord.wayPointArray[0].jointPos[0] = -16.418907*M_PI/180;
     userCoord.wayPointArray[0].jointPos[1] = 11.715555*M_PI/180;
     userCoord.wayPointArray[0].jointPos[2] = -133.748860*M_PI/180;
     userCoord.wayPointArray[0].jointPos[3] = -55.472799*M_PI/180;
     userCoord.wayPointArray[0].jointPos[4] = -89.999982*M_PI/180;
     userCoord.wayPointArray[0].jointPos[5] = -14.340675*M_PI/180;
     userCoord.wayPointArray[1].jointPos[0] = -55.333572*M_PI/180;
     userCoord.wayPointArray[1].jointPos[1] = 11.813817*M_PI/180;
     userCoord.wayPointArray[1].jointPos[2] = -138.234095*M_PI/180;
     userCoord.wayPointArray[1].jointPos[3] = -38.422666*M_PI/180;
     userCoord.wayPointArray[1].jointPos[4] = -75.692136*M_PI/180;
     userCoord.wayPointArray[1].jointPos[5] = -55.999864*M_PI/180;
     userCoord.wayPointArray[2].jointPos[0] = -81.686194*M_PI/180;
     userCoord.wayPointArray[2].jointPos[1] = 26.339385*M_PI/180;
     userCoord.wayPointArray[2].jointPos[2] = -126.337995*M_PI/180;
     userCoord.wayPointArray[2].jointPos[3] = -66.550139*M_PI/180;
     userCoord.wayPointArray[2].jointPos[4] = -65.208444*M_PI/180;
     userCoord.wayPointArray[2].jointPos[5] = -78.755974*M_PI/180;
     /*工具参数*/
     aubo_robot_namespace::ToolInEndDesc tool1;
     tool1.toolInEndPosition.x = 0;
     tool1.toolInEndPosition.y = 0;
     tool1.toolInEndPosition.z = 0.45;
     tool1.toolInEndOrientation.w = 1;
     tool1.toolInEndOrientation.x = 0;
     tool1.toolInEndOrientation.y = 0;
     tool1.toolInEndOrientation.z = 0;
     userCoord.toolDesc = tool1;
     /*设置目标位置*/
     aubo_robot_namespace::Pos posOnBase;
     posOnBase.x = 0;
     posOnBase.y = 0.3;
     posOnBase.z = -0.6;
     /*直线运动至目标位置*/


    printf("回车后运行至参考点 .... \n");  getchar();
    /*直线运动至目标位置*/
    std::cout<<"Calling the 1111111111111111"<<std::endl;

    ret =robotService.robotMoveLineToTargetPosition(userCoord,posOnBase,tool1,false);

    std::cout<<"ret"<<ret<<std::endl;
    std::cout<<"Calling the 22222222222222222"<<std::endl;

    printf("回车后运行至参考点 .... \n");  getchar();


   // sleep(10);

    /** Robot arm movement to zero posture **/
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};
    Util::initJointAngleArray(jointAngle, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);

    std::cout<<"Calling the motion function"<<std::endl;
    ret = robotService.robotServiceJointMove(jointAngle, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement to zero posture failure.　ret:"<<ret<<std::endl;
    }
    /** Robotic arm shutdown **/
    robotService.robotServiceRobotShutdown();

    /** Interface call: logout　**/
    robotService.robotServiceLogout();
}

