#ifndef EXAMPLE_TCP2CAN_H
#define EXAMPLE_TCP2CAN_H


class Example_Tcp2Can
{
public:
    /**
     * @brief demo
     *
     * 透传模式应用
     */
    static void demo();

    static void demo1();
};

#endif // EXAMPLE_TCP2CAN_H
