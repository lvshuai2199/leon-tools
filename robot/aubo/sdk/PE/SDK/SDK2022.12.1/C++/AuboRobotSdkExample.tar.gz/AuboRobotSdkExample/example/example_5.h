#ifndef EXAMPLE_5_H
#define EXAMPLE_5_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"
class Example_5
{
public:
    /**
     * @brief demo
     *
     * Trajectory movement
     *
     */

    static void RealTimeMovepStepNumNotifyCallback(int num, void *arg);

    //实时末端速度回调函数
    static void RealTimeEndSpeedCallback (double speed, void *arg);  //Get real-time end speed callback function


    static void demo();

    static void demo1();
};

#endif // EXAMPLE_5_H
