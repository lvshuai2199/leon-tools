#ifndef EXAMPLE_3_H
#define EXAMPLE_3_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"

class Example_3
{
public:
    /**
     * @brief demo
     *
     * Joint motion
     */
    static void demo();

    static void demo1();
};

#endif // EXAMPLE_3_H
