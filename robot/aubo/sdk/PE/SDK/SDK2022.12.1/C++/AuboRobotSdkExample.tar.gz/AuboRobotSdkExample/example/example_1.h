#ifndef EXAMPLE_1_H
#define EXAMPLE_1_H

#include "AuboRobotMetaType.h"
#include "serviceinterface.h"

/**
 * @brief The Example_1 class
 *
 * About the acquisition of the relevant state of the robot arm
 *
 */

class Example_1
{
public:
    //实时路点回调函数
    static void RealTimeWaypointCallback (const aubo_robot_namespace::wayPoint_S *wayPointPtr, void *arg); //Used to get real-time waypoint callback function
    //实时末端速度回调函数
    static void RealTimeEndSpeedCallback (double speed, void *arg);  //Get real-time end speed callback function
    //实时末端速度回调函数
    static void RealTimeEventInfoCallback(const aubo_robot_namespace::RobotEventInfo *pEventInfo, void *arg); //Get real-time robotic arm event callback function
    //实时关节状态回调函数
    static void RealTimeJointStatusCallback(const aubo_robot_namespace::JointStatus *jointStatus, int size, void *arg);
    /**
     * @brief demo
     *
     * 回调函数的方式获取实时路点，末端速度，机械臂的事件
     */
    static void demo();

    //获取机械臂关节状态信息
    static void getJointStatus();
    //robotServiceGetCurrentWaypointInfo(aubo_robot_namespace::wayPoint_S &wayPoint)
    static void getCurrentWaypointInfo();
};

#endif // EXAMPLE_1_H
