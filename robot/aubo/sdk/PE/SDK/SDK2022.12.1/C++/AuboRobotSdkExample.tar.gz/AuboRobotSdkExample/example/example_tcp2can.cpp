#include "example_tcp2can.h"
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <sstream>
#include <fstream>
#include <vector>
#include <termio.h>

#include "AuboRobotMetaType.h"    //Robot arm metadata type
#include "serviceinterface.h"     //Robot arm interface


#define SERVER_HOST "127.0.0.1"
//#define SERVER_HOST "192.168.1.100"
#define SERVER_PORT 8899

#define  JOINT1_ADD       119
#define  JOINT1_SUB       115
#define  Enter_Tcp2Can    49
#define  Exit_Tcp2Can     48

int scanKeyboard()
{
    int in;
    struct termios new_settings;
    struct termios stored_settings;
    tcgetattr(0,&stored_settings);
    new_settings = stored_settings;
    new_settings.c_lflag &= (~ICANON);
    new_settings.c_cc[VTIME] = 0;
    tcgetattr(0,&stored_settings);
    new_settings.c_cc[VMIN] = 1;
    tcsetattr(0,TCSANOW,&new_settings);

    in = getchar();

    tcsetattr(0,TCSANOW,&stored_settings);
    return in;
}


void Example_Tcp2Can::demo()
{
    ServiceInterface robotService;

    aubo_robot_namespace::wayPoint_S currentWaypointInfo;
    aubo_robot_namespace::wayPoint_S temp1;
    aubo_robot_namespace::wayPoint_S temp2;
    aubo_robot_namespace::wayPoint_S temp3;
    aubo_robot_namespace::wayPoint_S temp4;
    std::vector<aubo_robot_namespace::wayPoint_S> vecWaypointInfo;

    currentWaypointInfo.jointpos[0] = 0.0;
    currentWaypointInfo.jointpos[1] = 0.0;
    currentWaypointInfo.jointpos[2] = 0.0;
    currentWaypointInfo.jointpos[3] = 0.0;
    currentWaypointInfo.jointpos[4] = 0.0;
    currentWaypointInfo.jointpos[5] = 0.0;


    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: 登录 ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cout<<"login successful."<<std::endl;
    }
    else
    {
        std::cerr<<"login failed."<<std::endl;
    }


    /** 上电　**/
    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

    //Tool dynamics parameter
    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**Tool dynamics parameter**/,
                                               6        /*Collision level*/,
                                               true     /*Whether to allow reading poses defaults to true*/,
                                               true,    /*Leave the default to true */
                                               1000,    /*Leave the default to 1000 */
                                               result); /*Robot arm initialization*/
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cout<<"Robot arm initialization succeeded."<<std::endl;
    }
    else
    {
        std::cerr<<"Robot arm initialization failed."<<std::endl;
    }
    /** 初始化操作：关闭透传模式 **/
    ret = robotService.robotServiceLeaveTcp2CanbusMode();

    //初始化运动属性-----------
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of the articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** Interface call: set the maximum speed of articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    ret = robotService.robotServiceJointMove(currentWaypointInfo.jointpos, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement to zero posture failure.　ret:"<<ret<<std::endl;
    }else{
        std::cerr<<"Movement to zero posture success.　ret:"<<ret<<std::endl;
    }
    //-------------------------------------------
    /** 运动逻辑 **/

    std::cout << "w:joint1 + move,s:joint1 - move," << std::endl;
    std::cout << "0:exit tcp2can,1:enter tcp2can" << std::endl;
    std::cout << "Please first enter tcp2can" << std::endl;

    while(1)
    {
        vecWaypointInfo.clear();

        int keyboard_num = scanKeyboard();
        switch (keyboard_num) {
        case Enter_Tcp2Can://进入透传模式
        {
            std::cout << "enter tcp2can mode" << std::endl;

            robotService.robotServiceEnterTcp2CanbusMode();
        }
            break;
        case Exit_Tcp2Can://退出透传模式
        {
            std::cout << "exit tcp2can mode" << std::endl;

            robotService.robotServiceLeaveTcp2CanbusMode();
        }
            break;
        case JOINT1_ADD://关节1正移动
        {
            std::cout << "Joint1 add" << std::endl;
            vecWaypointInfo.clear();
            temp1 = currentWaypointInfo;
            temp1.jointpos[0] += 0.0017;
            temp2 = temp1;
            temp2.jointpos[0] += 0.0017;
            temp3 = temp2;
            temp3.jointpos[0] += 0.0017;
            temp4 = temp3;
            temp4.jointpos[0] += 0.0017;
            currentWaypointInfo = temp4;
            vecWaypointInfo.push_back(temp1);
            vecWaypointInfo.push_back(temp2);
            vecWaypointInfo.push_back(temp3);
            vecWaypointInfo.push_back(temp4);

            ret = robotService.robotServiceSetRobotPosData2Canbus(vecWaypointInfo);
        }
            break;
        case JOINT1_SUB://关节1负移动
        {
            std::cout << "Joint1 sub" << std::endl;
            vecWaypointInfo.clear();
            temp1 = currentWaypointInfo;
            temp1.jointpos[0] -= 0.0017;
            temp2 = temp1;
            temp2.jointpos[0] -= 0.0017;
            temp3 = temp2;
            temp3.jointpos[0] -= 0.0017;
            temp4 = temp3;
            temp4.jointpos[0] -= 0.0017;
            currentWaypointInfo = temp4;
            vecWaypointInfo.push_back(temp1);
            vecWaypointInfo.push_back(temp2);
            vecWaypointInfo.push_back(temp3);
            vecWaypointInfo.push_back(temp4);

            ret = robotService.robotServiceSetRobotPosData2Canbus(vecWaypointInfo);
        }
        default:
            break;
        }

    }
}

void Example_Tcp2Can::demo1()
{
    ServiceInterface robotService;

    aubo_robot_namespace::wayPoint_S currentWaypointInfo;
    aubo_robot_namespace::wayPoint_S temp1;
    aubo_robot_namespace::wayPoint_S temp2;
    aubo_robot_namespace::wayPoint_S temp3;
    aubo_robot_namespace::wayPoint_S temp4;
    std::vector<aubo_robot_namespace::wayPoint_S> vecWaypointInfo;

    currentWaypointInfo.jointpos[0] = 0.0;
    currentWaypointInfo.jointpos[1] = 0.0;
    currentWaypointInfo.jointpos[2] = 0.0;
    currentWaypointInfo.jointpos[3] = 0.0;
    currentWaypointInfo.jointpos[4] = 0.0;
    currentWaypointInfo.jointpos[5] = 0.0;


    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: 登录 ***/
    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cout<<"login successful."<<std::endl;
    }
    else
    {
        std::cerr<<"login failed."<<std::endl;
    }


    /** 上电　**/
    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

    //Tool dynamics parameter
    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**Tool dynamics parameter**/,
                                               6        /*Collision level*/,
                                               true     /*Whether to allow reading poses defaults to true*/,
                                               true,    /*Leave the default to true */
                                               1000,    /*Leave the default to 1000 */
                                               result); /*Robot arm initialization*/
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cout<<"Robot arm initialization succeeded."<<std::endl;
    }
    else
    {
        std::cerr<<"Robot arm initialization failed."<<std::endl;
    }
    /** 初始化操作：关闭透传模式 **/
    ret = robotService.robotServiceLeaveTcp2CanbusMode();

    //初始化运动属性-----------
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of the articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** Interface call: set the maximum speed of articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    ret = robotService.robotServiceJointMove(currentWaypointInfo.jointpos, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement to zero posture failure.　ret:"<<ret<<std::endl;
    }else{
        std::cerr<<"Movement to zero posture success.　ret:"<<ret<<std::endl;
    }
    //-------------------------------------------
    /** 运动逻辑 **/

    std::cout << "w:joint1 + move,s:joint1 - move," << std::endl;
    std::cout << "0:exit tcp2can,1:enter tcp2can" << std::endl;
    std::cout << "Please first enter tcp2can" << std::endl;

    while(1)
    {
        vecWaypointInfo.clear();

        int keyboard_num = scanKeyboard();
        switch (keyboard_num) {
        case Enter_Tcp2Can://进入透传模式
        {
            std::cout << "enter tcp2can mode" << std::endl;

            robotService.robotServiceEnterTcp2CanbusMode();
        }
            break;
        case Exit_Tcp2Can://退出透传模式
        {
            std::cout << "exit tcp2can mode" << std::endl;

            robotService.robotServiceLeaveTcp2CanbusMode();
        }
            break;
        case JOINT1_ADD://关节1正移动
        {
            std::cout << "Joint1 add" << std::endl;
            vecWaypointInfo.clear();
            temp1 = currentWaypointInfo;
            temp1.jointpos[0] += 0.0017;
            temp2 = temp1;
            temp2.jointpos[0] += 0.0017;
            temp3 = temp2;
            temp3.jointpos[0] += 0.0017;
            temp4 = temp3;
            temp4.jointpos[0] += 0.0017;
            currentWaypointInfo = temp4;
            vecWaypointInfo.push_back(temp1);
            vecWaypointInfo.push_back(temp2);
            vecWaypointInfo.push_back(temp3);
            vecWaypointInfo.push_back(temp4);

            double jointAngle[aubo_robot_namespace::ARM_DOF]={0};
            jointAngle[0]=temp1.jointpos[0];
            jointAngle[1]=temp1.jointpos[1];
            jointAngle[2]=temp1.jointpos[2];
            jointAngle[3]=temp1.jointpos[3];
            jointAngle[4]=temp1.jointpos[4];
            jointAngle[5]=temp1.jointpos[5];
            //ret = robotService.robotServiceSetRobotPosData2Canbus(vecWaypointInfo);

            ret=robotService.robotServiceSetRobotPosData2Canbus(jointAngle);
        }
            break;
        case JOINT1_SUB://关节1负移动
        {
            std::cout << "Joint1 sub" << std::endl;
            vecWaypointInfo.clear();
            temp1 = currentWaypointInfo;
            temp1.jointpos[0] -= 0.0017;
            temp2 = temp1;
            temp2.jointpos[0] -= 0.0017;
            temp3 = temp2;
            temp3.jointpos[0] -= 0.0017;
            temp4 = temp3;
            temp4.jointpos[0] -= 0.0017;
            currentWaypointInfo = temp4;
            vecWaypointInfo.push_back(temp1);
            vecWaypointInfo.push_back(temp2);
            vecWaypointInfo.push_back(temp3);
            vecWaypointInfo.push_back(temp4);

            double jointAngle[aubo_robot_namespace::ARM_DOF]={0};
            jointAngle[0]=temp1.jointpos[0];
            jointAngle[1]=temp1.jointpos[1];
            jointAngle[2]=temp1.jointpos[2];
            jointAngle[3]=temp1.jointpos[3];
            jointAngle[4]=temp1.jointpos[4];
            jointAngle[5]=temp1.jointpos[5];
            //ret = robotService.robotServiceSetRobotPosData2Canbus(vecWaypointInfo);

            ret=robotService.robotServiceSetRobotPosData2Canbus(jointAngle);
        }
        default:
            break;
        }

    }
}
