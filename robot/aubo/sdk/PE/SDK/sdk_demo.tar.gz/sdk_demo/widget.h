#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

#include "AuboRobotMetaType.h"

#include "serviceinterface.h"



namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pb_init_clicked();

    void on_pb_startup_clicked();

    void on_pb_global_move_init_clicked();

    void on_pb_speed_joints_speed_clicked();

    void on_pb_speed_joints_acc_clicked();

    void on_pb_speed_end_speed_clicked();

    void on_pb_speed_end_acc_clicked();

    void on_pb_move_joint_clicked();

    void on_pb_IK_clicked();

    void on_pb_update_clicked();

    void on_pb_move_to_IK_point_clicked();

private:
    Ui::Widget *ui;
    ServiceInterface robotService;

};

#endif // WIDGET_H
