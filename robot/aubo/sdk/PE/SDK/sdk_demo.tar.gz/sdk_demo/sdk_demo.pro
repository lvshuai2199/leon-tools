#-------------------------------------------------
#
# Project created by QtCreator 2022-10-18T15:00:22
#
#-------------------------------------------------

QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = sdk_demo
TEMPLATE = app


CONFIG += c++11

    #32bit OS
    contains(QT_ARCH, i386){

        CONFIG += c++11

        DEFINES += _GLIBCXX_USE_CXX11_ABI=0

        INCLUDEPATH += $$PWD/dependents/inc/aubo_sdk

        LIBS += -L$$PWD/dependents/lib/ -laubo_sdk

        LIBS += -L$$PWD/dependents/lib/ -laral

        LIBS += -lpthread
    }
    #64bit OS
    contains(QT_ARCH, x86_64){

        CONFIG += c++11

        INCLUDEPATH += $$PWD/dependents/inc/aubo_sdk

        LIBS += -L$$PWD/dependents/lib/ -laubo_sdk

        LIBS += -L$$PWD/dependents/lib/ -laral

        LIBS += -lpthread
    }

SOURCES += main.cpp\
        widget.cpp

HEADERS  += widget.h

FORMS    += widget.ui
