#include "widget.h"
#include "ui_widget.h"
#include <QDebug>

#define SERVER_HOST "127.0.0.1"
//#define SERVER_HOST "192.168.1.12"
#define SERVER_PORT 8899


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pb_init_clicked()
{
        int ret = aubo_robot_namespace::InterfaceCallSuccCode;

        /** Interface call: login ***/
        ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
        if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
        {

            qDebug() << "login successful.";

        }
        else
        {
            qDebug() <<"login failed."<< ret ;

        }


}

void Widget::on_pb_startup_clicked()
{

        int ret = aubo_robot_namespace::InterfaceCallSuccCode;

        aubo_robot_namespace::ROBOT_SERVICE_STATE result;

        //Tool dynamics parameter
        aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;

        memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

        ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**Tool dynamics parameter**/,
                                                   6        /*Collision level*/,
                                                   true     /*Whether to allow reading poses defaults to true*/,
                                                   true,    /*Leave the default to true */
                                                   1000,    /*Leave the default to 1000 */
                                                   result); /*Robot arm initialization*/

        qDebug() << "Robot arm startup result is" << result;

        if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
        {
            qDebug() << "Robot arm initialization succeeded.";


        }
        else
        {
            qDebug() << "Robot arm initialization failed." << ret ;

        }
}


void Widget::on_pb_global_move_init_clicked()
{
        int ret = aubo_robot_namespace::InterfaceCallSuccCode;

        ret = robotService.robotServiceInitGlobalMoveProfile();

        if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
        {
            qDebug() << "Robot Move global initialization succeeded.";
        }
        else
        {
            qDebug() << "Robot Robot Move global initialization failed." << ret ;
        }
}


void Widget::on_pb_speed_joints_speed_clicked()
{

        int ret = aubo_robot_namespace::InterfaceCallSuccCode;

        aubo_robot_namespace::JointVelcAccParam jointMaxVelc;

        jointMaxVelc.jointPara[0] = ui->le_joint_velc->text().toDouble()/180.0*M_PI;
        jointMaxVelc.jointPara[1] = ui->le_joint_velc->text().toDouble()/180.0*M_PI;
        jointMaxVelc.jointPara[2] = ui->le_joint_velc->text().toDouble()/180.0*M_PI;
        jointMaxVelc.jointPara[3] = ui->le_joint_velc->text().toDouble()/180.0*M_PI;
        jointMaxVelc.jointPara[4] = ui->le_joint_velc->text().toDouble()/180.0*M_PI;
        jointMaxVelc.jointPara[5] = ui->le_joint_velc->text().toDouble()/180.0*M_PI;

        ret = robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

        if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
        {
            qDebug() << "set joint Velc succeeded.";
        }
        else
        {
            qDebug() << "set joint Velc failed." << ret ;
        }
}

void Widget::on_pb_speed_joints_acc_clicked()
{
        int ret = aubo_robot_namespace::InterfaceCallSuccCode;

        aubo_robot_namespace::JointVelcAccParam jointMaxAcc;

        jointMaxAcc.jointPara[0] = ui->le_joint_acc->text().toDouble() /180.0*M_PI;
        jointMaxAcc.jointPara[1] = ui->le_joint_acc->text().toDouble() /180.0*M_PI;
        jointMaxAcc.jointPara[2] = ui->le_joint_acc->text().toDouble() /180.0*M_PI;
        jointMaxAcc.jointPara[3] = ui->le_joint_acc->text().toDouble() /180.0*M_PI;
        jointMaxAcc.jointPara[4] = ui->le_joint_acc->text().toDouble() /180.0*M_PI;
        jointMaxAcc.jointPara[5] = ui->le_joint_acc->text().toDouble() /180.0*M_PI;

        ret = robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

        if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
        {
            qDebug() << "set joint acc succeeded.";
        }
        else
        {
            qDebug() << "set joint acc failed." << ret ;
        }
}


void Widget::on_pb_speed_end_speed_clicked()
{
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    double lineMoveMaxVelc;
    lineMoveMaxVelc = ui->le_end_speed->text().toDouble() / 1000.0;   //Units m/s
    ret = robotService.robotServiceSetGlobalMoveEndMaxLineVelc(lineMoveMaxVelc);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        qDebug() << "set End LineVelc succeeded.";
    }
    else
    {
        qDebug() << "set End LineVelc failed." << ret ;
    }

    robotService.robotServiceSetGlobalMoveEndMaxAngleVelc(lineMoveMaxVelc);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        qDebug() << "set End AngleVelc succeeded.";
    }
    else
    {
        qDebug() << "set End AngleVelc failed." << ret ;
    }
}

void Widget::on_pb_speed_end_acc_clicked()
{
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    double lineMoveMaxAcc;
    lineMoveMaxAcc = ui->le_end_acc->text().toDouble() / 1000.0;   //Units m/s2
    ret = robotService.robotServiceSetGlobalMoveEndMaxLineAcc(lineMoveMaxAcc);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        qDebug() << "set End LineAcc succeeded.";
    }
    else
    {
        qDebug() << "set End LineAcc failed." << ret ;
    }

    ret = robotService.robotServiceSetGlobalMoveEndMaxAngleAcc(lineMoveMaxAcc);

    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        qDebug() << "set End AngleAcc succeeded.";
    }
    else
    {
        qDebug() << "set End AngleAcc failed." << ret ;
    }

}

void Widget::on_pb_move_joint_clicked()
{
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    double joints[aubo_robot_namespace::ARM_DOF];

    joints[0] = ui->le_joint_1->text().toDouble() / 180.0*M_PI;
    joints[1] = ui->le_joint_2->text().toDouble() / 180.0*M_PI;
    joints[2] = ui->le_joint_3->text().toDouble() / 180.0*M_PI;
    joints[3] = ui->le_joint_4->text().toDouble() / 180.0*M_PI;
    joints[4] = ui->le_joint_5->text().toDouble() / 180.0*M_PI;
    joints[5] = ui->le_joint_6->text().toDouble() / 180.0*M_PI;

    ret = robotService.robotServiceJointMove(joints, true);

    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
         qDebug() << "Movement to waypoint  failed.　ret:" << ret;
    }
    else
    {
         qDebug() <<"Movement to waypoint successed.　ret:" << ret;
    }
}

void Widget::on_pb_IK_clicked()
{
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    aubo_robot_namespace::wayPoint_S ref_point;

    robotService.robotServiceGetCurrentWaypointInfo(ref_point);

    aubo_robot_namespace::Rpy rpy_IK_point;

    aubo_robot_namespace::Ori ori_IK_point;

    rpy_IK_point.rx = ui->le_ori_rx->text().toDouble() / 180.0*M_PI;
    rpy_IK_point.ry = ui->le_ori_ry->text().toDouble() / 180.0*M_PI;
    rpy_IK_point.rz = ui->le_ori_rz->text().toDouble() / 180.0*M_PI;

    robotService.RPYToQuaternion(rpy_IK_point,ori_IK_point);

    aubo_robot_namespace::Pos pos_IK_point;

    pos_IK_point.x = ui->le_pos_x->text().toDouble();
    pos_IK_point.y = ui->le_pos_y->text().toDouble();
    pos_IK_point.z = ui->le_pos_z->text().toDouble();

    aubo_robot_namespace::wayPoint_S wp_IK_joint;

    ret = robotService.robotServiceRobotIk(ref_point.jointpos,pos_IK_point,ori_IK_point,wp_IK_joint);

    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
         qDebug() << "Ik  failed.　ret:" << ret;
    }

    else
    {
         qDebug() <<"Ik successed.　ret:" << ret;
         ui->le_IK_joint_1->setText(QString::number(wp_IK_joint.jointpos[0] * 180.0/M_PI));
         ui->le_IK_joint_2->setText(QString::number(wp_IK_joint.jointpos[1] * 180.0/M_PI));
         ui->le_IK_joint_3->setText(QString::number(wp_IK_joint.jointpos[2] * 180.0/M_PI));
         ui->le_IK_joint_4->setText(QString::number(wp_IK_joint.jointpos[3] * 180.0/M_PI));
         ui->le_IK_joint_5->setText(QString::number(wp_IK_joint.jointpos[4] * 180.0/M_PI));
         ui->le_IK_joint_6->setText(QString::number(wp_IK_joint.jointpos[5] * 180.0/M_PI));
    }

}

void Widget::on_pb_update_clicked()
{
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    aubo_robot_namespace::wayPoint_S current_point;

    aubo_robot_namespace::Rpy current_rpy;

    ret = robotService.robotServiceGetCurrentWaypointInfo(current_point);

    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
         qDebug() << "Get Current point failed.　ret:" << ret;
    }
    else
    {
         qDebug() << "Get Current point successed.　ret:" << ret;
    }

    ui->le_current_point_x->setText(QString::number(current_point.cartPos.position.x));
    ui->le_current_point_y->setText(QString::number(current_point.cartPos.position.y));
    ui->le_current_point_z->setText(QString::number(current_point.cartPos.position.z));

    robotService.quaternionToRPY(current_point.orientation,current_rpy);

    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
         qDebug() << " quaternionToRPY failed.　ret:" << ret;
    }
    else
    {
         qDebug() << " quaternionToRPY successed.　ret:" << ret;
    }


    ui->le_current_point_Rx->setText(QString::number(current_rpy.rx * 180.0/M_PI));
    ui->le_current_point_Ry->setText(QString::number(current_rpy.ry * 180.0/M_PI));
    ui->le_current_point_Rz->setText(QString::number(current_rpy.rz * 180.0/M_PI));

    ui->le_current_joint_1->setText(QString::number(current_point.jointpos[0]* 180.0/M_PI));
    ui->le_current_joint_2->setText(QString::number(current_point.jointpos[1]* 180.0/M_PI));
    ui->le_current_joint_3->setText(QString::number(current_point.jointpos[2]* 180.0/M_PI));
    ui->le_current_joint_4->setText(QString::number(current_point.jointpos[3]* 180.0/M_PI));
    ui->le_current_joint_5->setText(QString::number(current_point.jointpos[4]* 180.0/M_PI));
    ui->le_current_joint_6->setText(QString::number(current_point.jointpos[5]* 180.0/M_PI));

}

void Widget::on_pb_move_to_IK_point_clicked()
{
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    double IK_point[6] = {ui->le_IK_joint_1->text().toDouble() / 180.0*M_PI,
                          ui->le_IK_joint_2->text().toDouble() / 180.0*M_PI,
                          ui->le_IK_joint_3->text().toDouble() / 180.0*M_PI,
                          ui->le_IK_joint_4->text().toDouble() / 180.0*M_PI,
                          ui->le_IK_joint_5->text().toDouble() / 180.0*M_PI,
                          ui->le_IK_joint_6->text().toDouble() / 180.0*M_PI
                         };

    ret = robotService.robotServiceJointMove(IK_point, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
         qDebug() << "Movement to waypoint  failed.　ret:" << ret;
    }
    else
    {
         qDebug() <<"Movement to waypoint successed.　ret:" << ret;
    }
}
