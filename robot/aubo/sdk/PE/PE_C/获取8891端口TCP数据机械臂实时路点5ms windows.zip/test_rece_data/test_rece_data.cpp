﻿//#include "pch.h"//VS2019，删掉该行
#include<iostream>
#include<winsock.h>
#include<string.h>

#pragma comment(lib,"ws2_32.lib")
using namespace std;
void initialization();

char* strstr_1;
char* strstr_2;

SYSTEMTIME sys;




int main() {
	//定义长度变量
	int send_len = 0;
	int recv_len = 0;
	//定义发送缓冲区和接受缓冲区
	char send_buf[2000];
	char recv_buf[1550];

	char joint_get1[9] = "jointPos";
	char joint_get2[17] = "jointTagCurrentI";

	char essid[150] = { 0 };

	//char joint_data[] = ;

	//定义服务端套接字，接受请求套接字
	SOCKET s_server;
	//服务端地址客户端地址
	SOCKADDR_IN server_addr;
	initialization();
	//填充服务端信息
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.S_un.S_addr = inet_addr("192.168.10.100");
	server_addr.sin_port = htons(8891);
	//创建套接字
	s_server = socket(AF_INET, SOCK_STREAM, 0);
	if (connect(s_server, (SOCKADDR*)&server_addr, sizeof(SOCKADDR)) == SOCKET_ERROR) {
		cout << "服务器连接失败！" << endl;
		WSACleanup();
	}
	else {
		cout << "服务器连接成功！" << endl;
	}

	int count = 1000;


	//发送,接收数据
	while (count --) {
		/*cout << "请输入发送信息:";
		cin >> send_buf;
		send_len = send(s_server, send_buf, 100, 0);
		if (send_len < 0) {
			cout << "发送失败！" << endl;
			break;
		}*/
		recv_len = recv(s_server, recv_buf, 1550, 0);
		if (recv_len < 0) {
			cout << "接受失败！" << endl;
			break;
		}
		else {
			
			//cout << "服务端信息:" << recv_buf << endl;

			strstr_1 = strstr(recv_buf, joint_get1);
			strstr_2 = strstr(recv_buf, joint_get2);

			memcpy(essid, strstr_1 + 11, (strstr_2 - 1) - (strstr_1 + 13));  //essid存的就是我们想要截取的字符串：tps，拷贝temp_p + 1的内容，即“ 后t开始的位置，end_p - 1是\n前一位：s，temp_p + 1是”的后一位：t，(end_p - 1) - (temp_p + 1)是拷贝他们之间的字节数
			
			cout << essid << endl;

			//printf("%d\n", count);
			//printf("%s-----%d\n", essid,count);

			//GetLocalTime(&sys);
			//printf("%s,%4d/%02d/%02d %02d:%02d:%02d.%03d 星期%1d\n", essid,sys.wYear, sys.wMonth, sys.wDay, sys.wHour, sys.wMinute, sys.wSecond, sys.wMilliseconds, sys.wDayOfWeek);

		}

	}
	//关闭套接字
	closesocket(s_server);
	//释放DLL资源
	WSACleanup();
	return 0;
}
void initialization() {
	//初始化套接字库
	WORD w_req = MAKEWORD(2, 2);//版本号
	WSADATA wsadata;
	int err;
	err = WSAStartup(w_req, &wsadata);
	if (err != 0) {
		cout << "初始化套接字库失败！" << endl;
	}
	else {
		cout << "初始化套接字库成功！" << endl;
	}
	//检测版本号
	if (LOBYTE(wsadata.wVersion) != 2 || HIBYTE(wsadata.wHighVersion) != 2) {
		cout << "套接字库版本号不符！" << endl;
		WSACleanup();
	}
	else {
		cout << "套接字库版本正确！" << endl;
	}
	//填充服务端地址信息

}