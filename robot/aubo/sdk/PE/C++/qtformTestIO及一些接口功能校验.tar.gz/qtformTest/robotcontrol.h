﻿#ifndef ROBOTCONTROL_H
#define ROBOTCONTROL_H


#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

//#define ROBOT_ADDR "127.0.0.
#define ROBOT_ADDR "192.168.31.66"
#define ROBOT_PORT 8899

#define MAX_LINE 4200


#include <QThread>
#include <thread>



#include "AuboRobotMetaType.h"
#include "serviceinterface.h"


class robotControl
{
public:
    robotControl();

    bool initRobot();
public:
    bool example_login(const char * addr, int port);



    void printRoadPoint(aubo_robot_namespace::wayPoint_S *wayPoint);


    void con_robotMove();
    void robotMove();
    void con_robotStop();
    void robotStop();
    void con_robotFastStop();
    void robotFastStop();

    void con_ioChangeByName(std::string ioName);
    void con_toolIoChangeByName(std::string ioName);

    double con_getIoState(std::string ioName);
    double con_getToolIoState(std::string ioName);

    double robotGetIoState(std::string ioName);

    void robotSetIo(std::string ioName, bool ioState);

    double robotGetToolIoState(std::string ioName);
    void robotSetToolIo(std::string ioName, bool ioState);

    int interfaceUseResCode = 0;

private:
    ServiceInterface robotService;

};

#endif // ROBOTCONTROL_H
