﻿#include "form.h"
#include "ui_form.h"

Form::Form(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Form)
{
    ui->setupUi(this);

    robot = new robotControl();

    ui->ioName_text->setText("U_DO_00");
    on_getIoState_btn_clicked();
}

Form::~Form()
{
    delete ui;
}

void Form::on_initBtn_clicked()
{
    robot->initRobot();
}


void Form::on_getPoseBtn_clicked()
{
}


void Form::on_inverseBtn_clicked()
{

}


void Form::on_jointMoveBtn_clicked()
{
    robot->con_robotMove();
}


void Form::on_moveStop_btn_clicked()
{
    robot->con_robotStop();
}


void Form::on_moveFastStop_btn_clicked()
{
    robot->con_robotFastStop();
}


void Form::on_jointMoveBtn_2_pressed()
{

}


void Form::on_jointMoveBtn_2_released()
{
    robot->con_robotFastStop();
}


void Form::on_ioType_combox_currentIndexChanged(const QString &arg1)
{
    qDebug() << "当前选择项为: " << arg1;
    curIoType = arg1;
}

void Form::on_ioName_text_editingFinished()
{
    curIoName = ui->ioName_text->text().toStdString();
}

void Form::on_setIoEx_btn_clicked()
{
    if(curIoType == "TOOL"){
        robot->con_toolIoChangeByName(curIoName);
    }else{

        robot->con_ioChangeByName(curIoName);
    }
    QThread::sleep(1);
    this->on_getIoState_btn_clicked();
}

void Form::on_getIoState_btn_clicked()
{
    if(curIoType == "TOOL"){
        curIoState = robot->con_getToolIoState(curIoName);
    }else{
        curIoState = robot->con_getIoState(curIoName);
    }
    if(curIoState == 0.0){
        ui->ioState_label->setText("OFF");
    }else{
        ui->ioState_label->setText("ON");
    }

}
