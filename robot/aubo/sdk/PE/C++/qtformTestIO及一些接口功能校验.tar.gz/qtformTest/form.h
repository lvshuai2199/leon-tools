﻿#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QMessageBox>
#include <QDebug>

#include "robotcontrol.h"

namespace Ui {
class Form;
}

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

private slots:
    void on_initBtn_clicked();

    void on_getPoseBtn_clicked();

    void on_inverseBtn_clicked();

    void on_jointMoveBtn_clicked();

    void on_moveStop_btn_clicked();

    void on_moveFastStop_btn_clicked();

    void on_jointMoveBtn_2_pressed();

    void on_jointMoveBtn_2_released();


    void on_ioType_combox_currentIndexChanged(const QString &arg1);

    void on_ioName_text_editingFinished();

    void on_setIoEx_btn_clicked();

    void on_getIoState_btn_clicked();

private:
    Ui::Form *ui;

    robotControl *robot;

    QString curIoType = "IO";
    std::string curIoName;
    double curIoState = 0.0;
};

#endif // FORM_H
