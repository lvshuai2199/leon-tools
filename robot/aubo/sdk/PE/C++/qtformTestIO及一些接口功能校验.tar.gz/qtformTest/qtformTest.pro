#-------------------------------------------------
#
# Project created by QtCreator 2024-06-03T09:53:17
#
#-------------------------------------------------

QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = qtformTest
TEMPLATE = app


SOURCES += main.cpp\
    form.cpp\
robotcontrol.cpp

HEADERS  += form.h\
robotcontrol.h

FORMS    +=  form.ui

unix{
    #32bit OS
    contains(QT_ARCH, i386){

        CONFIG += c++11

        DEFINES += _GLIBCXX_USE_CXX11_ABI=0

        INCLUDEPATH += $$PWD/dependents/robotSDK/inc

        LIBS += -L$$PWD/dependents/robotSDK/lib/linux_x32/ -lauborobotcontroller

        LIBS += -lpthread

    }
    #64bit OS
    contains(QT_ARCH, x86_64){

        CONFIG += c++11

        DEFINES += _GLIBCXX_USE_CXX11_ABI=0

        INCLUDEPATH += $$PWD/dependents/robotSDK/inc

        LIBS += -L$$PWD/dependents/log4cplus/linux_x64/lib/ -llog4cplus

        LIBS += -L$$PWD/dependents/robotSDK/lib/linux_x64/ -lauborobotcontroller

        LIBS += -lpthread
    }
}
