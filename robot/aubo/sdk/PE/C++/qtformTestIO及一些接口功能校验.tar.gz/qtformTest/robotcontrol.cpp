﻿#include "robotcontrol.h"

robotControl::robotControl() {

}

bool robotControl::initRobot()
{
    // this->example_login()

    // robotControl *robot = new robotControl();

    this->example_login(ROBOT_ADDR, ROBOT_PORT);


    return true;
}


//void robotControl::getPoseAndPrint()
//{
//    aubo_robot_namespace::wayPoint_S curWayPoint;
//    robotService.robotServiceGetCurrentWaypointInfo(&curWayPoint);

////    printRoadPoint(&curWayPoint);

//}


/********************************************************************
    function:	example_login
    purpose :	登陆机械臂
    param   :	rshd 输出上下文句柄
                addr 机械臂服务器地址
                port 机械臂服务器端口
    return  :	true 成功 false 失败
*********************************************************************/
bool robotControl::example_login( const char * addr, int port)
{

    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: login ***/
    ret = robotService.robotServiceLogin(addr, port, "aubo", "123456");
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cout<<"login successful."<<std::endl;
    }
    else
    {
        std::cerr<<"login failed."<<std::endl;
    }


//    /** If the real robot arm is connected, the arm needs to be initialized.　**/
//    aubo_robot_namespace::ROBOT_SERVICE_STATE result;

//    //Tool dynamics parameter
//    aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
//    memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

//    ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**Tool dynamics parameter**/,
//                                               6        /*Collision level*/,
//                                               true     /*Whether to allow reading poses defaults to true*/,
//                                               true,    /*Leave the default to true */
//                                               1000,    /*Leave the default to 1000 */
//                                               result); /*Robot arm initialization*/
//    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
//    {
//        std::cout<<"Robot arm initialization succeeded."<<std::endl;
//    }
//    else
//    {
//        std::cerr<<"Robot arm initialization failed."<<std::endl;
//    }
}


void robotControl::printRoadPoint(aubo_robot_namespace::wayPoint_S *wayPoint)
{
    std::cout << "***************************************************" << std::endl;
    std::cout << "坐标 pos" << std::endl;
    std::cout << wayPoint->cartPos.position.x << std::endl;
    std::cout << wayPoint->cartPos.position.y << std::endl;
    std::cout << wayPoint->cartPos.position.z << std::endl;

    std::cout << "姿态（四元数）ori" << std::endl;
    std::cout << wayPoint->orientation.w << std::endl;
    std::cout << wayPoint->orientation.x << std::endl;
    std::cout << wayPoint->orientation.y << std::endl;
    std::cout << wayPoint->orientation.z << std::endl;

    std::cout << "关节角 joint" << std::endl;
    for(int i = 0 ; i< 6; i++){
         std::cout << wayPoint->jointpos[i] * 180 /M_PI<< std::endl;
    }
}

void robotControl::con_robotMove()
{
    std::thread weaveThread(&robotControl::robotMove, this);
    weaveThread.detach();

}

void robotControl::robotMove()
{
    int ret = aubo_robot_namespace::InterfaceCallSuccCode;

    /** Interface call: login ***/
//    ret = robotService.robotServiceLogin(SERVER_HOST, SERVER_PORT, "aubo", "123456");
//    if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
//    {
//        std::cout<<"login successful."<<std::endl;
//    }
//    else
//    {
//        std::cerr<<"login failed."<<std::endl;
//    }

     std::cout<<"Robot arm initialization....."<<std::endl;


     /** If the real robot arm is connected, the arm needs to be initialized.**/
     aubo_robot_namespace::ROBOT_SERVICE_STATE result;

     //Tool dynamics parameter
     aubo_robot_namespace::ToolDynamicsParam toolDynamicsParam;
     memset(&toolDynamicsParam, 0, sizeof(toolDynamicsParam));

     ret = robotService.rootServiceRobotStartup(toolDynamicsParam/**Tool dynamics parameter**/,
                                                6        /*Collision level*/,
                                                true     /*Whether to allow reading poses defaults to true*/,
                                                true,    /*Leave the default to true */
                                                1000,    /*Leave the default to 1000 */
                                                result); /*Robot arm initialization*/
     if(ret == aubo_robot_namespace::InterfaceCallSuccCode)
     {
         std::cout<<"Robot arm initialization succeeded."<<std::endl;
     }
     else
     {
         std::cerr<<"Robot arm initialization failed."<<std::endl;
     }

    /** Business block **/
    /** Interface call: Initialize motion properties ***/
    robotService.robotServiceInitGlobalMoveProfile();

    /** Interface call: Set the maximum acceleration of the articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxAcc;
    jointMaxAcc.jointPara[0] = 50.0/180.0*M_PI;//50
    jointMaxAcc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxAcc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxAcc(jointMaxAcc);

    /** Interface call: set the maximum speed of articulated motion ***/
    aubo_robot_namespace::JointVelcAccParam jointMaxVelc;
    jointMaxVelc.jointPara[0] = 50.0/180.0*M_PI;//50
    jointMaxVelc.jointPara[1] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[2] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[3] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[4] = 50.0/180.0*M_PI;
    jointMaxVelc.jointPara[5] = 50.0/180.0*M_PI;   //The interface requires the unit to be radians
    robotService.robotServiceSetGlobalMoveJointMaxVelc(jointMaxVelc);

    /** Robot arm movement to zero posture **/
    double jointAngle[aubo_robot_namespace::ARM_DOF] = {0};



    std::cout<<"Calling the motion function"<<std::endl;
    ret = robotService.robotServiceJointMove(jointAngle, true);
    if(ret != aubo_robot_namespace::InterfaceCallSuccCode)
    {
        std::cerr<<"Movement to zero posture failure.　ret:"<<ret<<std::endl;
    }
}

void robotControl::con_robotStop()
{
    int res =     robotService.robotMoveStop();
    std::cerr<<"con_robotStop res!"<< res << std::endl;

    std::cerr<<"con_robotStop res!"<< res << std::endl;
}

void robotControl::robotStop()
{
    int res =     robotService.robotMoveStop();
    std::cerr<<"con_robotStop res!"<< res << std::endl;

    std::cerr<<"con_robotStop res!"<< res << std::endl;
}

void robotControl::con_robotFastStop()
{
    int res =     robotService.robotMoveFastStop();

    std::cerr<<"con_robotFastStop res!"<< res << std::endl;

    std::cerr<<"con_robotFastStop res!"<< res << std::endl;
}

void robotControl::con_ioChangeByName(std::string ioName)
{
    if(this->robotGetIoState(ioName) == 0){
        this->robotSetIo(ioName,true);
    }else{
        this->robotSetIo(ioName,false);
    }
}

void robotControl::con_toolIoChangeByName(std::string ioName)
{
    if(this->robotGetToolIoState(ioName) == 0){
        this->robotSetToolIo(ioName,true);
    }else{
        this->robotSetToolIo(ioName,false);
    }

}

double robotControl::con_getIoState(std::string ioName)
{
    return this->robotGetIoState(ioName);
}

double robotControl::con_getToolIoState(std::string ioName)
{
    return this->robotGetToolIoState(ioName);
}

double robotControl::robotGetIoState(std::string ioName)
{
    double ioState;
    int ret = robotService.robotServiceGetBoardIOStatus(aubo_robot_namespace::RobotBoardUserDO, ioName, ioState);
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
        std::cout << "接口调用成功!!!" << std::endl;
    }else{
        std::cout << "接口调用失败!!!" << std::endl;
    }
    return ioState;
}

// 根据名称设置
void robotControl::robotSetIo(std::string ioName, bool ioState)
{
    // 将 QString 转换为 std::string
    std::string ioNameStr = ioName;
    int ret = robotService.robotServiceSetBoardIOStatus(aubo_robot_namespace::RobotBoardUserDO,ioNameStr,ioState);
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
        std::cout << "接口调用成功!!!" << std::endl;
    }else{
        std::cout << "接口调用失败!!!" << std::endl;
    }

}

double robotControl::robotGetToolIoState(std::string ioName)
{
    double ioState;
    int ret = robotService.robotServiceGetToolIoStatus(ioName, ioState);
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
        std::cout << "接口调用成功!!!" << std::endl;
    }else{
        std::cout << "接口调用失败!!!" << std::endl;
    }
    return ioState;
}


void robotControl::robotSetToolIo(std::string ioName, bool ioState)
{
    // 将 QString 转换为 std::string
    std::string toolioNameStr = ioName;
    aubo_robot_namespace::IO_STATUS toolIoValue = aubo_robot_namespace::IO_STATUS_INVALID;
    if(ioState){
        toolIoValue = aubo_robot_namespace::IO_STATUS_VALID;
    }
    int ret = robotService.robotServiceSetToolDOStatus(toolioNameStr, toolIoValue);
    if(ret == aubo_robot_namespace::InterfaceCallSuccCode){
        std::cout << "接口调用成功!!!" << std::endl;
    }else{
        std::cout << "接口调用失败!!!" << std::endl;
    }
}
