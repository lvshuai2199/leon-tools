#include "mainwindow.h"
#include "ui_mainwindow.h"


#include <iostream>
#include "AuboRobotMetaType.h"
#include "serviceinterface.h"

#define SERVER_HOST "127.0.0.1"
#define SERVER_PORT 8899


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    std::cout << "Hello World!" << std::endl;

    ServiceInterface robotService;

    int ret = robotService.robotServiceLogin(SERVER_HOST,SERVER_PORT,"aubo","123456");
    if (ret == aubo_robot_namespace::InterfaceCallSuccCode){
        std::cout<< "登陆成功"<<std::endl;

    } else{
        std::cout<<"登录失败"<<std::endl;
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}
