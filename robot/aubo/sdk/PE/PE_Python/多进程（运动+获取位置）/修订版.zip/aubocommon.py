import time
import libpyauboi5
import logging
from logging.handlers import RotatingFileHandler
from multiprocessing import Process, Queue
import os
from math import pi
import threading
import multiprocessing

class RobotEventType:
    RobotEvent_armCanbusError = 0  # 机械臂CAN总线错误
    RobotEvent_remoteHalt = 1  # 机械臂停止
    RobotEvent_remoteEmergencyStop = 2  # 机械臂远程急停
    RobotEvent_jointError = 3  # 关节错误
    RobotEvent_forceControl = 4  # 力控制
    RobotEvent_exitForceControl = 5  # 退出力控制
    RobotEvent_softEmergency = 6  # 软急停
    RobotEvent_exitSoftEmergency = 7  # 退出软急停
    RobotEvent_collision = 8  # 碰撞
    RobotEvent_collisionStatusChanged = 9  # 碰撞状态改变
    RobotEvent_tcpParametersSucc = 10  # 工具动力学参数设置成功
    RobotEvent_powerChanged = 11  # 机械臂电源开关状态改变
    RobotEvent_ArmPowerOff = 12  # 机械臂电源关闭
    RobotEvent_mountingPoseChanged = 13  # 安装位置发生改变
    RobotEvent_encoderError = 14  # 编码器错误
    RobotEvent_encoderLinesError = 15  # 编码器线数不一致
    RobotEvent_singularityOverspeed = 16  # 奇异点超速
    RobotEvent_currentAlarm = 17  # 机械臂电流异常
    RobotEvent_toolioError = 18  # 机械臂工具端错误
    RobotEvent_robotStartupPhase = 19  # 机械臂启动阶段
    RobotEvent_robotStartupDoneResult = 20  # 机械臂启动完成结果
    RobotEvent_robotShutdownDone = 21  # 机械臂关机结果
    RobotEvent_atTrackTargetPos = 22  # 机械臂轨迹运动到位信号通知
    RobotEvent_SetPowerOnDone = 23  # 设置电源状态完成
    RobotEvent_ReleaseBrakeDone = 24  # 机械臂刹车释放完成
    RobotEvent_robotControllerStateChaned = 25  # 机械臂控制状态改变
    RobotEvent_robotControllerError = 26  # 机械臂控制错误----一般是算法规划出现问题时返回
    RobotEvent_socketDisconnected = 27  # socket断开连接
    RobotEvent_overSpeed = 28  # 超速
    RobotEvent_algorithmException = 29  # 机械臂算法异常
    RobotEvent_boardIoPoweron = 30  # 外部上电信号
    RobotEvent_boardIoRunmode = 31  # 联动/手动
    RobotEvent_boardIoPause = 32  # 外部暂停信号
    RobotEvent_boardIoStop = 33  # 外部停止信号
    RobotEvent_boardIoHalt = 34  # 外部关机信号
    RobotEvent_boardIoEmergency = 35  # 外部急停信号
    RobotEvent_boardIoRelease_alarm = 36  # 外部报警解除信号
    RobotEvent_boardIoOrigin_pose = 37  # 外部回原点信号
    RobotEvent_boardIoAutorun = 38  # 外部自动运行信号
    RobotEvent_safetyIoExternalEmergencyStope = 39  # 外部急停输入01
    RobotEvent_safetyIoExternalSafeguardStope = 40  # 外部保护停止输入02
    RobotEvent_safetyIoReduced_mode = 41  # 缩减模式输入
    RobotEvent_safetyIoSafeguard_reset = 42  # 防护重置
    RobotEvent_safetyIo3PositionSwitch = 43  # 三态开关1
    RobotEvent_safetyIoOperationalMode = 44  # 操作模式
    RobotEvent_safetyIoManualEmergencyStop = 45  # 示教器急停01
    RobotEvent_safetyIoSystemStop = 46  # 系统停止输入
    RobotEvent_alreadySuspended = 47  # 机械臂暂停
    RobotEvent_alreadyStopped = 48  # 机械臂停止
    RobotEvent_alreadyRunning = 49  # 机械臂运行
    RobotEvent_MoveEnterStopState = 1300  # 运动进入到stop阶段
    RobotEvent_None = 999999

    # 非错误事件
    NoError = (RobotEvent_forceControl,
               RobotEvent_exitForceControl,
               RobotEvent_tcpParametersSucc,
               RobotEvent_powerChanged,
               RobotEvent_mountingPoseChanged,
               RobotEvent_robotStartupPhase,
               RobotEvent_robotStartupDoneResult,
               RobotEvent_robotShutdownDone,
               RobotEvent_SetPowerOnDone,
               RobotEvent_ReleaseBrakeDone,
               RobotEvent_atTrackTargetPos,
               RobotEvent_robotControllerStateChaned,
               RobotEvent_robotControllerError,
               RobotEvent_algorithmException,
               RobotEvent_alreadyStopped,
               RobotEvent_alreadyRunning,
               RobotEvent_boardIoPoweron,
               RobotEvent_boardIoRunmode,
               RobotEvent_boardIoPause,
               RobotEvent_boardIoStop,
               RobotEvent_boardIoHalt,
               RobotEvent_boardIoRelease_alarm,
               RobotEvent_boardIoOrigin_pose,
               RobotEvent_boardIoAutorun,
               RobotEvent_safetyIoExternalEmergencyStope,
               RobotEvent_safetyIoExternalSafeguardStope,
               RobotEvent_safetyIoReduced_mode,
               RobotEvent_safetyIoSafeguard_reset,
               RobotEvent_safetyIo3PositionSwitch,
               RobotEvent_safetyIoOperationalMode,
               RobotEvent_safetyIoManualEmergencyStop,
               RobotEvent_safetyIoSystemStop,
               RobotEvent_alreadySuspended,
               RobotEvent_alreadyStopped,
               RobotEvent_alreadyRunning,
               RobotEvent_MoveEnterStopState
               )

    UserPostEvent = (RobotEvent_robotControllerError,
                     RobotEvent_safetyIoExternalSafeguardStope,
                     RobotEvent_safetyIoSystemStop
                     )
    ClearErrorEvent = (RobotEvent_armCanbusError,
                       RobotEvent_remoteEmergencyStop,
                       RobotEvent_jointError,
                       RobotEvent_collision,
                       RobotEvent_collisionStatusChanged,
                       RobotEvent_encoderError,
                       RobotEvent_encoderLinesError,
                       RobotEvent_currentAlarm,
                       RobotEvent_softEmergency,
                       RobotEvent_exitSoftEmergency
                       )

    def __init__(self):
        pass


class RobotErrorType:
    RobotError_SUCC = 0  # 无错误
    RobotError_Base = 2000
    RobotError_RSHD_INIT_FAILED = RobotError_Base + 1  # 库初始化失败
    RobotError_RSHD_UNINIT = RobotError_Base + 2  # 库未初始化
    RobotError_NoLink = RobotError_Base + 3  # 无链接
    RobotError_Move = RobotError_Base + 4  # 机械臂移动错误
    RobotError_ControlError = RobotError_Base + RobotEventType.RobotEvent_robotControllerError
    RobotError_LOGIN_FAILED = RobotError_Base + 5  # 机械臂登录失败
    RobotError_NotLogin = RobotError_Base + 6  # 机械臂未登录
    RobotError_ERROR_ARGS = RobotError_Base + 7  # 参数错误

    def __init__(self):
        pass


class RobotEvent:
    def __init__(self, event_type=RobotEventType.RobotEvent_None, event_code=0, event_msg=''):
        self.event_type = event_type
        self.event_code = event_code
        self.event_msg = event_msg


# noinspection SpellCheckingInspection
class RobotError(Exception):
    def __init__(self, error_type=RobotErrorType.RobotError_SUCC, error_code=0, error_msg=''):
        self.error_type = error_type
        self.error_cdoe = error_code
        self.error_msg = error_msg

    def __str__(self):
        return "RobotError type{0} code={1} msg={2}".format(self.error_type, self.error_cdoe, self.error_msg)


class RobotDefaultParameters:
    # 缺省的动力学参数
    tool_dynamics = {"position": (0.0, 0.0, 0.0), "payload": 1.0, "inertia": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)}

    # 缺省碰撞等级
    collision_grade = 6

    def __init__(self):
        pass

    def __str__(self):
        return "Robot Default parameters, tool_dynamics:{0}, collision_grade:{1}".format(self.tool_dynamics,
                                                                                         self.collision_grade)


class RobotMoveTrackType:
    # 圆弧
    ARC_CIR = 2
    # 轨迹
    CARTESIAN_MOVEP = 3
    # 以下四种三阶样条插值曲线都有起始和结束点加速度不连续的情况,不适合与新关节驱动版本
    # 三次样条插值(过控制点),自动优化轨迹运行时间,目前不支持姿态变化
    CARTESIAN_CUBICSPLINE = 4
    # 需要设定三次均匀B样条插值(过控制点)的时间间隔,目前不支持姿态变化
    CARTESIAN_UBSPLINEINTP = 5
    # 三阶样条插值曲线
    JIONT_CUBICSPLINE = 6
    # 可用于轨迹回放
    JOINT_UBSPLINEINTP = 7

    def __init__(self):
        pass


class RobotIOType:
    # 控制柜IO
    ControlBox_DI = 0
    ControlBox_DO = 1
    ControlBox_AI = 2
    ControlBox_AO = 3
    # 用户IO
    User_DI = 4
    User_DO = 5
    User_AI = 6
    User_AO = 7

    def __init__(self):
        pass


class RobotToolIoName:
    tool_io_0 = "T_DI/O_00"
    tool_io_1 = "T_DI/O_01"
    tool_io_2 = "T_DI/O_02"
    tool_io_3 = "T_DI/O_03"

    tool_ai_0 = "T_AI_00"
    tool_ai_1 = "T_AI_01"

    def __init__(self):
        pass


class RobotUserIoName:
    # 控制柜用户ＤＩ
    user_di_00 = "U_DI_00"
    user_di_01 = "U_DI_01"
    user_di_02 = "U_DI_02"
    user_di_03 = "U_DI_03"
    user_di_04 = "U_DI_04"
    user_di_05 = "U_DI_05"
    user_di_06 = "U_DI_06"
    user_di_07 = "U_DI_07"
    user_di_10 = "U_DI_10"
    user_di_11 = "U_DI_11"
    user_di_12 = "U_DI_12"
    user_di_13 = "U_DI_13"
    user_di_14 = "U_DI_14"
    user_di_15 = "U_DI_15"
    user_di_16 = "U_DI_16"
    user_di_17 = "U_DI_17"

    # 控制柜用户ＤＯ
    user_do_00 = "U_DO_00"
    user_do_01 = "U_DO_01"
    user_do_02 = "U_DO_02"
    user_do_03 = "U_DO_03"
    user_do_04 = "U_DO_04"
    user_do_05 = "U_DO_05"
    user_do_06 = "U_DO_06"
    user_do_07 = "U_DO_07"
    user_do_10 = "U_DO_10"
    user_do_11 = "U_DO_11"
    user_do_12 = "U_DO_12"
    user_do_13 = "U_DO_13"
    user_do_14 = "U_DO_14"
    user_do_15 = "U_DO_15"
    user_do_16 = "U_DO_16"
    user_do_17 = "U_DO_17"

    # 控制柜模拟量ＩＯ
    user_ai_00 = "VI0"
    user_ai_01 = "VI1"
    user_ai_02 = "VI2"
    user_ai_03 = "VI3"

    user_ao_00 = "VO0"
    user_ao_01 = "VO1"
    user_ao_02 = "VO2"
    user_ao_03 = "VO3"

    def __init__(self):
        pass


class RobotStatus:
    # 机械臂当前停止
    Stopped = 0
    # 机械臂当前运行
    Running = 1
    # 机械臂当前暂停
    Paused = 2
    # 机械臂当前恢复
    Resumed = 3

    def __init__(self):
        pass


class RobotRunningMode:
    # 机械臂仿真模式
    RobotModeSimulator = 0
    # 机械臂真实模式
    RobotModeReal = 1

    def __init__(self):
        pass


class RobotToolPowerType:
    OUT_0V = 0
    OUT_12V = 1
    OUT_24V = 2

    def __init__(self):
        pass


class RobotToolIoAddr:
    TOOL_DIGITAL_IO_0 = 0
    TOOL_DIGITAL_IO_1 = 1
    TOOL_DIGITAL_IO_2 = 2
    TOOL_DIGITAL_IO_3 = 3

    def __init__(self):
        pass


class RobotCoordType:
    # 基座坐标系
    Robot_Base_Coordinate = 0
    # 末端坐标系
    Robot_End_Coordinate = 1
    # 用户坐标系
    Robot_World_Coordinate = 2

    def __init__(self):
        pass


class RobotCoordCalMethod:
    CoordCalMethod_xOy = 0
    CoordCalMethod_yOz = 1
    CoordCalMethod_zOx = 2
    CoordCalMethod_xOxy = 3
    CoordCalMethod_xOxz = 4
    CoordCalMethod_yOyx = 5
    CoordCalMethod_yOyz = 6
    CoordCalMethod_zOzx = 7
    CoordCalMethod_zOzy = 8

    def __init__(self):
        pass


class RobotToolDigitalIoDir:
    # 输入
    IO_IN = 0
    # 输出
    IO_OUT = 1

    def __init__(self):
        pass


class Auboi5Robot:
    # 客户端个数
    __client_count = 0

    def __init__(self):
        self.rshd = -1
        self.connected = False
        self.last_error = RobotError()
        self.last_event = RobotEvent()
        self.atTrackTargetPos = False
        Auboi5Robot.__client_count += 1

    # 机械臂断电
    def __del__(self):
        Auboi5Robot.__client_count -= 1
        self.uninitialize()
        print("client_count={0}".format(Auboi5Robot.__client_count))

    # 机械臂连接情况
    def __str__(self):
        return "RSHD={0}, connected={1}".format(self.rshd, self.connected)

    # 获取系统当前时间(输出系统当前时间字符串)
    @staticmethod
    def get_local_time():
        return time.strftime("%b %d %Y %H:%M:%S", time.localtime(time.time()))

    # 机械臂事件
    def robot_event_callback(self, event):
        print("event={0}".format(event))
        if event['type'] not in RobotEventType.NoError:
            self.last_error = RobotError(event['type'], event['code'], event['content'])
        else:
            self.last_event = RobotEvent(event['type'], event['code'], event['content'])

    # 抛出异常事件
    @staticmethod
    def raise_error(error_type, error_code, error_msg):
        raise RobotError(error_type, error_code, error_msg)

    # 检查机械臂是否发生异常事件
    def check_event(self):
        if self.last_error.error_type != RobotErrorType.RobotError_SUCC:
            raise self.last_error
        if self.rshd == -1 or not self.connected:
            self.raise_error(RobotErrorType.RobotError_NoLink, 0, "no socket link")

    # 初始化机械臂控制库(成功返回: RobotError.RobotError_SUCC,失败返回: 其他)
    @staticmethod
    def initialize():
        result = libpyauboi5.initialize()
        if result == RobotErrorType.RobotError_SUCC:
            return RobotErrorType.RobotError_SUCC
        else:
            return RobotErrorType.RobotError_RSHD_INIT_FAILED

    # 反初始化机械臂控制库(成功返回: RobotError.RobotError_SUCC,失败返回: 其他)
    @staticmethod
    def uninitialize():
        return libpyauboi5.uninitialize()

    # 创建机械臂控制上下文句柄(成功返回: RSHD)
    def create_context(self):
        self.rshd = libpyauboi5.create_context()
        return self.rshd

    # 获取机械臂当前控制上下文(上下文句柄RSHD)
    def get_context(self):
        return self.rshd

    # 链接机械臂服务器(成功返回: RobotError.RobotError_SUCC,失败返回: 其他)
    def connect(self, ip='localhost', port=8899):
        print("ip={0}, port={1}".format(ip, port))
        if self.rshd >= 0:
            if not self.connected:
                if libpyauboi5.login(self.rshd, ip, port) == 0:
                    self.connected = True
                    time.sleep(0.5)
                    return RobotErrorType.RobotError_SUCC
                else:
                    print("login failed!")
                    return RobotErrorType.RobotError_LOGIN_FAILED
            else:
                print("already connected.")
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized!!!")
            return RobotErrorType.RobotError_RSHD_UNINIT

    # 断开机械臂服务器链接(成功返回: RobotError.RobotError_SUCC,失败返回: 其他)
    def disconnect(self):
        if self.rshd >= 0 and self.connected:
            libpyauboi5.logout(self.rshd)
            self.connected = False
            time.sleep(0.5)
            return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 启动机械臂(collision：碰撞等级范围(0~10),tool_dynamics:运动学参数(位置，负载，量))
    def robot_startup(self, collision=RobotDefaultParameters.collision_grade,
                      tool_dynamics=RobotDefaultParameters.tool_dynamics):
        # 检查机械臂是否发生异常事件
        self.check_event()
        if self.rshd >= 0 and self.connected:
            # 启动机械臂
            result = libpyauboi5.robot_startup(self.rshd, collision, tool_dynamics)
            time.sleep(0.5)
            return result
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 关闭机械臂(成功返回: RobotError.RobotError_SUCC,失败返回: 其他)
    def robot_shutdown(self):
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.robot_shutdown(self.rshd)
            time.sleep(0.5)
            return result
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 通过回调函数获取实时事件信息(成功返回: RobotError.RobotError_SUCC,失败返回: 其他)
    def enable_robot_event(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            self.set_robot_event_callback(self.robot_event_callback)
            return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 初始化机械臂控制全局属性,调用成功后，系统会自动清理掉之前设置的用户坐标系，速度，加速度等等属性
    def init_profile(self):
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.init_global_move_profile(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置六个关节的最大加速度(joint_maxacc:六个关节的最大加速度，单位(rad/s))
    def set_joint_maxacc(self, joint_maxacc=(1.0, 1.0, 1.0, 1.0, 1.0, 1.0)):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_joint_maxacc(self.rshd, joint_maxacc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取六个关节的最大加速度(成功返回: 六个关节的最大加速度单位(rad/s^2),失败返回: None)
    def get_joint_maxacc(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_joint_maxacc(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置六个关节的最大速度(joint_maxvelc:六个关节的最大速度，单位(rad/s))
    def set_joint_maxvelc(self, joint_maxvelc=(1.0, 1.0, 1.0, 1.0, 1.0, 1.0)):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_joint_maxvelc(self.rshd, joint_maxvelc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取六个关节的最大速度(成功返回: 六个关节的最大速度(rad/s))
    def get_joint_maxvelc(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_joint_maxvelc(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂末端最大线加速度(end_maxacc:末端最大加线速度，单位(m/s^2))
    def set_end_max_line_acc(self, end_maxacc=0.1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_end_max_line_acc(self.rshd, end_maxacc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取机械臂末端最大线加速度(成功返回: 机械臂末端最大加速度，单位(m/s^2))
    def get_end_max_line_acc(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_end_max_line_acc(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂末端最大线速度(end_maxacc:末端最大线速度，单位(m/s))
    def set_end_max_line_velc(self, end_maxvelc=0.1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_end_max_line_velc(self.rshd, end_maxvelc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取机械臂末端最大线速度(成功返回: 机械臂末端最大线速度，单位(m/s))
    def get_end_max_line_velc(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_end_max_line_velc(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂末端最大角加速度(end_maxacc:末端最大加速度，单位(rad/s^2))
    def set_end_max_angle_acc(self, end_maxacc=0.1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_end_max_angle_acc(self.rshd, end_maxacc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 取机械臂末端最大角加速度(成功返回: 机械臂末端最大角加速度，单位(m/s^2))
    def get_end_max_angle_acc(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_end_max_angle_acc(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂末端最大角速度(end_maxacc:末端最大速度，单位(rad/s))
    def set_end_max_angle_velc(self, end_maxvelc=0.1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_end_max_line_velc(self.rshd, end_maxvelc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取机械臂末端最大角速度(成功返回: 机械臂末端最大速度，单位(rad/s))
    def get_end_max_angle_velc(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_end_max_line_velc(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂加加速度线加速度比率(end_maxacc:末端最大速度，单位(rad/s))
    def set_jerk_acc_ratio(self, jerk_acc=0.1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_jerk_acc_ratio(self.rshd, jerk_acc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取机械臂加加速度线加速度比率(成功返回: 机械臂末端最大速度，单位(rad/s))
    def get_jerk_acc_ratio(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_jerk_acc_ratio(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂加加速度角加速度比率(end_maxacc:末端最大速度，单位(rad/s))
    def set_jerk_angle_acc_ratio(self, jerk_angle_acc=0.1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_jerk_angle_acc_ratio(self.rshd, jerk_angle_acc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取机械臂加加速度角加速度比率(成功返回: 机械臂末端最大速度，单位(rad/s))
    def get_jerk_angle_acc_ratio(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_jerk_angle_acc_ratio(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂加加速度角加速度比率(end_maxacc:末端最大速度，单位(rad/s))
    def set_common_jerk_rotio(self, common_jerk_acc=0.1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.setset_common_jerk_rotio(self.rshd, common_jerk_acc)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 给出笛卡尔坐标值和欧拉角，机械臂轴动到目标位置和姿态(pos:位置坐标（x，y，z），单位(m),rpy：欧拉角（rx，ry，rz）,单位（度）)
    def move_to_target_in_cartesian(self, pos, rpy_xyz):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            # 度 -> 弧度
            rpy_xyz = [i / 180.0 * pi for i in rpy_xyz]
            # 欧拉角转四元数
            ori = libpyauboi5.rpy_to_quaternion(self.rshd, rpy_xyz)

            # 逆运算得关节角
            joint_radian = libpyauboi5.get_current_waypoint(self.rshd)

            ik_result = libpyauboi5.inverse_kin(self.rshd, joint_radian['joint'], pos, ori)

            logging.info("ik_result====>{0}".format(ik_result))

            # 轴动到目标位置
            result = libpyauboi5.move_joint(self.rshd, ik_result["joint"])
            if result != RobotErrorType.RobotError_SUCC:
                self.raise_error(RobotErrorType.RobotError_Move, result, "move error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 机械臂轴动(joint_radian:六个关节的关节角，单位(rad))
    def move_joint(self, joint_radian=(0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000), issync=True):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.move_joint(self.rshd, joint_radian, issync)
            if result != RobotErrorType.RobotError_SUCC:
                self.raise_error(RobotErrorType.RobotError_Move, result, "move error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 机械臂保持当前姿态直线运动( joint_radian:六个关节的关节角，单位(rad))
    def move_line(self, joint_radian=(0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000), issync=True):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.move_line(self.rshd, joint_radian, issync)
            if result != RobotErrorType.RobotError_SUCC:
                self.raise_error(RobotErrorType.RobotError_Move, result, "move error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 保持当前位置变换姿态做旋转运动(详细见说明)
    def move_rotate(self, user_coord, rotate_axis, rotate_angle):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.move_rotate(self.rshd, user_coord, rotate_axis, rotate_angle)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 清理服务器上的非在线轨迹运动数据
    def clear_offline_track(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.clear_offline_track(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 向服务器添加非在线轨迹运动路点(waypoints 非在线轨迹运动路点元祖(可包含小于3000个路点), 单位:弧度)
    def append_offline_track_waypoint(self, waypoints):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.append_offline_track_waypoint(self.rshd, waypoints)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    #向服务器添加非在线轨迹运动路点文件(路点文件全路径,路点文件的每一行包含六个关节的关节角(弧度),用逗号隔开)
    def append_offline_track_file(self, track_file):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.append_offline_track_file(self.rshd, track_file)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 通知服务器启动非在线轨迹运动
    def startup_offline_track(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.startup_offline_track(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 通知服务器停止非在线轨迹运动
    def stop_offline_track(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.stop_offline_track(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 通知服务器进入TCP2CANBUS透传模式
    def enter_tcp2canbus_mode(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.enter_tcp2canbus_mode(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 通知服务器退出TCP2CANBUS透传模式
    def leave_tcp2canbus_mode(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.leave_tcp2canbus_mode(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 透传运动路点到CANBUS(joint_radian:六个关节的关节角，单位(rad))
    def set_waypoint_to_canbus(self, joint_radian=(0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000)):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_waypoint_to_canbus(self.rshd, joint_radian)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 清除所有已经设置的全局路点
    def remove_all_waypoint(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.remove_all_waypoint(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 添加全局路点用于轨迹运动(joint_radian:六个关节的关节角，单位(rad))
    def add_waypoint(self, joint_radian=(0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000)):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.add_waypoint(self.rshd, joint_radian)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置交融半径(blend_radius:交融半径，单位(m))
    def set_blend_radius(self, blend_radius=0.01):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            if 0.01 >= blend_radius <= 0.05:
                return libpyauboi5.set_blend_radius(self.rshd, blend_radius)
            else:
                print("blend radius value range must be 0.01~0.05")
                return RobotErrorType.RobotError_ERROR_ARGS
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置圆运动圈数(circular_count:圆的运动圈数)
    # 当circular_count大于0时，机械臂进行圆运动circular_count次
    # 当circular_count等于0时，机械臂进行圆弧轨迹运动
    def set_circular_loop_times(self, circular_count=1):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_circular_loop_times(self.rshd, circular_count)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置用户坐标系(详细见说明)
    def set_user_coord(self, user_coord):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_user_coord(self.rshd, user_coord)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置基座坐标系
    def set_base_coord(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_base_coord(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 检查用户坐标系参数设置是否合理(详细见说明)
    def check_user_coord(self, user_coord):
        return libpyauboi5.check_user_coord(self.rshd, user_coord)

    # 设置基于基座标系运动偏移量(relative_pos=(x, y, z) 相对位移，单位(m),relative_ori=(w,x,y,z) 相对姿态)
    def set_relative_offset_on_base(self, relative_pos, relative_ori):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_relative_offset_on_base(self.rshd, relative_pos, relative_ori)

        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置基于用户标系运动偏移量(详细见说明)
    def set_relative_offset_on_user(self, relative_pos, relative_ori, user_coord):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_relative_offset_on_user(self.rshd, relative_pos, relative_ori, user_coord)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 取消提前到位设置
    def set_no_arrival_ahead(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.set_no_arrival_ahead(self.rshd)
            if result != 0:
                self.raise_error(RobotErrorType.RobotError_Move, result, "set no arrival ahead error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置距离模式下的提前到位距离(distance 提前到位距离 单位（米）)
    def set_arrival_ahead_distance(self, distance=0.0):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.set_arrival_ahead_distance(self.rshd, distance)
            if result != 0:
                self.raise_error(RobotErrorType.RobotError_Move, result, "set arrival ahead distance error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置时间模式下的提前到位时间(sec 提前到位时间　单位（秒）)
    def set_arrival_ahead_time(self, sec=0.0):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.set_arrival_ahead_time(self.rshd, sec)
            if result != 0:
                self.raise_error(RobotErrorType.RobotError_Move, result, "set arrival ahead time error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置距离模式下交融半径距离(blend 交融半径 单位（米）)
    def set_arrival_ahead_blend(self, distance=0.0):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.set_arrival_ahead_blend(self.rshd, distance)
            if result != 0:
                self.raise_error(RobotErrorType.RobotError_Move, result, "set arrival ahead blend error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 轨迹运动(track 轨迹类型，包括如下：圆弧运动RobotMoveTrackType.ARC_CIR,轨迹运动RobotMoveTrackType.CARTESIAN_MOVEP)
    def move_track(self, track):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            result = libpyauboi5.move_track(self.rshd, track)
            if result != 0:
                self.raise_error(RobotErrorType.RobotError_Move, result, "move error")
            else:
                return RobotErrorType.RobotError_SUCC
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 正解(六个关节角 {'joint': [1.0, 1.0, 1.0, 1.0, 1.0, 1.0])
    # 位置 'pos': [-0.06403157614989634, -0.4185973810159096, 0.816883228463401],
    # 姿态 'ori': [-0.11863209307193756, 0.3820514380931854, 0.0, 0.9164950251579285]}
    def forward_kin(self, joint_radian=(0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000)):
        if self.rshd >= 0:
            return libpyauboi5.forward_kin(self.rshd, joint_radian)
        else:
            print("RSHD uninitialized or not login!!!")
            return None
    # 逆解(joint_radian:起始点六个关节的关节角，单位(rad),pos位置(x, y, z)单位(m),ori位姿(w, x, y, z))
    # 六个关节角 {'joint': [1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
    # 位置 'pos': [-0.06403157614989634, -0.4185973810159096, 0.816883228463401],
    # 姿态 'ori': [-0.11863209307193756, 0.3820514380931854, 0.0, 0.9164950251579285]}
    def inverse_kin(self, joint_radian=(0.000000, 0.000000, 0.000000, 0.000000, 0.000000, 0.000000),
                    pos=(0.0, 0.0, 0.0), ori=(1.0, 0.0, 0.0, 0.0)):
        if self.rshd >= 0:
            return libpyauboi5.inverse_kin(self.rshd, joint_radian, pos, ori)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 基座坐标系转用户坐标系(详细见说明)
    def base_to_user(self, pos, ori, user_coord, user_tool):
        return libpyauboi5.base_to_user(self.rshd, pos, ori, user_coord, user_tool)

    # 用户坐标系转基座标系
    def user_to_base(self, pos, ori, user_coord, user_tool):
        return libpyauboi5.user_to_base(self.rshd, pos, ori, user_coord, user_tool)

    # 基坐标系转基座标得到工具末端点的位置和姿态
    # pos:基于基座标系的法兰盘中心位置信息(x, y, z)单位(m)，ori:基于基座标系的姿态信息(w, x, y, z)
    # user_tool用户工具描述，user_tool={"pos": (x, y, z), "ori": (w, x, y, z)}
    # 成功返回: 返回基于基座标系的工具末端位置位置和姿态信息{"pos": (x, y, z), "ori": (w, x, y, z)}
    def base_to_base_additional_tool(self, flange_pos, flange_ori, user_tool):
        return libpyauboi5.base_to_base_additional_tool(self.rshd, flange_pos, flange_ori, user_tool)

    # 欧拉角转四元数
    def rpy_to_quaternion(self, rpy):
        if self.rshd >= 0:
            return libpyauboi5.rpy_to_quaternion(self.rshd, rpy)
        else:
            print("RSHD uninitialized !!!")
            return None

    # 四元数转欧拉角
    def quaternion_to_rpy(self, ori):
        if self.rshd >= 0:
            return libpyauboi5.quaternion_to_rpy(self.rshd, ori)
        else:
            print("RSHD uninitialized !!!")
            return None
    # 设置末端工具参数
    # 末端工具参数： tool_end_param={"pos": (x, y, z), "ori": (w, x, y, z)}
    def set_tool_end_param(self, tool_end_param):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_tool_end_param(self.rshd, tool_end_param)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置无工具的动力学参数
    def set_none_tool_dynamics_param(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_none_tool_dynamics_param(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置工具的动力学参数
    # tool_dynamics:运动学参数
    # tool_dynamics = 位置，单位(m) ：{"position": (0.0, 0.0, 0.0),负载，单位(kg)： "payload": 1.0,惯量：          "inertia": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)}
    def set_tool_dynamics_param(self, tool_dynamics):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_tool_dynamics_param(self.rshd, tool_dynamics)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 获取末端工具参数
    # 成功返回: 运动学参数tool_dynamics = 位置，单位(m) ：{"position": (0.0, 0.0, 0.0),负载，单位(kg)： "payload": 1.0,惯量：          "inertia": (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)}
    def get_tool_dynamics_param(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_tool_dynamics_param(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置无工具运动学参数　
    def set_none_tool_kinematics_param(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_none_tool_kinematics_param(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置工具的运动学参数(末端工具参数： tool_end_param={"pos": (x, y, z), "ori": (w, x, y, z)})
    def set_tool_kinematics_param(self, tool_end_param):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_tool_kinematics_param(self.rshd, tool_end_param)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置工具的运动学参数(成功返回: 工具的运动学参数tool_end_param={"pos": (x, y, z), "ori": (w, x, y, z)})
    def get_tool_kinematics_param(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_tool_kinematics_param(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 停止机械臂运动
    def move_stop(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.move_stop(self.rshd)
        else:
            print("itialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 快速停止机械臂运动
    def move_faststop(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.move_fast(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 暂停机械臂运动
    def move_pause(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.move_pause(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 暂停后回复机械臂运动
    def move_continue(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.move_continue(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 机械臂碰撞后恢复
    def collision_recover(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.collision_recover(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取机械臂当前状态
    # 成功返回: 机械臂当前状态,机械臂当前停止:RobotStatus.Stopped,机械臂当前运行:RobotStatus.Running
    # 机械臂当前暂停:RobotStatus.Paused,机械臂当前恢复:RobotStatus.Resumed
    def get_robot_state(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_robot_state(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂运动进入缩减模式
    def enter_reduce_mode(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.enter_reduce_mode(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置机械臂运动退出缩减模式
    def exit_reduce_mode(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.exit_reduce_mode(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 通知机械臂工程启动，服务器同时开始检测安全IO
    def project_startup(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.project_startup(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 通知机械臂工程停止，服务器停止检测安全IO
    def rs_project_stop(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.rs_project_stop(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 设置机械臂服务器工作模式(mode:服务器工作模式,机械臂仿真模式:RobotRunningMode.RobotModeSimulator,机械臂真实模式:RobotRunningMode.RobotModeReal)
    def set_work_mode(self, mode=0):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_work_mode(self.rshd, mode)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_LOGIN_FAILED

    # 获取机械臂服务器当前工作模式(成功返回: 服务器工作模式,机械臂仿真模式:RobotRunningMode.RobotModeSimulator,机械臂真实模式:RobotRunningMode.RobotModeReal
    def get_work_mode(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_work_mode(self.rshd)
        else:
            print("itialized or not login!!!")
            return None

    # 设置机械臂碰撞等级(grade碰撞等级:碰撞等级 范围（0～10）)
    def set_collision_class(self, grade=6):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_collision_class(self.rshd, grade)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_LOGIN_FAILED

    # 取当前是否已经链接真实机械臂(成功返回: 1：存在 0：不存在)
    def is_have_real_robot(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.is_have_real_robot(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 当前机械臂是否运行在联机模式(成功返回: 1：在 0：不在)
    def is_online_mode(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.is_online_mode(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 当前机械臂是否运行在联机主模式(成功返回: 1：主模式 0：从模式)
    def is_online_master_mode(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.is_online_master_mode(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 获取机械臂当前状态信息(成功返回: 返回六个关节状态，包括：电流，电压，温度)
    def get_joint_status(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_joint_status(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 获取机械臂当前位置信息(成功返回: 关节位置信息)
    # 六个关节角 {'joint': [1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
    # 位置 'pos': [-0.06403157614989634, -0.4185973810159096, 0.816883228463401],
    # 姿态 'ori': [-0.11863209307193756, 0.3820514380931854, 0.0, 0.9164950251579285]}
    def get_current_waypoint(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_current_waypoint(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 获取接口板指定 IO 集合的配置信息(io_type：IO类型：RobotIOType)
    # 成功返回: IO配置[{"id": ID"name": "IO名字""addr": IO地址"type": IO类型"value": IO当前值},]
    def get_board_io_config(self, io_type=RobotIOType.User_DO):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_board_io_config(self.rshd, io_type)
        else:
            print("RSHD uninitialized or not login!!!")
            return None
    # 获取IO状态(io_type:类型,io_name:名称 RobotUserIoName.user_dx_xx)
    # 成功返回: IO状态 double数值(数字IO，返回0或1,模拟IO返回浮点数）
    def get_board_io_status(self, io_type, io_name):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_board_io_status(self.rshd, io_type, io_name)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置IO状态(io_type:类型,io_name:名称 RobotUserIoName.user_dx_xx,io_value:状态数值(数字IO，返回0或1,模拟IO返回浮点数）)
    def set_board_io_status(self, io_type, io_name, io_value):
        # self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_board_io_status(self.rshd, io_type, io_name, io_value)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_LOGIN_FAILED

    # 设置工具端电源类型(power_type:电源类型,RobotToolPowerType.OUT_0V,RobotToolPowerType.OUT_12V,RobotToolPowerType.OUT_24V)
    def set_tool_power_type(self, power_type=RobotToolPowerType.OUT_0V):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_tool_power_type(self.rshd, power_type)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_LOGIN_FAILED

    # 获取工具端电源类型
    # 成功返回: 电源类型，RobotToolPowerType.OUT_0V, RobotToolPowerType.OUT_12V,RobotToolPowerType.OUT_24V
    def get_tool_power_type(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_tool_power_type(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置工具端数字IO类型(io_addr:工具端IO地址 详见class RobotToolIoAddr,io_type:工具端IO类型 详见class RobotToolDigitalIoDir)
    # 成功返回: IO类型，RobotToolDigitalIoDir.IO_IN, RobotToolDigitalIoDir.IO_OUT
    def set_tool_io_type(self, io_addr=RobotToolIoAddr.TOOL_DIGITAL_IO_0,
                         io_type=RobotToolDigitalIoDir.IO_OUT):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_tool_io_type(self.rshd, io_addr, io_type)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_LOGIN_FAILED

    # 获取工具端电压数值(成功返回: 返回电压数值，单位（伏特）)
    def get_tool_power_voltage(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_tool_power_voltage(self.rshd)
        else:
            print("itialized or not login!!!")
            return None

    # 获取工具端IO状态(io_name:IO名称)
    # 成功返回: 返回工具端IO状态
    def get_tool_io_status(self, io_name):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_tool_io_status(self.rshd, io_name)
        else:
            print("itialized or not login!!!")
            return None

    # 设置工具端IO状态(io_name：工具端IO名称,io_status:工具端IO状态: 取值范围（0或1）)
    def set_tool_io_status(self, io_name, io_status):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_tool_do_status(self.rshd, io_name, io_status)
        else:
            print("itialized or not login!!!")
            return RobotErrorType.RobotError_LOGIN_FAILED

    # 通知服务器启动辨识轨迹运动
    def startup_excit_traj_track(self, track_file='', track_type=0, subtype=0):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.startup_excit_traj_track(self.rshd, track_file, track_type, subtype)
        else:
            print("RSHD uninitialized or not login!!!")
            return RobotErrorType.RobotError_NotLogin

    # 获取辨识结果(成功返回: 辨识结果数组)
    def get_dynidentify_results(self):
        self.check_event()
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.get_dynidentify_results(self.rshd)
        else:
            print("RSHD uninitialized or not login!!!")
            return None

    # 设置机械臂事件回调函数(callback：回调函数名称)
    def set_robot_event_callback(self, callback):
        if self.rshd >= 0 and self.connected:
            return libpyauboi5.set_robot_event_callback(self.rshd, callback)
        else:
            print("RSHD uninitialized or not login!!!")
